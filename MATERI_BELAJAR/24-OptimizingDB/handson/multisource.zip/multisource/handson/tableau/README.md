# Panduan Visualisasi dengan Tableau

Folder ini berisi file Tableau untuk visualisasi data yang telah diintegrasikan dari Oracle SQL Developer dan MongoDB.

## Langkah-langkah Membuat Visualisasi

1. Buka Tableau Public atau Tableau Desktop
2. Sambungkan ke file CSV `../data/integrated_data.csv`
3. Buat visualisasi sesuai dengan panduan di `../docs/hands-on-guide.md`

## Visualisasi yang Dibuat

### Dashboard 1: Performa Produk
- Grafik batang untuk total penjualan per produk
- Grafik batang untuk rating rata-rata produk
- Scatter plot yang menunjukkan hubungan antara rating dan penjualan
- Filter berdasarkan kategori produk

### Dashboard 2: Analisis Interaksi Pengguna
- Grafik batang untuk jumlah view per produk
- Grafik batang untuk jumlah add to cart per produk
- Grafik batang untuk conversion rate (add to cart / view)
- Heat map yang menunjukkan korelasi antara interaksi dan penjualan

### Dashboard 3: Analisis Komprehensif
- Tabel yang menampilkan semua metrik penting per produk
- Grafik radar yang menunjukkan performa produk di berbagai dimensi
- Grafik tren yang menunjukkan penjualan dan rating dari waktu ke waktu

## Catatan
- File Tableau (.twbx) akan dibuat setelah mengikuti langkah-langkah di panduan hands-on
- Pastikan semua data telah diintegrasikan dengan benar sebelum membuat visualisasi