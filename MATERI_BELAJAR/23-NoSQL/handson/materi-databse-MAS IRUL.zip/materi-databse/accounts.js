const { Pool } = require("pg");
const { faker } = require("@faker-js/faker");

const pool = new Pool({
  user: "postgres",
  host: "localhost",
  database: "newbank", // sesuaikan
  password: "Ishlah123", // sesuaikan
  port: 5432,
});

async function insertAccounts() {
  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    // Ambil semua user ID dari tabel users
    const res = await client.query("SELECT id FROM users");
    const userIds = res.rows.map((row) => row.id);

    if (userIds.length === 0) {
      throw new Error(
        "Tidak ada user yang ditemukan. Harap isi tabel users terlebih dahulu."
      );
    }

    const accountTypes = ["personal", "bussiness"];
    const statuses = ["active", "frozen", "closed"];
    const values = [];

    for (let i = 0; i < 10000; i++) {
      const userId = faker.helpers.arrayElement(userIds);
      const accountNumber = `ACCT${Date.now()}${i}`.slice(0, 30); // max 30 char
      const accountType = faker.helpers.arrayElement(accountTypes);
      const balance = faker.finance.amount(10000, 100000000, 2); // 10rb s.d. 100jt
      const status = faker.helpers.arrayElement(statuses);

      values.push(
        `(${userId}, '${accountNumber}', '${accountType}', ${balance}, '${status}')`
      );
    }

    const query = `
      INSERT INTO accounts (user_id, account_number, account_type, balance, status)
      VALUES ${values.join(", ")};
    `;

    await client.query(query);
    await client.query("COMMIT");
    console.log("✅ Berhasil insert 10.000 akun.");
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("❌ Error:", err.message);
  } finally {
    client.release();
  }
}

insertAccounts();
