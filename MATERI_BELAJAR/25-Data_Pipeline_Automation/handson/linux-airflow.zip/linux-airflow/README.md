# Apache Airflow for Ubuntu Linux 🐧

This setup is specifically optimized for **Ubuntu Linux** systems with Docker and Docker Compose.

## 🚀 Quick Start for Ubuntu

### Prerequisites

1. **Ubuntu Linux** (18.04 LTS or later recommended)
2. **Docker** installed
3. **Docker Compose** installed

#### Install Docker on Ubuntu:
```bash
# Update package index
sudo apt update

# Install Docker
sudo apt install docker.io -y

# Add your user to docker group (avoid using sudo)
sudo usermod -aG docker $USER

# Install Docker Compose
sudo apt install docker-compose -y

# Logout and login again to apply group changes
```

### 🔧 Setup Instructions

1. **Clone or copy this directory to your Ubuntu system**

2. **Set the AIRFLOW_UID environment variable:**
```bash
# This is CRITICAL for Ubuntu Linux file permissions
echo -e "AIRFLOW_UID=$(id -u)" > .env
```

3. **Start Airflow:**
```bash
# Initialize and start all services
docker-compose up airflow-init
docker-compose up -d
```

4. **Access Airflow Web UI:**
   - Open: http://localhost:8080
   - Username: `admin`
   - Password: `admin`

### 📊 Ubuntu Linux Optimizations

This configuration includes several Ubuntu-specific optimizations:

#### Performance Optimizations:
- **CPU Scaling:** Optimized worker concurrency for multi-core Ubuntu systems
- **Memory Management:** Redis memory limits and overcommit settings
- **Network:** Custom bridge network with dedicated subnet
- **File System:** Proper user/group mapping for Ubuntu security

#### Resource Limits:
- **Worker Memory:** 2GB limit with 512MB reservation
- **Worker CPU:** 2.0 CPU limit with 0.5 CPU reservation
- **Redis Memory:** 256MB with LRU eviction policy

#### Security Features:
- User/group mapping from host Ubuntu system
- Proper file permissions with AIRFLOW_UID
- Read-only passwd/group mounts

### 🛠️ Ubuntu Commands

#### Start Services:
```bash
docker-compose up -d
```

#### Stop Services:
```bash
docker-compose down
```

#### View Logs:
```bash
# All services
docker-compose logs

# Specific service
docker-compose logs airflow-webserver
docker-compose logs airflow-scheduler
```

#### Reset Environment:
```bash
# Warning: This will delete all data!
docker-compose down -v
sudo rm -rf logs/* data/*
docker-compose up airflow-init
docker-compose up -d
```

#### Scale Workers (Ubuntu advantage):
```bash
# Scale to 3 worker instances for high-performance Ubuntu systems
docker-compose up -d --scale airflow-worker=3
```

### 🔍 Monitoring on Ubuntu

#### Check System Resources:
```bash
# Memory usage
free -h

# CPU usage
htop

# Docker stats
docker stats

# Disk usage
df -h
```

#### Check Airflow Status:
```bash
# All containers
docker-compose ps

# Resource usage
docker-compose top

# Live logs
docker-compose logs -f airflow-scheduler
```

### 📁 Directory Structure

```
linux-airflow/
├── docker-compose.yml    # Ubuntu-optimized Docker Compose
├── .env                  # Environment variables (create this!)
├── dags/                 # Your DAG files
│   ├── data_processing_dag.py
│   └── example_dag.py
├── data/                 # Data files (auto-created)
├── logs/                 # Airflow logs (auto-created)
├── plugins/              # Custom plugins (auto-created)
└── README.md            # This file
```

### ⚡ Performance Tuning for Ubuntu

#### For High-Performance Ubuntu Systems:
```bash
# Edit .env file to add:
echo "AIRFLOW__CORE__PARALLELISM=64" >> .env
echo "AIRFLOW__CORE__DAG_CONCURRENCY=32" >> .env
echo "AIRFLOW__CELERY__WORKER_CONCURRENCY=16" >> .env
```

#### For Low-Resource Ubuntu Systems:
```bash
# Edit .env file to add:
echo "AIRFLOW__CORE__PARALLELISM=8" >> .env
echo "AIRFLOW__CORE__DAG_CONCURRENCY=4" >> .env
echo "AIRFLOW__CELERY__WORKER_CONCURRENCY=2" >> .env
```

### 🐛 Ubuntu-Specific Troubleshooting

#### Permission Issues:
```bash
# If you get permission denied errors:
sudo chown -R $USER:$USER logs/ data/ dags/
chmod -R 755 logs/ data/ dags/
```

#### Docker Group Issues:
```bash
# If docker commands require sudo:
sudo usermod -aG docker $USER
newgrp docker
# Or logout and login again
```

#### Port Conflicts:
```bash
# If port 8080 is in use:
sudo netstat -tlnp | grep :8080
# Kill the process or change port in docker-compose.yml
```

#### Memory Issues:
```bash
# Check available memory:
free -h

# If low memory, reduce worker count:
docker-compose up -d --scale airflow-worker=1
```

### 🔗 Database Connection

This setup uses **Neon PostgreSQL** as the database backend:
- **Type:** PostgreSQL
- **Host:** Neon Cloud (external)
- **SSL:** Required
- **Connection:** Automatically configured

### 📝 Development on Ubuntu

#### Adding New DAGs:
1. Create Python files in `dags/` directory
2. Airflow will automatically detect them (every 5 minutes)
3. Refresh the web UI to see new DAGs

#### Testing DAGs:
```bash
# Test a specific DAG
docker-compose exec airflow-worker airflow dags test data_processing_workflow 2024-01-01

# List all DAGs
docker-compose exec airflow-worker airflow dags list
```

#### Installing Python Packages:
```bash
# Create a requirements.txt file
echo "pandas==1.5.3" >> requirements.txt
echo "requests==2.28.1" >> requirements.txt

# Rebuild with custom packages (create Dockerfile)
# Or use docker-compose exec to install temporarily
```

### 🚨 Ubuntu System Requirements

#### Minimum:
- **RAM:** 4GB
- **CPU:** 2 cores
- **Disk:** 10GB free space
- **OS:** Ubuntu 18.04 LTS+

#### Recommended:
- **RAM:** 8GB+
- **CPU:** 4+ cores
- **Disk:** 20GB+ free space
- **OS:** Ubuntu 20.04 LTS or 22.04 LTS

### 🎯 Next Steps

1. **Add your DAGs** to the `dags/` directory
2. **Configure connections** in the Airflow UI
3. **Set up monitoring** with tools like Prometheus (optional)
4. **Enable SSL** for production use (optional)
5. **Configure email notifications** (optional)

### 📞 Support

For Ubuntu-specific issues:
- Check Ubuntu system logs: `journalctl -u docker`
- Docker logs: `docker logs <container_name>`
- Airflow logs: `logs/` directory

For general Airflow help:
- Official Documentation: https://airflow.apache.org/docs/
- Community: https://airflow.apache.org/community/

---

**Happy Data Engineering on Ubuntu! 🐧✈️**