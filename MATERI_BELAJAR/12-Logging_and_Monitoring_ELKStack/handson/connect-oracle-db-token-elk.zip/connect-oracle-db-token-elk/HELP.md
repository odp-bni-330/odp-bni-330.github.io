# Cara Menjalankan Server
1. Pindah ke direktori
2. Jalankan pada terminal:
```bash
./mvnw spring-boot:run
```

# Cara Menghidupkan DB
```bash
docker ps -a            # menampilkan nama docker container (semua, termasuk yang in-active)

# menyalakan kembali docker tersebut
# syntax: docker start [nama_image] 
docker start oracle-xe

# menyalakan kembali servernya
docker exec -it oracle-xe sqlplus bostang/password@localhost:1521/XEPDB1
```

# Cara Monitor Log dengan ELK Stack

# Cara Hubungkan Aplikasi Springboot dengan ELK Stack
**Langkah 1** : Tambah dependency ke `pom.xml`:
```xml
<!-- Logstash Logback Encoder -->
<dependency>
    <groupId>net.logstash.logback</groupId>
    <artifactId>logstash-logback-encoder</artifactId>
    <version>7.4</version>
</dependency>
```

**Langkah 2**: Buat konfigurasi Logback
buat di `/resources/logback-spring.xml`:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<configuration>
    <include resource="org/springframework/boot/logging/logback/defaults.xml"/>
    
    <springProperty scope="context" name="appName" source="spring.application.name"/>
    
    <!-- Console Appender -->
    <appender name="CONSOLE" class="ch.qos.logback.core.ConsoleAppender">
        <encoder>
            <pattern>%d{yyyy-MM-dd HH:mm:ss} [%thread] %-5level %logger{36} - %msg%n</pattern>
        </encoder>
    </appender>
    
    <!-- Logstash Appender -->
    <appender name="LOGSTASH" class="net.logstash.logback.appender.LogstashTcpSocketAppender">
        <destination>localhost:5000</destination> <!-- Ganti dengan alamat Logstash Anda -->
        <encoder class="net.logstash.logback.encoder.LogstashEncoder">
            <customFields>{"appname":"${appName}", "environment":"development"}</customFields>
        </encoder>
    </appender>
    
    <root level="INFO">
        <appender-ref ref="CONSOLE"/>
        <appender-ref ref="LOGSTASH"/>
    </root>
    
    <!-- Log SQL queries -->
    <logger name="org.hibernate.SQL" level="DEBUG"/>
    <logger name="org.hibernate.type.descriptor.sql.BasicBinder" level="TRACE"/>
</configuration>
```

**Langkah 3** : Tambahkan bagian logging di controller
`/controller/AuthController.java`
```java
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    
    /* TAMBAHKAN INI */
    private static final Logger logger = LoggerFactory.getLogger(AuthController.class);
    
    ...

    logger.info("LOGIN_ATTEMPT for user {}", username);
    ...

    logger.warn("Login failed - invalid credentials for username: {}", username);

}
/*** LENGKAPNYA LANGSUNG CEK DI connect-oracle-db-token-elk bagian AuthController.java` ***/
```

# Menghidupkan ELK Stack (jalan di Docker)
**Langkah 1**: Buat `docker-compose-elk.yml`
```yml
version: '3.8'

services:
  elasticsearch:
    image: docker.elastic.co/elasticsearch/elasticsearch:8.12.0
    container_name: elasticsearch
    environment:
      - discovery.type=single-node
      - ES_JAVA_OPTS=-Xms1g -Xmx1g
      - xpack.security.enabled=false
    volumes:
      - es_data:/usr/share/elasticsearch/data
    ports:
      - "9200:9200"
    networks:
      - elk

  logstash:
    image: docker.elastic.co/logstash/logstash:8.12.0
    container_name: logstash
    volumes:
      - ./logstash-config:/usr/share/logstash/pipeline/
    ports:
      - "5000:5000"
    environment:
      - LS_JAVA_OPTS=-Xms512m -Xmx512m
    depends_on:
      - elasticsearch
    networks:
      - elk

  kibana:
    image: docker.elastic.co/kibana/kibana:8.12.0
    container_name: kibana
    ports:
      - "5601:5601"
    depends_on:
      - elasticsearch
    networks:
      - elk

volumes:
  es_data:

networks:
  elk:
    driver: bridge
```

**Langkah 2**: Buat Konfigurasi Logstash
```bash
mkdir logstash-config
```

Isi `logstash-config/logstash.conf`:
```conf
input {
  tcp {
    port => 5000
    codec => json_lines
  }
}

filter {
  # Parsing khusus untuk log login/register
  if [message] =~ "login" {
    grok {
      match => { "message" => ".*Login %{WORD:action} for username: %{USERNAME:username}.*" }
      add_tag => [ "auth_log" ]
    }
  }
  
  if [message] =~ "register" {
    grok {
      match => { "message" => ".*Register %{WORD:action} for username: %{USERNAME:username}.*" }
      add_tag => [ "auth_log" ]
    }
  }
}

output {
  elasticsearch {
    hosts => ["http://elasticsearch:9200"]
    index => "springboot-logs-%{+YYYY.MM.dd}"
  }
  
  # Untuk debugging (opsional)
  stdout {
    codec => rubydebug
  }
}
```

**Langkah 3** : Jalankan ELK stack
```bash
docker-compose -f docker-compose-elk.yml up
```

> Catatan : ketika pertama kali jalan, butuh minimal 2 menit agar ELK bisa berjalan mulus sehingga localhost:5601 dapat diakses

**Langkah 4** : Buat Dashboard Kibana
- **4.1** : Akses `http://localhost:5601`
- **4.2** : Nyalakan aplikasi springboot (pada terminal : `./mvnw spring-boot:run`) 
- **4.2**: Buat Index Pattern 
pattern : `springboot-logs-*` , pilih `@Timestamp`, pilih `Create Index pattern`

- **4.3** : Test kirim request lewat Postman lalu amati log di `http://localhost:5601/app/discover`

**Pengujian** :
![localhost-9200](./img/localhost-9200.png)

![pengujian-ELK-stack](./img/pengujian-ELK-stack.png)

![tampilan-pada-log-terminal](./img/tampilan-pada-log-terminal.png)

## Catatan Tambahan:
Untuk memberhentikan ELK stack yang jalan di docker:
```bash
docker-compose -f docker-compose-elk.yml down
# atau
docker compose down -f docker-compose-elk.yml
```

# Read Me First
The following was discovered as part of building this project:

* The original package name 'com.example.connect-oracle-db' is invalid and this project uses 'com.example.connect_oracle_db' instead.

# Getting Started

### Reference Documentation
For further reference, please consider the following sections:

* [Official Apache Maven documentation](https://maven.apache.org/guides/index.html)
* [Spring Boot Maven Plugin Reference Guide](https://docs.spring.io/spring-boot/3.5.0/maven-plugin)
* [Create an OCI image](https://docs.spring.io/spring-boot/3.5.0/maven-plugin/build-image.html)
* [Spring Web](https://docs.spring.io/spring-boot/3.5.0/reference/web/servlet.html)
* [Spring Data JPA](https://docs.spring.io/spring-boot/3.5.0/reference/data/sql.html#data.sql.jpa-and-spring-data)
* [Spring Boot DevTools](https://docs.spring.io/spring-boot/3.5.0/reference/using/devtools.html)

### Guides
The following guides illustrate how to use some features concretely:

* [Building a RESTful Web Service](https://spring.io/guides/gs/rest-service/)
* [Serving Web Content with Spring MVC](https://spring.io/guides/gs/serving-web-content/)
* [Building REST services with Spring](https://spring.io/guides/tutorials/rest/)
* [Accessing Data with JPA](https://spring.io/guides/gs/accessing-data-jpa/)

### Maven Parent overrides

Due to Maven's design, elements are inherited from the parent POM to the project POM.
While most of the inheritance is fine, it also inherits unwanted elements like `<license>` and `<developers>` from the parent.
To prevent this, the project POM contains empty overrides for these elements.
If you manually switch to a different parent and actually want the inheritance, you need to remove those overrides.

