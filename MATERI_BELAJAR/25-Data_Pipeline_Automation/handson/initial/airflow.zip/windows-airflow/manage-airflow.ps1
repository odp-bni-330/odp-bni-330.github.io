# Apache Airflow Management Script for Windows
# PowerShell version for advanced users

param(
    [Parameter(Mandatory=$false)]
    [ValidateSet("start", "stop", "restart", "status", "logs", "reset", "shell")]
    [string]$Action = "menu"
)

function Show-Header {
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host " Apache Airflow + Neon - Windows Manager" -ForegroundColor Cyan
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host ""
}

function Test-Docker {
    try {
        $dockerVersion = docker --version 2>$null
        if ($LASTEXITCODE -eq 0) {
            Write-Host "[OK] Docker is running: $dockerVersion" -ForegroundColor Green
            return $true
        }
    }
    catch {
        Write-Host "[ERROR] Docker is not running or not installed!" -ForegroundColor Red
        Write-Host "Please start Docker Desktop and try again." -ForegroundColor Yellow
        return $false
    }
}

function Start-Airflow {
    Write-Host "[INFO] Starting Airflow services..." -ForegroundColor Blue
    docker-compose up -d
    
    Write-Host "[INFO] Waiting for services to initialize..." -ForegroundColor Blue
    Start-Sleep -Seconds 15
    
    Get-Status
    
    Write-Host ""
    Write-Host "🚀 Airflow is starting up!" -ForegroundColor Green
    Write-Host "Web UI: http://localhost:8080" -ForegroundColor Cyan
    Write-Host "Username: admin | Password: admin" -ForegroundColor Yellow
    
    $openBrowser = Read-Host "Open Airflow in browser? (y/N)"
    if ($openBrowser -eq "y" -or $openBrowser -eq "Y") {
        Start-Process "http://localhost:8080"
    }
}

function Stop-Airflow {
    Write-Host "[INFO] Stopping Airflow services..." -ForegroundColor Blue
    docker-compose down
    Write-Host "✅ All Airflow services stopped." -ForegroundColor Green
}

function Restart-Airflow {
    Write-Host "[INFO] Restarting Airflow services..." -ForegroundColor Blue
    docker-compose restart
    Write-Host "✅ All Airflow services restarted." -ForegroundColor Green
}

function Get-Status {
    Write-Host "[INFO] Service Status:" -ForegroundColor Blue
    docker-compose ps
}

function Show-Logs {
    $service = Read-Host "Enter service name (webserver/scheduler/worker) or press Enter for all"
    if ([string]::IsNullOrWhiteSpace($service)) {
        docker-compose logs -f
    } else {
        docker-compose logs -f "airflow-$service"
    }
}

function Reset-Airflow {
    Write-Host ""
    Write-Host "⚠️  WARNING: This will delete local data (Neon database will not be affected)!" -ForegroundColor Red
    Write-Host "This includes:" -ForegroundColor Yellow
    Write-Host "  - All task logs" -ForegroundColor Yellow
    Write-Host "  - Generated data files" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "NOTE: Neon PostgreSQL database content will remain intact." -ForegroundColor Green
    Write-Host ""
    
    $confirm = Read-Host "Type 'YES' to confirm local data reset"
    if ($confirm -eq "YES") {
        Write-Host "[INFO] Stopping services..." -ForegroundColor Blue
        docker-compose down
        
        Write-Host "[INFO] Cleaning local directories..." -ForegroundColor Blue
        Remove-Item -Path "logs\*" -Force -Recurse -ErrorAction SilentlyContinue
        Remove-Item -Path "data\*" -Force -Recurse -ErrorAction SilentlyContinue
        
        Write-Host "✅ Local Airflow data reset!" -ForegroundColor Green
        Write-Host "✅ Neon database remains unchanged." -ForegroundColor Green
    } else {
        Write-Host "❌ Reset cancelled." -ForegroundColor Yellow
    }
}

function Enter-Shell {
    $service = Read-Host "Enter container (webserver/scheduler/worker) [webserver]"
    if ([string]::IsNullOrWhiteSpace($service)) {
        $service = "webserver"
    }
    
    Write-Host "[INFO] Entering $service container shell..." -ForegroundColor Blue
    docker-compose exec "airflow-$service" bash
}

function Test-NeonConnection {
    Write-Host "[INFO] Testing Neon PostgreSQL connection..." -ForegroundColor Blue
    .\test-neon-connection.ps1
}

function Show-Menu {
    Write-Host "Select an action:" -ForegroundColor Cyan
    Write-Host "1. Start Airflow" -ForegroundColor White
    Write-Host "2. Stop Airflow" -ForegroundColor White
    Write-Host "3. Restart Airflow" -ForegroundColor White
    Write-Host "4. Show Status" -ForegroundColor White
    Write-Host "5. View Logs" -ForegroundColor White
    Write-Host "6. Test Neon Database Connection" -ForegroundColor White
    Write-Host "7. Reset Airflow (Local Data Only)" -ForegroundColor White
    Write-Host "8. Enter Container Shell" -ForegroundColor White
    Write-Host "0. Exit" -ForegroundColor White
    Write-Host ""
    
    $choice = Read-Host "Enter choice (0-8)"
    
    switch ($choice) {
        "1" { Start-Airflow }
        "2" { Stop-Airflow }
        "3" { Restart-Airflow }
        "4" { Get-Status }
        "5" { Show-Logs }
        "6" { Test-NeonConnection }
        "7" { Reset-Airflow }
        "8" { Enter-Shell }
        "0" { exit }
        default { 
            Write-Host "Invalid choice!" -ForegroundColor Red
            Show-Menu
        }
    }
}

# Main execution
Clear-Host
Show-Header

if (-not (Test-Docker)) {
    exit 1
}

switch ($Action) {
    "start" { Start-Airflow }
    "stop" { Stop-Airflow }
    "restart" { Restart-Airflow }
    "status" { Get-Status }
    "logs" { Show-Logs }
    "reset" { Reset-Airflow }
    "shell" { Enter-Shell }
    "menu" { Show-Menu }
}

Write-Host ""
Write-Host "Script completed. Press any key to exit..."
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") 