// Create ecommerce user and database
db = db.getSiblingDB('ecommerce');

// Create user for ecommerce database
db.createUser({
  user: 'ecommerce_user',
  pwd: 'ecommerce_pass',
  roles: [
    {
      role: 'readWrite',
      db: 'ecommerce'
    }
  ]
});

// Insert sample customer data
db.customers.insertMany([
  {
    customer_id: 1001,
    name: "John Doe",
    email: "john.doe@email.com",
    age: 28,
    gender: "Male",
    location: {
      city: "Jakarta",
      country: "Indonesia",
      coordinates: [-6.2088, 106.8456]
    },
    registration_date: new Date("2023-01-15"),
    status: "active",
    preferences: {
      categories: ["Electronics", "Books"],
      newsletter: true
    }
  },
  {
    customer_id: 1002,
    name: "Jane Smith",
    email: "jane.smith@email.com",
    age: 32,
    gender: "Female",
    location: {
      city: "Surabaya",
      country: "Indonesia",
      coordinates: [-7.2575, 112.7521]
    },
    registration_date: new Date("2023-02-10"),
    status: "active",
    preferences: {
      categories: ["Fashion", "Health"],
      newsletter: true
    }
  },
  {
    customer_id: 1003,
    name: "Michael Johnson",
    email: "michael.johnson@email.com",
    age: 35,
    gender: "Male",
    location: {
      city: "Bandung",
      country: "Indonesia",
      coordinates: [-6.9175, 107.6191]
    },
    registration_date: new Date("2023-03-05"),
    status: "active",
    preferences: {
      categories: ["Electronics", "Sports"],
      newsletter: false
    }
  },
  {
    customer_id: 1004,
    name: "Sarah Wilson",
    email: "sarah.wilson@email.com",
    age: 27,
    gender: "Female",
    location: {
      city: "Medan",
      country: "Indonesia",
      coordinates: [3.5952, 98.6722]
    },
    registration_date: new Date("2023-04-12"),
    status: "active",
    preferences: {
      categories: ["Fashion", "Books"],
      newsletter: true
    }
  },
  {
    customer_id: 1005,
    name: "David Brown",
    email: "david.brown@email.com",
    age: 41,
    gender: "Male",
    location: {
      city: "Yogyakarta",
      country: "Indonesia",
      coordinates: [-7.7956, 110.3695]
    },
    registration_date: new Date("2023-05-20"),
    status: "active",
    preferences: {
      categories: ["Sports", "Health"],
      newsletter: true
    }
  },
  {
    customer_id: 1006,
    name: "Lisa Anderson",
    email: "lisa.anderson@email.com",
    age: 29,
    gender: "Female",
    location: {
      city: "Semarang",
      country: "Indonesia",
      coordinates: [-6.9667, 110.4167]
    },
    registration_date: new Date("2023-06-08"),
    status: "active",
    preferences: {
      categories: ["Books", "Home"],
      newsletter: false
    }
  },
  {
    customer_id: 1007,
    name: "Robert Taylor",
    email: "robert.taylor@email.com",
    age: 33,
    gender: "Male",
    location: {
      city: "Malang",
      country: "Indonesia",
      coordinates: [-7.9797, 112.6304]
    },
    registration_date: new Date("2023-07-15"),
    status: "active",
    preferences: {
      categories: ["Electronics", "Home"],
      newsletter: true
    }
  },
  {
    customer_id: 1008,
    name: "Emily Davis",
    email: "emily.davis@email.com",
    age: 26,
    gender: "Female",
    location: {
      city: "Denpasar",
      country: "Indonesia",
      coordinates: [-8.6500, 115.2167]
    },
    registration_date: new Date("2023-08-22"),
    status: "active",
    preferences: {
      categories: ["Fashion", "Sports"],
      newsletter: true
    }
  },
  {
    customer_id: 1009,
    name: "Christopher Miller",
    email: "christopher.miller@email.com",
    age: 38,
    gender: "Male",
    location: {
      city: "Makassar",
      country: "Indonesia",
      coordinates: [-5.1477, 119.4327]
    },
    registration_date: new Date("2023-09-10"),
    status: "active",
    preferences: {
      categories: ["Health", "Books"],
      newsletter: false
    }
  },
  {
    customer_id: 1010,
    name: "Amanda Wilson",
    email: "amanda.wilson@email.com",
    age: 31,
    gender: "Female",
    location: {
      city: "Palembang",
      country: "Indonesia",
      coordinates: [-2.9167, 104.7458]
    },
    registration_date: new Date("2023-10-05"),
    status: "active",
    preferences: {
      categories: ["Home", "Electronics"],
      newsletter: true
    }
  },
  {
    customer_id: 1011,
    name: "James Moore",
    email: "james.moore@email.com",
    age: 45,
    gender: "Male",
    location: {
      city: "Jakarta",
      country: "Indonesia",
      coordinates: [-6.2088, 106.8456]
    },
    registration_date: new Date("2023-11-12"),
    status: "active",
    preferences: {
      categories: ["Electronics", "Sports"],
      newsletter: true
    }
  },
  {
    customer_id: 1012,
    name: "Michelle Garcia",
    email: "michelle.garcia@email.com",
    age: 24,
    gender: "Female",
    location: {
      city: "Surabaya",
      country: "Indonesia",
      coordinates: [-7.2575, 112.7521]
    },
    registration_date: new Date("2023-12-01"),
    status: "active",
    preferences: {
      categories: ["Fashion", "Health"],
      newsletter: false
    }
  },
  {
    customer_id: 1013,
    name: "Kevin Rodriguez",
    email: "kevin.rodriguez@email.com",
    age: 30,
    gender: "Male",
    location: {
      city: "Bandung",
      country: "Indonesia",
      coordinates: [-6.9175, 107.6191]
    },
    registration_date: new Date("2024-01-10"),
    status: "active",
    preferences: {
      categories: ["Books", "Electronics"],
      newsletter: true
    }
  },
  {
    customer_id: 1014,
    name: "Jessica Lee",
    email: "jessica.lee@email.com",
    age: 27,
    gender: "Female",
    location: {
      city: "Medan",
      country: "Indonesia",
      coordinates: [3.5952, 98.6722]
    },
    registration_date: new Date("2024-01-20"),
    status: "active",
    preferences: {
      categories: ["Fashion", "Home"],
      newsletter: true
    }
  },
  {
    customer_id: 1015,
    name: "Daniel Martinez",
    email: "daniel.martinez@email.com",
    age: 36,
    gender: "Male",
    location: {
      city: "Yogyakarta",
      country: "Indonesia",
      coordinates: [-7.7956, 110.3695]
    },
    registration_date: new Date("2024-02-01"),
    status: "active",
    preferences: {
      categories: ["Sports", "Health"],
      newsletter: false
    }
  }
]);

// Create indexes for better performance
db.customers.createIndex({ "customer_id": 1 });
db.customers.createIndex({ "location.city": 1 });
db.customers.createIndex({ "status": 1 });
db.customers.createIndex({ "preferences.categories": 1 });

print("Database initialization completed successfully!"); 