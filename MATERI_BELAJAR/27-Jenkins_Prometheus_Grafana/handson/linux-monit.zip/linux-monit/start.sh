#!/bin/bash

# Navigate to the directory where the script is located
#cd "$(dirname "$0")"

echo "Starting monitoring stack..."
docker-compose up -d

echo "Monitoring stack started."
echo "Prometheus is available at http://localhost:9090"
echo "Grafana is available at http://localhost:3000 (login: admin/admin)" 
