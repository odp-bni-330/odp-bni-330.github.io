/*
 * Written by : Bostang Palaguna
 * Date : 2025-05-28
 * File : ProductController.java
 * Deskripsi : Layer interface dengan user
 */

// src/main/java/com/example/api_caching/controller/ProductController.java
package com.example.api_caching.controller;     // package declaration

// library import
import com.example.api_caching.model.Product;
import com.example.api_caching.service.ProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST Controller for product management operations
 * Base URL: /api/products
 */

/************************** Layer Control **************************/
@RestController                     // Menandakan kelas ini Spring MVC Controller ; otomatis konversi return value ke JSON
@RequestMapping("/api/products")    // Menentukan base path untuk endpoint
@RequiredArgsConstructor            // Lombok: Generates constructor for dependency injection
public class ProductController {
    
    // Dependency injection of ProductService for business logic
    private final ProductService productService;
    
    /**
     * Fetch all products
     * GET /api/products
     * @return List of all products with 200 OK status
     */
    @GetMapping
    public List<Product> getAllProducts() {
        // Delegate to service layer which handles caching automatically
        return productService.getAllProducts();
    }
    
    /**
     * Get single product by ID
     * GET /api/products/{id}
     * @param id Product ID (path variable)
     * @return Requested product or null if not found (200 OK)
     */
    @GetMapping("/{id}")
    public Product getProductById(@PathVariable Long id) {
        // Service layer handles caching with @Cacheable
        return productService.getProductById(id);
    }
    
    /**
     * Update existing product
     * PUT /api/products/{id}
     * @param id Product ID (path variable)
     * @param product Updated product data (request body)
     * @return Updated product with 200 OK status
     */
    @PutMapping("/{id}")
    public ResponseEntity<Product> updateProduct(
            @PathVariable Long id,
            @RequestBody Product product) {
        // Ensure path ID matches body ID
        product.setId(id); 
        // Service handles cache update via @CachePut
        Product updatedProduct = productService.updateProduct(product);
        return ResponseEntity.ok(updatedProduct);
    }
    
    /**
     * Delete a product
     * DELETE /api/products/{id}
     * @param id Product ID to delete (path variable)
     * Note: Returns 204 No Content by default for void methods
     */
    @DeleteMapping("/{id}")
    public void deleteProduct(@PathVariable Long id) {
        // Service handles cache eviction via @CacheEvict
        productService.deleteProduct(id);
    }
    
    /**
     * Clear all product caches (Admin/Dev endpoint)
     * POST /api/products/clear-cache
     * Note: Returns 200 OK by default
     */
    @PostMapping("/clear-cache")
    public void clearCache() {
        // Clears both 'products' and 'product' caches
        productService.clearAllCaches();
    }

    /**
     * Create new product
     * POST /api/products
     * @param product Product data to create (request body)
     * @return Created product with 201 Created status
     */
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED) // Sets 201 status instead of default 200
    public Product createProduct(@RequestBody Product product) {
        // Service handles cache eviction for product list
        return productService.createProduct(product);
    }
}
/************************** End of Layer Control *******************/