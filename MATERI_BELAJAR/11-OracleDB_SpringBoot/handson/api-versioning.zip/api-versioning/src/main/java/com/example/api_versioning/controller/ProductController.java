/*
 * Written by : Bostang Palaguna
 * Date : 2025-05-28
 * File : ProductController.java
 * Deskripsi : versioning API melalui Request Parameter
 */

/***************************************** METODE 2 : Request Parameter Versioning *****************************************/
// src/main/java/com/example/api_versioning/controller/ProductController.java
package com.example.api_versioning.controller;  // package declaration

// import library
import com.example.api_versioning.dto.v1.ProductV1;
import com.example.api_versioning.dto.v2.ProductV2;
import com.example.api_versioning.service.ProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/************************** Layer Controller **************************/
@RestController                     // Menandakan kelas ini Spring MVC Controller ; otomatis konversi return value ke JSON
@RequestMapping("/api/products")    // Menentukan base path untuk endpoint
@RequiredArgsConstructor            // Buat constructor dengan parameter untuk semua field yang final : ProductService
public class ProductController {
    
    private final ProductService productService;
    
    @GetMapping(params = "version=1")   // Hanya akan dipanggil jika request mengandung parameter : version = 1
                                        // contoh URI : http://localhost:8081/api/products?version=1
    public List<ProductV1> getAllProductsParamV1() {
        return productService.getAllProductsV1();   // return dalam bentuk JSON
    }
    
    @GetMapping(params = "version=2")
    public List<ProductV2> getAllProductsParamV2() {
        return productService.getAllProductsV2();
    }
}
/************************** End of Layer Controller *******************/

/* OLD CODE (TANPTA DTO)
// src/main/java/com/example/api_versioning/controller/ProductController.java
package com.example.api_versioning.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/products")
public class ProductController {
    
    @GetMapping(params = "version=1")
    public String getAllProductsV1() {
        return "Daftar produk (Versi 1 - parameter)";
    }
    
    @GetMapping(params = "version=2")
    public String getAllProductsV2() {
        return "Daftar produk dengan fitur baru (Versi 2 - parameter)";
    }
}
*/
/***************************************** End of METODE 2 *****************************************/