# Panduan Hands-on: Analisis Data dari Sumber yang Berbeda (SQL dan NoSQL)

## Pendahuluan
Dalam hands-on ini, kita akan mempelajari cara menganalisis data dari dua sumber berbeda: database relasional (Oracle) dan database NoSQL (MongoDB). Kita akan mengintegrasikan hasil analisis dan memvisualisasikannya menggunakan Tableau.

## Kasus Bisnis
Sebuah perusahaan e-commerce memiliki data transaksi yang tersimpan di database Oracle, sementara data interaksi pengguna dan review produk disimpan di MongoDB. Kita akan menganalisis kedua sumber data ini untuk mendapatkan insight bisnis yang komprehensif.

## Persiapan

### 1. Instalasi Tools dengan Docker
Untuk memudahkan instalasi database, kita akan menggunakan Docker Compose:

```bash
# Menjalankan database Oracle dan MongoDB dengan Docker Compose
docker-compose up -d
```

Setelah container berjalan, Anda dapat mengakses:
- Oracle Database: localhost:1521 (user: ecommerce, password: ecommerce)
- MongoDB: localhost:27017 (user: ecommerce_user, password: ecommerce_pass)
- MongoDB Express (GUI): http://localhost:8081 (user: admin, password: admin)

### 2. Tools Tambahan yang Diperlukan
- Oracle SQL Developer: [Download Oracle SQL Developer](https://www.oracle.com/database/sqldeveloper/technologies/download/)
- MongoDB Compass (GUI untuk MongoDB): [Download MongoDB Compass](https://www.mongodb.com/try/download/compass)
- Tableau Public: [Download Tableau Public](https://public.tableau.com/en-us/s/download)

### 2. Dataset
Kita akan menggunakan dua dataset:
- **Dataset Transaksi** (Oracle): Data transaksi penjualan e-commerce
- **Dataset Review** (MongoDB): Data review produk dan interaksi pengguna

## Langkah 1: Persiapan Database Oracle

1. Buka Oracle SQL Developer dan buat koneksi baru
2. Jalankan script berikut untuk membuat skema database:

```sql
-- Membuat tabel Customers
CREATE TABLE customers (
    customer_id NUMBER PRIMARY KEY,
    customer_name VARCHAR2(100),
    email VARCHAR2(100),
    registration_date DATE,
    status VARCHAR2(20)
);

-- Membuat tabel Products
CREATE TABLE products (
    product_id NUMBER PRIMARY KEY,
    product_name VARCHAR2(100),
    category VARCHAR2(50),
    price NUMBER(10,2),
    stock_quantity NUMBER
);

-- Membuat tabel Transactions
CREATE TABLE transactions (
    transaction_id NUMBER PRIMARY KEY,
    customer_id NUMBER,
    transaction_date DATE,
    total_amount NUMBER(10,2),
    payment_method VARCHAR2(50),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

-- Membuat tabel Transaction_Items
CREATE TABLE transaction_items (
    item_id NUMBER PRIMARY KEY,
    transaction_id NUMBER,
    product_id NUMBER,
    quantity NUMBER,
    unit_price NUMBER(10,2),
    FOREIGN KEY (transaction_id) REFERENCES transactions(transaction_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);
```

3. Masukkan data sampel:

```sql
-- Insert data ke tabel Customers
INSERT INTO customers VALUES (1, 'John Doe', 'john.doe@email.com', TO_DATE('2022-01-15', 'YYYY-MM-DD'), 'active');
INSERT INTO customers VALUES (2, 'Jane Smith', 'jane.smith@email.com', TO_DATE('2022-02-20', 'YYYY-MM-DD'), 'active');
INSERT INTO customers VALUES (3, 'Robert Johnson', 'robert.j@email.com', TO_DATE('2022-03-10', 'YYYY-MM-DD'), 'inactive');
INSERT INTO customers VALUES (4, 'Emily Davis', 'emily.d@email.com', TO_DATE('2022-04-05', 'YYYY-MM-DD'), 'active');
INSERT INTO customers VALUES (5, 'Michael Brown', 'michael.b@email.com', TO_DATE('2022-05-12', 'YYYY-MM-DD'), 'active');

-- Insert data ke tabel Products
INSERT INTO products VALUES (101, 'Smartphone X', 'Electronics', 899.99, 50);
INSERT INTO products VALUES (102, 'Laptop Pro', 'Electronics', 1299.99, 30);
INSERT INTO products VALUES (103, 'Coffee Maker', 'Home Appliances', 79.99, 100);
INSERT INTO products VALUES (104, 'Running Shoes', 'Sports', 129.99, 200);
INSERT INTO products VALUES (105, 'Wireless Earbuds', 'Electronics', 149.99, 75);

-- Insert data ke tabel Transactions
INSERT INTO transactions VALUES (1001, 1, TO_DATE('2023-01-10', 'YYYY-MM-DD'), 899.99, 'Credit Card');
INSERT INTO transactions VALUES (1002, 2, TO_DATE('2023-01-15', 'YYYY-MM-DD'), 1299.99, 'PayPal');
INSERT INTO transactions VALUES (1003, 3, TO_DATE('2023-01-20', 'YYYY-MM-DD'), 79.99, 'Credit Card');
INSERT INTO transactions VALUES (1004, 4, TO_DATE('2023-01-25', 'YYYY-MM-DD'), 279.98, 'Debit Card');
INSERT INTO transactions VALUES (1005, 5, TO_DATE('2023-02-01', 'YYYY-MM-DD'), 1049.98, 'Credit Card');
INSERT INTO transactions VALUES (1006, 1, TO_DATE('2023-02-05', 'YYYY-MM-DD'), 149.99, 'PayPal');
INSERT INTO transactions VALUES (1007, 2, TO_DATE('2023-02-10', 'YYYY-MM-DD'), 129.99, 'Credit Card');

-- Insert data ke tabel Transaction_Items
INSERT INTO transaction_items VALUES (10001, 1001, 101, 1, 899.99);
INSERT INTO transaction_items VALUES (10002, 1002, 102, 1, 1299.99);
INSERT INTO transaction_items VALUES (10003, 1003, 103, 1, 79.99);
INSERT INTO transaction_items VALUES (10004, 1004, 104, 1, 129.99);
INSERT INTO transaction_items VALUES (10005, 1004, 103, 1, 149.99);
INSERT INTO transaction_items VALUES (10006, 1005, 102, 1, 1299.99);
INSERT INTO transaction_items VALUES (10007, 1005, 105, 1, 149.99);
INSERT INTO transaction_items VALUES (10008, 1006, 105, 1, 149.99);
INSERT INTO transaction_items VALUES (10009, 1007, 104, 1, 129.99);
```

## Langkah 2: Persiapan Database MongoDB

1. Buka MongoDB Compass dan sambungkan ke server MongoDB lokal
2. Buat database baru bernama `ecommerce`
3. Buat collection bernama `product_reviews`
4. Import data review produk berikut (simpan sebagai JSON dan import melalui MongoDB Compass):

```json
[
  {
    "review_id": "r101",
    "product_id": 101,
    "customer_id": 2,
    "rating": 4.5,
    "review_text": "Great smartphone with excellent camera quality!",
    "review_date": {"$date": "2023-01-20T00:00:00Z"},
    "helpful_votes": 15,
    "verified_purchase": true
  },
  {
    "review_id": "r102",
    "product_id": 101,
    "customer_id": 4,
    "rating": 3.5,
    "review_text": "Good phone but battery life could be better.",
    "review_date": {"$date": "2023-01-25T00:00:00Z"},
    "helpful_votes": 8,
    "verified_purchase": true
  },
  {
    "review_id": "r103",
    "product_id": 102,
    "customer_id": 1,
    "rating": 5.0,
    "review_text": "Excellent laptop! Fast performance and great display.",
    "review_date": {"$date": "2023-02-02T00:00:00Z"},
    "helpful_votes": 20,
    "verified_purchase": true
  },
  {
    "review_id": "r104",
    "product_id": 103,
    "customer_id": 5,
    "rating": 4.0,
    "review_text": "Makes great coffee, easy to use.",
    "review_date": {"$date": "2023-02-05T00:00:00Z"},
    "helpful_votes": 12,
    "verified_purchase": true
  },
  {
    "review_id": "r105",
    "product_id": 104,
    "customer_id": 3,
    "rating": 4.5,
    "review_text": "Very comfortable running shoes, good support.",
    "review_date": {"$date": "2023-02-10T00:00:00Z"},
    "helpful_votes": 7,
    "verified_purchase": false
  },
  {
    "review_id": "r106",
    "product_id": 105,
    "customer_id": 2,
    "rating": 5.0,
    "review_text": "Amazing sound quality and comfortable fit!",
    "review_date": {"$date": "2023-02-15T00:00:00Z"},
    "helpful_votes": 18,
    "verified_purchase": true
  },
  {
    "review_id": "r107",
    "product_id": 101,
    "customer_id": 5,
    "rating": 4.0,
    "review_text": "Good value for money, but charging is slow.",
    "review_date": {"$date": "2023-02-20T00:00:00Z"},
    "helpful_votes": 5,
    "verified_purchase": true
  },
  {
    "review_id": "r108",
    "product_id": 102,
    "customer_id": 4,
    "rating": 4.5,
    "review_text": "Great for work and gaming. Keyboard is excellent.",
    "review_date": {"$date": "2023-02-25T00:00:00Z"},
    "helpful_votes": 10,
    "verified_purchase": true
  }
]
```

5. Buat collection bernama `user_interactions` dan import data berikut:

```json
[
  {
    "interaction_id": "i101",
    "customer_id": 1,
    "product_id": 101,
    "interaction_type": "view",
    "timestamp": {"$date": "2023-01-08T10:15:00Z"},
    "duration_seconds": 120,
    "device": "mobile"
  },
  {
    "interaction_id": "i102",
    "customer_id": 1,
    "product_id": 102,
    "interaction_type": "view",
    "timestamp": {"$date": "2023-01-08T10:20:00Z"},
    "duration_seconds": 180,
    "device": "mobile"
  },
  {
    "interaction_id": "i103",
    "customer_id": 2,
    "product_id": 101,
    "interaction_type": "view",
    "timestamp": {"$date": "2023-01-12T14:30:00Z"},
    "duration_seconds": 90,
    "device": "desktop"
  },
  {
    "interaction_id": "i104",
    "customer_id": 2,
    "product_id": 102,
    "interaction_type": "add_to_cart",
    "timestamp": {"$date": "2023-01-12T14:35:00Z"},
    "device": "desktop"
  },
  {
    "interaction_id": "i105",
    "customer_id": 3,
    "product_id": 103,
    "interaction_type": "view",
    "timestamp": {"$date": "2023-01-15T09:10:00Z"},
    "duration_seconds": 60,
    "device": "mobile"
  },
  {
    "interaction_id": "i106",
    "customer_id": 3,
    "product_id": 103,
    "interaction_type": "add_to_cart",
    "timestamp": {"$date": "2023-01-15T09:12:00Z"},
    "device": "mobile"
  },
  {
    "interaction_id": "i107",
    "customer_id": 4,
    "product_id": 104,
    "interaction_type": "view",
    "timestamp": {"$date": "2023-01-20T16:45:00Z"},
    "duration_seconds": 150,
    "device": "tablet"
  },
  {
    "interaction_id": "i108",
    "customer_id": 4,
    "product_id": 103,
    "interaction_type": "view",
    "timestamp": {"$date": "2023-01-20T16:50:00Z"},
    "duration_seconds": 75,
    "device": "tablet"
  },
  {
    "interaction_id": "i109",
    "customer_id": 4,
    "product_id": 104,
    "interaction_type": "add_to_cart",
    "timestamp": {"$date": "2023-01-20T16:55:00Z"},
    "device": "tablet"
  },
  {
    "interaction_id": "i110",
    "customer_id": 5,
    "product_id": 102,
    "interaction_type": "view",
    "timestamp": {"$date": "2023-01-25T11:20:00Z"},
    "duration_seconds": 200,
    "device": "desktop"
  },
  {
    "interaction_id": "i111",
    "customer_id": 5,
    "product_id": 105,
    "interaction_type": "view",
    "timestamp": {"$date": "2023-01-25T11:25:00Z"},
    "duration_seconds": 100,
    "device": "desktop"
  },
  {
    "interaction_id": "i112",
    "customer_id": 5,
    "product_id": 102,
    "interaction_type": "add_to_cart",
    "timestamp": {"$date": "2023-01-25T11:30:00Z"},
    "device": "desktop"
  }
]
```

## Langkah 3: Analisis Data dengan Oracle SQL Developer

Jalankan query-query berikut untuk menganalisis data transaksi:

### 1. Analisis Total Penjualan per Kategori Produk

```sql
SELECT 
    p.category,
    SUM(ti.quantity * ti.unit_price) AS total_sales
FROM 
    transaction_items ti
JOIN 
    products p ON ti.product_id = p.product_id
GROUP BY 
    p.category
ORDER BY 
    total_sales DESC;
```

### 2. Analisis Metode Pembayaran yang Paling Populer

```sql
SELECT 
    payment_method,
    COUNT(*) AS transaction_count,
    SUM(total_amount) AS total_amount
FROM 
    transactions
GROUP BY 
    payment_method
ORDER BY 
    transaction_count DESC;
```

### 3. Analisis Tren Penjualan Bulanan

```sql
SELECT 
    TO_CHAR(transaction_date, 'YYYY-MM') AS month,
    COUNT(*) AS transaction_count,
    SUM(total_amount) AS total_sales
FROM 
    transactions
GROUP BY 
    TO_CHAR(transaction_date, 'YYYY-MM')
ORDER BY 
    month;
```

### 4. Analisis Produk Terlaris

```sql
SELECT 
    p.product_id,
    p.product_name,
    SUM(ti.quantity) AS total_quantity_sold,
    SUM(ti.quantity * ti.unit_price) AS total_revenue
FROM 
    transaction_items ti
JOIN 
    products p ON ti.product_id = p.product_id
GROUP BY 
    p.product_id, p.product_name
ORDER BY 
    total_quantity_sold DESC;
```

### 5. Analisis Customer Lifetime Value

```sql
SELECT 
    c.customer_id,
    c.customer_name,
    COUNT(t.transaction_id) AS transaction_count,
    SUM(t.total_amount) AS total_spent
FROM 
    customers c
LEFT JOIN 
    transactions t ON c.customer_id = t.customer_id
GROUP BY 
    c.customer_id, c.customer_name
ORDER BY 
    total_spent DESC;
```

## Langkah 4: Analisis Data dengan MongoDB

Jalankan query-query berikut di MongoDB Compass:

### 1. Analisis Rating Produk

```javascript
db.product_reviews.aggregate([
  {
    $group: {
      _id: "$product_id",
      average_rating: { $avg: "$rating" },
      review_count: { $sum: 1 }
    }
  },
  {
    $sort: { average_rating: -1 }
  }
])
```

### 2. Analisis Review dengan Helpful Votes Tertinggi

```javascript
db.product_reviews.find().sort({ helpful_votes: -1 }).limit(5)
```

### 3. Analisis Interaksi Pengguna per Device

```javascript
db.user_interactions.aggregate([
  {
    $group: {
      _id: "$device",
      interaction_count: { $sum: 1 },
      avg_duration: { $avg: "$duration_seconds" }
    }
  },
  {
    $sort: { interaction_count: -1 }
  }
])
```

### 4. Analisis Konversi View ke Add to Cart

```javascript
db.user_interactions.aggregate([
  {
    $group: {
      _id: "$product_id",
      view_count: {
        $sum: { $cond: [{ $eq: ["$interaction_type", "view"] }, 1, 0] }
      },
      add_to_cart_count: {
        $sum: { $cond: [{ $eq: ["$interaction_type", "add_to_cart"] }, 1, 0] }
      }
    }
  },
  {
    $project: {
      _id: 1,
      view_count: 1,
      add_to_cart_count: 1,
      conversion_rate: {
        $cond: [
          { $eq: ["$view_count", 0] },
          0,
          { $divide: ["$add_to_cart_count", "$view_count"] }
        ]
      }
    }
  },
  {
    $sort: { conversion_rate: -1 }
  }
])
```

## Langkah 5: Integrasi Data dari Kedua Sumber

Untuk mengintegrasikan data dari kedua sumber, kita perlu mengekspor hasil query dari Oracle dan MongoDB, kemudian menggabungkannya untuk analisis lebih lanjut.

### Ekspor Data dari Oracle SQL Developer

1. Jalankan query berikut untuk mendapatkan data produk dengan penjualan:

```sql
SELECT 
    p.product_id,
    p.product_name,
    p.category,
    SUM(ti.quantity) AS total_quantity_sold,
    SUM(ti.quantity * ti.unit_price) AS total_revenue
FROM 
    products p
LEFT JOIN 
    transaction_items ti ON p.product_id = ti.product_id
GROUP BY 
    p.product_id, p.product_name, p.category
ORDER BY 
    p.product_id;
```

2. Ekspor hasil query ke CSV dengan nama `product_sales.csv`

### Ekspor Data dari MongoDB

1. Jalankan query berikut untuk mendapatkan data rating produk:

```javascript
db.product_reviews.aggregate([
  {
    $group: {
      _id: "$product_id",
      average_rating: { $avg: "$rating" },
      review_count: { $sum: 1 }
    }
  },
  {
    $sort: { _id: 1 }
  }
])
```

2. Ekspor hasil query ke CSV dengan nama `product_ratings.csv`

3. Jalankan query berikut untuk mendapatkan data interaksi produk:

```javascript
db.user_interactions.aggregate([
  {
    $group: {
      _id: "$product_id",
      view_count: {
        $sum: { $cond: [{ $eq: ["$interaction_type", "view"] }, 1, 0] }
      },
      add_to_cart_count: {
        $sum: { $cond: [{ $eq: ["$interaction_type", "add_to_cart"] }, 1, 0] }
      }
    }
  },
  {
    $project: {
      _id: 1,
      view_count: 1,
      add_to_cart_count: 1,
      conversion_rate: {
        $cond: [
          { $eq: ["$view_count", 0] },
          0,
          { $divide: ["$add_to_cart_count", "$view_count"] }
        ]
      }
    }
  },
  {
    $sort: { _id: 1 }
  }
])
```

4. Ekspor hasil query ke CSV dengan nama `product_interactions.csv`

## Langkah 6: Visualisasi dengan Tableau

1. Buka Tableau dan sambungkan ke file CSV yang telah diekspor
2. Gabungkan data menggunakan fitur "Relationships" di Tableau dengan product_id sebagai kunci
3. Buat visualisasi berikut:

### Dashboard 1: Performa Produk

- Grafik batang untuk total penjualan per produk
- Grafik batang untuk rating rata-rata produk
- Scatter plot yang menunjukkan hubungan antara rating dan penjualan
- Filter berdasarkan kategori produk

### Dashboard 2: Analisis Interaksi Pengguna

- Grafik batang untuk jumlah view per produk
- Grafik batang untuk jumlah add to cart per produk
- Grafik batang untuk conversion rate (add to cart / view)
- Heat map yang menunjukkan korelasi antara interaksi dan penjualan

### Dashboard 3: Analisis Komprehensif

- Tabel yang menampilkan semua metrik penting per produk
- Grafik radar yang menunjukkan performa produk di berbagai dimensi
- Grafik tren yang menunjukkan penjualan dan rating dari waktu ke waktu

## Kesimpulan

Dalam hands-on ini, kita telah mempelajari cara:
1. Menyiapkan dan menganalisis data dari database relasional (Oracle)
2. Menyiapkan dan menganalisis data dari database NoSQL (MongoDB)
3. Mengintegrasikan data dari kedua sumber
4. Memvisualisasikan hasil analisis menggunakan Tableau

Dengan mengintegrasikan data dari sumber yang berbeda, kita dapat memperoleh insight yang lebih komprehensif tentang performa produk, perilaku pelanggan, dan tren penjualan.

## Langkah Selanjutnya

- Implementasikan pipeline ETL untuk mengotomatisasi proses integrasi data
- Tambahkan sumber data lain seperti data media sosial atau data web analytics
- Buat dashboard real-time untuk monitoring performa bisnis