from pydantic import BaseModel, Field, ConfigDict
from typing import Optional
from .objectid import PyObjectId
from bson import ObjectId

class BookModel(BaseModel):
    id: PyObjectId = Field(default_factory=PyObjectId, alias="_id")
    title: str = Field(..., min_length=1, max_length=100)
    author: str = Field(..., min_length=1, max_length=50)
    price: float = Field(..., gt=0)
    description: Optional[str] = Field(None, max_length=500)

    model_config = ConfigDict(
        populate_by_name=True,
        arbitrary_types_allowed=True,
        json_encoders={ObjectId: str},
        json_schema_extra={
            "example": {
                "id": "507f1f77bcf86cd799439011",
                "title": "Clean Code",
                "author": "Robert C. Martin",
                "price": 39.99,
                "description": "A handbook of agile software craftsmanship"
            }
        }
    )
