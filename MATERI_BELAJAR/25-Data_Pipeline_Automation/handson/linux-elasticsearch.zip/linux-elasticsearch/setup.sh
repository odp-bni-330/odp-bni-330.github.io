#!/bin/bash

# Elasticsearch Setup Script untuk Linux
# Script ini akan mempersiapkan environment Linux untuk menjalankan Elasticsearch

set -euo pipefail

# Colors untuk output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m'

# Logging functions
log() { echo -e "${BLUE}[INFO]${NC} $1"; }
success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Detect OS
detect_os() {
    if [[ -f /etc/os-release ]]; then
        . /etc/os-release
        OS=$ID
        VERSION=$VERSION_ID
    else
        error "Cannot detect OS. This script supports Ubuntu, Debian, CentOS, RHEL, and Arch Linux."
        exit 1
    fi
    
    log "Detected OS: $OS $VERSION"
}

# Check if running as root
check_root() {
    if [[ $EUID -eq 0 ]]; then
        warning "Running as root. This script will create a non-root user for Docker."
        CREATE_USER=true
    else
        CREATE_USER=false
    fi
}

# Install Docker
install_docker() {
    log "Installing Docker..."
    
    case $OS in
        ubuntu|debian)
            # Update package list
            apt update
            
            # Install prerequisites
            apt install -y apt-transport-https ca-certificates curl gnupg lsb-release
            
            # Add Docker GPG key
            curl -fsSL https://download.docker.com/linux/$OS/gpg | gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg
            
            # Add Docker repository
            echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/$OS $(lsb_release -cs) stable" | tee /etc/apt/sources.list.d/docker.list > /dev/null
            
            # Install Docker
            apt update
            apt install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
            ;;
            
        centos|rhel|rocky|almalinux)
            # Install required packages
            yum install -y yum-utils
            
            # Add Docker repository
            yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
            
            # Install Docker
            yum install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
            ;;
            
        fedora)
            # Install Docker
            dnf install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
            ;;
            
        arch|manjaro)
            # Install Docker
            pacman -S --noconfirm docker docker-compose
            ;;
            
        *)
            error "Unsupported OS: $OS"
            exit 1
            ;;
    esac
    
    success "Docker installed successfully"
}

# Install Docker Compose (standalone version for older systems)
install_docker_compose() {
    if ! command -v docker-compose &> /dev/null; then
        log "Installing Docker Compose..."
        
        # Download latest version
        COMPOSE_VERSION=$(curl -s https://api.github.com/repos/docker/compose/releases/latest | grep tag_name | cut -d '"' -f 4)
        curl -L "https://github.com/docker/compose/releases/download/${COMPOSE_VERSION}/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
        
        # Make executable
        chmod +x /usr/local/bin/docker-compose
        
        # Create symlink if needed
        ln -sf /usr/local/bin/docker-compose /usr/bin/docker-compose
        
        success "Docker Compose installed successfully"
    else
        log "Docker Compose already installed"
    fi
}

# Install additional tools
install_tools() {
    log "Installing additional tools (curl, jq, htop)..."
    
    case $OS in
        ubuntu|debian)
            apt install -y curl jq htop net-tools
            ;;
        centos|rhel|rocky|almalinux)
            yum install -y curl jq htop net-tools
            ;;
        fedora)
            dnf install -y curl jq htop net-tools
            ;;
        arch|manjaro)
            pacman -S --noconfirm curl jq htop net-tools
            ;;
    esac
    
    success "Additional tools installed"
}

# Configure system for Elasticsearch
configure_system() {
    log "Configuring system for Elasticsearch..."
    
    # Set vm.max_map_count
    log "Setting vm.max_map_count to 262144"
    sysctl -w vm.max_map_count=262144
    
    # Make it permanent
    if ! grep -q "vm.max_map_count" /etc/sysctl.conf; then
        echo "vm.max_map_count=262144" >> /etc/sysctl.conf
        success "vm.max_map_count set permanently"
    else
        success "vm.max_map_count already configured"
    fi
    
    # Disable swap (recommended for Elasticsearch)
    log "Disabling swap..."
    swapoff -a
    
    # Comment out swap in fstab
    sed -i '/ swap / s/^\(.*\)$/#\1/g' /etc/fstab
    success "Swap disabled"
    
    # Set file descriptor limits
    log "Configuring file descriptor limits..."
    cat > /etc/security/limits.d/elasticsearch.conf << 'EOF'
* soft nofile 65536
* hard nofile 65536
* soft memlock unlimited
* hard memlock unlimited
EOF
    
    success "File descriptor limits configured"
}

# Configure Docker
configure_docker() {
    log "Configuring Docker..."
    
    # Start and enable Docker service
    systemctl start docker
    systemctl enable docker
    
    # Configure Docker daemon
    mkdir -p /etc/docker
    cat > /etc/docker/daemon.json << 'EOF'
{
    "log-driver": "json-file",
    "log-opts": {
        "max-size": "10m",
        "max-file": "3"
    },
    "storage-driver": "overlay2"
}
EOF
    
    # Restart Docker to apply configuration
    systemctl restart docker
    
    success "Docker configured and started"
}

# Create or configure user
setup_user() {
    if [[ $CREATE_USER == true ]]; then
        log "Creating elasticsearch user..."
        useradd -m -s /bin/bash elasticsearch
        usermod -aG docker elasticsearch
        success "User 'elasticsearch' created and added to docker group"
        
        # Copy project files
        if [[ -d "/root/linux-elasticsearch" ]]; then
            cp -r /root/linux-elasticsearch /home/elasticsearch/
            chown -R elasticsearch:elasticsearch /home/elasticsearch/linux-elasticsearch
        fi
    else
        log "Adding current user to docker group..."
        usermod -aG docker $USER
        success "User $USER added to docker group"
    fi
}

# Test installation
test_installation() {
    log "Testing installation..."
    
    # Test Docker
    if docker --version > /dev/null 2>&1; then
        success "Docker is working"
    else
        error "Docker installation failed"
        return 1
    fi
    
    # Test Docker Compose
    if docker-compose --version > /dev/null 2>&1; then
        success "Docker Compose is working"
    else
        error "Docker Compose installation failed"
        return 1
    fi
    
    # Test system configuration
    local max_map_count=$(sysctl vm.max_map_count | awk '{print $3}')
    if [[ $max_map_count -ge 262144 ]]; then
        success "vm.max_map_count is properly configured: $max_map_count"
    else
        warning "vm.max_map_count might be too low: $max_map_count"
    fi
    
    success "All tests passed!"
}

# Create monitoring script
create_monitoring_script() {
    log "Creating monitoring script..."
    
    cat > monitor_elasticsearch.sh << 'EOF'
#!/bin/bash

# Elasticsearch Monitoring Script

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

check_service() {
    local service=$1
    local port=$2
    
    if curl -s -f "http://localhost:$port" > /dev/null 2>&1; then
        echo -e "${GREEN}✓${NC} $service is running on port $port"
        return 0
    else
        echo -e "${RED}✗${NC} $service is not responding on port $port"
        return 1
    fi
}

echo -e "${BLUE}=== Elasticsearch Monitoring ===${NC}"
echo "Timestamp: $(date)"
echo

# Check services
check_service "Elasticsearch" "9200"
check_service "Kibana" "5601"

echo

# Check Elasticsearch cluster health
if curl -s "http://localhost:9200/_cluster/health" > /dev/null 2>&1; then
    echo -e "${BLUE}Cluster Health:${NC}"
    curl -s "http://localhost:9200/_cluster/health?pretty" | jq -r '
        "Status: \(.status)",
        "Nodes: \(.number_of_nodes)",
        "Active Shards: \(.active_shards)",
        "Relocating Shards: \(.relocating_shards)",
        "Unassigned Shards: \(.unassigned_shards)"
    ' 2>/dev/null || curl -s "http://localhost:9200/_cluster/health?pretty"
    
    echo
    echo -e "${BLUE}Memory Usage:${NC}"
    curl -s "http://localhost:9200/_cat/nodes?h=name,heap.percent,ram.percent,cpu&format=json" | jq -r '
        .[] | "Heap: \(.["heap.percent"])%, RAM: \(.["ram.percent"])%, CPU: \(.cpu)%"
    ' 2>/dev/null || curl -s "http://localhost:9200/_cat/nodes?h=name,heap.percent,ram.percent,cpu&v"
fi

echo
echo -e "${BLUE}Docker Containers:${NC}"
docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}" | grep -E "(elasticsearch|kibana)"

echo
echo -e "${BLUE}System Resources:${NC}"
echo "Memory: $(free -h | awk '/^Mem:/ {print $3"/"$2}')"
echo "Disk: $(df -h . | awk 'NR==2 {print $3"/"$2" ("$5" used)"}')"
echo "Load: $(uptime | awk -F'load average:' '{print $2}')"
EOF

    chmod +x monitor_elasticsearch.sh
    success "Monitoring script created: monitor_elasticsearch.sh"
}

# Main function
main() {
    echo -e "${PURPLE}"
    echo "=========================================="
    echo "  Elasticsearch Linux Setup Script"
    echo "=========================================="
    echo -e "${NC}"
    
    # Check if running as root for system modifications
    if [[ $EUID -ne 0 ]]; then
        error "This script needs to run as root to configure the system."
        error "Please run: sudo $0"
        exit 1
    fi
    
    detect_os
    check_root
    
    log "Starting Elasticsearch environment setup..."
    
    # Install components
    install_docker
    install_docker_compose
    install_tools
    
    # Configure system
    configure_system
    configure_docker
    setup_user
    
    # Create additional scripts
    create_monitoring_script
    
    # Test everything
    test_installation
    
    echo
    success "Setup completed successfully!"
    echo
    echo -e "${YELLOW}Next steps:${NC}"
    echo "1. Log out and log back in (or run 'newgrp docker')"
    echo "2. Navigate to the linux-elasticsearch directory"
    echo "3. Run: chmod +x sample-data-script.sh"
    echo "4. Run: docker-compose up -d"
    echo "5. Run: ./sample-data-script.sh"
    echo "6. Access Kibana at http://localhost:5601"
    echo
    echo -e "${YELLOW}Monitoring:${NC}"
    echo "Use './monitor_elasticsearch.sh' to monitor the cluster"
    echo
    echo -e "${YELLOW}Documentation:${NC}"
    echo "Read hands-on-elasticsearch.md for detailed instructions"
}

# Run main function
main "$@" 