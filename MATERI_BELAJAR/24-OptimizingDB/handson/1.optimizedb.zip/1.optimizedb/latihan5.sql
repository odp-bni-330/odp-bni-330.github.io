-- DDL: Create Tables
-- Membuat tabel customers
CREATE TABLE IF NOT EXISTS customers (
    customer_id SERIAL PRIMARY KEY,
    customer_name VARCHAR(255) NOT NULL,
    status VARCHAR(50) DEFAULT 'active'
);

-- Membuat tabel products  
CREATE TABLE IF NOT EXISTS products (
    product_id SERIAL PRIMARY KEY,
    product_name VARCHAR(255) NOT NULL,
    category VARCHAR(100),
    price NUMERIC(12, 2)
);

-- Membuat tabel orders
CREATE TABLE IF NOT EXISTS orders (
    order_id SERIAL PRIMARY KEY,
    customer_id INTEGER,
    order_date DATE,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

-- Membuat tabel order_items
CREATE TABLE IF NOT EXISTS order_items (
    order_item_id SERIAL PRIMARY KEY,
    order_id INTEGER,
    product_id INTEGER,
    quantity INTEGER,
    unit_price NUMERIC(12, 2),
    FOREIGN KEY (order_id) REFERENCES orders(order_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

-- Sample Data
-- Insert data into customers
INSERT INTO customers (customer_name, status) VALUES
('Andi Wijaya', 'active'),
('Budi Santoso', 'active'),
('Cici Permata', 'active'),
('Dedi Rahman', 'inactive'),
('Eka Sari', 'active'),
('Fani Kusuma', 'active'),
('Gita Melani', 'active'),
('Hadi Nugroho', 'inactive'),
('Indra Yoga', 'active'),
('Joko Susilo', 'active');

-- Insert data into products
INSERT INTO products (product_name, category, price) VALUES
('iPhone 14 Smartphone', 'Electronics', 12000000.00),
('Samsung Galaxy S23 Smartphone', 'Electronics', 10000000.00),
('Xiaomi Redmi Note 12 Smartphone', 'Electronics', 3500000.00),
('OnePlus 11 Smartphone', 'Electronics', 8000000.00),
('Laptop Dell XPS 13', 'Electronics', 18000000.00),
('MacBook Air M2', 'Electronics', 16000000.00),
('Headphones Sony WH-1000XM4', 'Electronics', 4500000.00),
('Smart TV LG 55 inch', 'Electronics', 8500000.00),
('PlayStation 5', 'Electronics', 7500000.00),
('Nintendo Switch', 'Electronics', 4200000.00),
('Tablet iPad Air', 'Electronics', 9000000.00),
('Smartwatch Apple Watch Series 8', 'Electronics', 6000000.00),
('Keyboard Mechanical RGB', 'Electronics', 1200000.00),
('Mouse Gaming Logitech', 'Electronics', 800000.00),
('Monitor ASUS 27 inch', 'Electronics', 3500000.00);

-- Insert data into orders
INSERT INTO orders (customer_id, order_date) VALUES
(1, '2025-01-15'),
(1, '2025-02-20'),
(2, '2025-01-10'),
(2, '2025-03-05'),
(3, '2025-01-25'),
(3, '2025-04-10'),
(4, '2024-12-15'),
(5, '2025-02-08'),
(5, '2025-05-20'),
(6, '2025-01-30'),
(7, '2025-03-15'),
(8, '2024-11-20'),
(9, '2025-04-25'),
(10, '2025-06-10');

-- Insert data into order_items
INSERT INTO order_items (order_id, product_id, quantity, unit_price) VALUES
-- Order 1 (Andi)
(1, 1, 1, 12000000.00), -- iPhone 14
(1, 7, 1, 4500000.00),  -- Headphones Sony
-- Order 2 (Andi)
(2, 5, 1, 18000000.00), -- Laptop Dell
-- Order 3 (Budi)
(3, 2, 1, 10000000.00), -- Samsung Galaxy S23
(3, 14, 1, 800000.00),  -- Mouse Gaming
-- Order 4 (Budi)
(4, 8, 1, 8500000.00),  -- Smart TV LG
-- Order 5 (Cici)
(5, 3, 2, 3500000.00),  -- Xiaomi Smartphone (2 units)
-- Order 6 (Cici)
(6, 11, 1, 9000000.00), -- iPad Air
(6, 12, 1, 6000000.00), -- Apple Watch
-- Order 7 (Dedi - inactive customer)
(7, 9, 1, 7500000.00),  -- PlayStation 5
-- Order 8 (Eka)
(8, 4, 1, 8000000.00),  -- OnePlus 11
(8, 13, 1, 1200000.00), -- Keyboard Mechanical
-- Order 9 (Eka)
(9, 15, 2, 3500000.00), -- Monitor ASUS (2 units)
-- Order 10 (Fani)
(10, 6, 1, 16000000.00), -- MacBook Air
-- Order 11 (Gita)
(11, 10, 1, 4200000.00), -- Nintendo Switch
-- Order 12 (Hadi - inactive customer)
(12, 1, 1, 12000000.00), -- iPhone 14
-- Order 13 (Indra)
(13, 2, 1, 10000000.00), -- Samsung Galaxy S23
(13, 7, 1, 4500000.00),  -- Headphones Sony
-- Order 14 (Joko)
(14, 3, 1, 3500000.00), -- Xiaomi Smartphone
(14, 12, 1, 6000000.00); -- Apple Watch

-- Query 1: Analisis penjualan produk per pelanggan
SELECT   
    c.customer_name,  
    p.product_name,  
    SUM(oi.quantity * oi.unit_price) AS total_sales,  
    COUNT(oi.order_item_id) AS items_sold,
    COUNT(DISTINCT o.order_id) AS total_orders
FROM   
    customers c
INNER JOIN 
    orders o ON c.customer_id = o.customer_id
INNER JOIN 
    order_items oi ON oi.order_id = o.order_id
INNER JOIN 
    products p ON oi.product_id = p.product_id
WHERE   
    o.order_date BETWEEN '2025-01-01'::DATE AND '2025-06-30'::DATE
GROUP BY   
    c.customer_name, p.product_name
ORDER BY   
    total_sales DESC
LIMIT 20;

-- Membuat indeks untuk meningkatkan performa query
CREATE INDEX idx_order_date ON orders(order_date);
CREATE INDEX idx_customer_id ON orders(customer_id);
CREATE INDEX idx_product_id ON order_items(product_id);

-- Query 2: Analisis pelanggan aktif
SELECT   
    c.customer_name,  
    COUNT(DISTINCT o.order_id) AS total_orders,  
    SUM(oi.quantity * oi.unit_price) AS total_spent,  
    MAX(o.order_date) AS last_order_date
FROM   
    customers c
LEFT JOIN 
    orders o ON c.customer_id = o.customer_id
LEFT JOIN 
    order_items oi ON oi.order_id = o.order_id
WHERE   
    c.status = 'active'
GROUP BY   
    c.customer_id, c.customer_name
ORDER BY   
    total_spent DESC
LIMIT 10;

-- Membuat indeks untuk kolom yang sering digunakan dalam filter dan join
CREATE INDEX idx_customer_status ON customers(status);
CREATE INDEX idx_customer_id_orders ON orders(customer_id);
CREATE INDEX idx_order_date_idx ON orders(order_date);

-- Query 3: Analisis produk smartphone
SELECT   
    p.product_name,  
    p.category,  
    p.price,  
    COUNT(oi.order_item_id) AS times_ordered
FROM   
    products p
LEFT JOIN 
    order_items oi ON oi.product_id = p.product_id
WHERE   
    LOWER(p.product_name) LIKE '%smartphone%'  
    AND p.category = 'Electronics'  
    AND p.price BETWEEN 1000000 AND 5000000
GROUP BY   
    p.product_id, p.product_name, p.category, p.price
ORDER BY   
    times_ordered DESC
LIMIT 20;

-- Membuat indeks pada kolom yang sering digunakan untuk pencarian dan filter
CREATE INDEX idx_product_name ON products(product_name);
CREATE INDEX idx_product_category ON products(category);
CREATE INDEX idx_product_price ON products(price);