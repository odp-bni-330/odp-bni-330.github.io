# ELK Stack Demo - Windows PowerShell Version
# Elasticsearch + Logstash + Kibana + Filebeat Demo

param(
    [Parameter(Position=0)]
    [ValidateSet("start", "stop", "restart", "logs", "status", "help")]
    [string]$Action = "start"
)

# Color functions for better output
function Write-ColorOutput {
    param(
        [string]$Message,
        [string]$Color = "White"
    )
    
    switch ($Color) {
        "Red" { Write-Host $Message -ForegroundColor Red }
        "Green" { Write-Host $Message -ForegroundColor Green }
        "Yellow" { Write-Host $Message -ForegroundColor Yellow }
        "Blue" { Write-Host $Message -ForegroundColor Blue }
        "Magenta" { Write-Host $Message -ForegroundColor Magenta }
        "Cyan" { Write-Host $Message -ForegroundColor Cyan }
        default { Write-Host $Message }
    }
}

function Write-Step {
    param([string]$Message)
    Write-ColorOutput "🔧 $Message" -Color "Blue"
}

function Write-Success {
    param([string]$Message)
    Write-ColorOutput "✅ $Message" -Color "Green"
}

function Write-Info {
    param([string]$Message)
    Write-ColorOutput "ℹ️  $Message" -Color "Cyan"
}

function Write-Warning {
    param([string]$Message)
    Write-ColorOutput "⚠️  $Message" -Color "Yellow"
}

function Write-Error {
    param([string]$Message)
    Write-ColorOutput "❌ $Message" -Color "Red"
}

# Banner
Write-ColorOutput @"
╔══════════════════════════════════════════════════════════════╗
║                     ELK Stack Demo                          ║
║          Elasticsearch + Logstash + Kibana + Filebeat       ║
║                    Windows Version                          ║
╚══════════════════════════════════════════════════════════════╝
"@ -Color "Magenta"

# Check if Docker is running
function Test-Docker {
    Write-Step "Checking Docker..."
    try {
        docker info | Out-Null
        Write-Success "Docker is running"
        return $true
    } catch {
        Write-Error "Docker is not running! Please start Docker Desktop first."
        return $false
    }
}

# Check if Docker Compose is available
function Test-DockerCompose {
    Write-Step "Checking Docker Compose..."
    try {
        $output = docker compose version 2>$null
        if ($output) {
            Write-Success "Docker Compose is available"
            return $true
        } else {
            $output = docker-compose --version 2>$null
            if ($output) {
                Write-Success "Docker Compose (legacy) is available"
                return $true
            } else {
                Write-Error "Docker Compose not found! Please install Docker Compose."
                return $false
            }
        }
    } catch {
        Write-Error "Docker Compose not found! Please install Docker Compose."
        return $false
    }
}

# Clean up old containers
function Remove-OldContainers {
    Write-Step "Cleaning up old containers..."
    try {
        docker compose down -v --remove-orphans 2>$null
        Write-Success "Old containers cleaned up"
    } catch {
        Write-Info "No containers to clean up"
    }
}

# Start ELK Stack
function Start-ELKStack {
    Write-Step "Building and starting ELK Stack..."
    try {
        docker compose up -d
        Write-Success "ELK Stack containers started"
    } catch {
        Write-Error "Failed to start ELK Stack"
        exit 1
    }
}

# Wait for services to be ready
function Wait-ForServices {
    Write-Step "Waiting for services to be ready..."
    
    Write-Info "Waiting for Elasticsearch..."
    $retryCount = 0
    $maxRetries = 30
    do {
        try {
            $response = Invoke-WebRequest -Uri "http://localhost:9200" -TimeoutSec 2 -ErrorAction SilentlyContinue
            if ($response.StatusCode -eq 200) {
                break
            }
        } catch {
            # Continue waiting
        }
        Start-Sleep -Seconds 5
        Write-Host "." -NoNewline
        $retryCount++
    } while ($retryCount -lt $maxRetries)
    
    if ($retryCount -ge $maxRetries) {
        Write-Error "Elasticsearch failed to start within timeout"
        exit 1
    }
    Write-Success "Elasticsearch is ready!"
    
    Write-Info "Waiting for Kibana..."
    $retryCount = 0
    do {
        try {
            $response = Invoke-WebRequest -Uri "http://localhost:5601" -TimeoutSec 2 -ErrorAction SilentlyContinue
            if ($response.StatusCode -eq 200) {
                break
            }
        } catch {
            # Continue waiting
        }
        Start-Sleep -Seconds 5
        Write-Host "." -NoNewline
        $retryCount++
    } while ($retryCount -lt $maxRetries)
    
    if ($retryCount -ge $maxRetries) {
        Write-Error "Kibana failed to start within timeout"
        exit 1
    }
    Write-Success "Kibana is ready!"
}

# Create index pattern in Kibana
function New-KibanaIndexPattern {
    Write-Step "Creating index pattern in Kibana..."
    
    # Wait for data to be ingested
    Start-Sleep -Seconds 10
    
    try {
        $headers = @{
            "kbn-xsrf" = "true"
            "Content-Type" = "application/json"
        }
        
        $body = @{
            attributes = @{
                title = "demo-logs-*"
                timeFieldName = "@timestamp"
            }
        } | ConvertTo-Json
        
        Invoke-RestMethod -Uri "http://localhost:5601/api/saved_objects/index-pattern" -Method Post -Headers $headers -Body $body -ErrorAction SilentlyContinue | Out-Null
        Write-Success "Index pattern created (demo-logs-*)"
    } catch {
        Write-Info "Index pattern might already exist or will be created automatically"
    }
}

# Show service status
function Show-ServiceStatus {
    Write-Step "Service status:"
    docker compose ps
}

# Show access URLs
function Show-AccessUrls {
    Write-ColorOutput @"

🌐 Service Access URLs:
   📊 Kibana Dashboard: http://localhost:5601
   🔍 Elasticsearch:    http://localhost:9200
   ⚙️  Logstash:         http://localhost:9600

"@ -Color "Green"
}

# Start log generator
function Start-LogGenerator {
    Write-Step "Starting log generator..."
    
    if (Test-Path "scripts\generate_logs.ps1") {
        Write-Info "Log generator will run in background..."
        Write-Info "Log files will be updated in real-time"
        
        # Start log generator as background job
        $job = Start-Job -ScriptBlock {
            Set-Location $using:PWD
            & ".\scripts\generate_logs.ps1"
        }
        
        $job.Id | Out-File -FilePath "log_generator.pid" -Encoding UTF8
        Write-Success "Log generator started (Job ID: $($job.Id))"
    } else {
        Write-Warning "Log generator script not found, creating it..."
        New-LogGeneratorScript
        Start-LogGenerator
    }
}

# Stop log generator
function Stop-LogGenerator {
    if (Test-Path "log_generator.pid") {
        $jobId = Get-Content "log_generator.pid" -Raw
        $jobId = $jobId.Trim()
        
        try {
            $job = Get-Job -Id $jobId -ErrorAction SilentlyContinue
            if ($job) {
                Stop-Job -Id $jobId
                Remove-Job -Id $jobId
                Write-Success "Log generator stopped"
            }
        } catch {
            Write-Info "Log generator was not running"
        }
        
        Remove-Item "log_generator.pid" -ErrorAction SilentlyContinue
    }
}

# Create log generator script if it doesn't exist
function New-LogGeneratorScript {
    $scriptContent = @'
# Log Generator Script for ELK Stack Demo - Windows Version
Write-Host "🚀 Starting log generator..."
Write-Host "📁 Log directory: .\logs"
Write-Host "⏹️  Press Ctrl+C to stop"

$IPs = @("192.168.1.100", "10.0.0.50", "203.0.113.45", "172.16.0.25", "198.51.100.33", "127.0.0.1")
$ApachePaths = @("/index.html", "/products.html", "/about.html", "/contact.html", "/search", "/api/login", "/dashboard", "/images/logo.png")
$NginxPaths = @("/api/v1/users", "/api/v1/orders", "/health", "/metrics", "/api/v1/products", "/webhook", "/api/v1/logs")
$Methods = @("GET", "POST", "PUT", "DELETE", "PATCH")
$StatusCodes = @("200", "201", "204", "302", "400", "404", "500")
$UserAgents = @(
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36",
    "curl/7.68.0",
    "PostmanRuntime/7.28.4",
    "Prometheus/2.30.3"
)
$LogLevels = @("INFO", "DEBUG", "WARN", "ERROR")
$LogMessages = @(
    "User authentication successful",
    "Database connection established",
    "Cache hit for user data",
    "API request processed successfully",
    "Background job completed",
    "High memory usage detected",
    "Slow query detected",
    "Rate limit approaching",
    "Database deadlock detected",
    "Payment processing completed"
)

function Add-ApacheLog {
    $ip = $IPs | Get-Random
    $path = $ApachePaths | Get-Random
    $method = $Methods | Get-Random
    $status = $StatusCodes | Get-Random
    $size = Get-Random -Minimum 100 -Maximum 10000
    $userAgent = $UserAgents | Get-Random
    $timestamp = Get-Date -Format "dd/MMM/yyyy:HH:mm:ss zzz"
    
    $logEntry = "$ip - - [$timestamp] `"$method $path HTTP/1.1`" $status $size `"http://example.com/`" `"$userAgent`""
    Add-Content -Path "logs\apache\access.log" -Value $logEntry
}

function Add-NginxLog {
    $ip = $IPs | Get-Random
    $path = $NginxPaths | Get-Random
    $method = $Methods | Get-Random
    $status = $StatusCodes | Get-Random
    $size = Get-Random -Minimum 50 -Maximum 5000
    $userAgent = $UserAgents | Get-Random
    $timestamp = Get-Date -Format "dd/MMM/yyyy:HH:mm:ss zzz"
    
    $logEntry = "$ip - - [$timestamp] `"$method $path HTTP/1.1`" $status $size `"http://api.example.com/`" `"$userAgent`""
    Add-Content -Path "logs\nginx\access.log" -Value $logEntry
}

function Add-ApplicationLog {
    $level = $LogLevels | Get-Random
    $message = $LogMessages | Get-Random
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss,fff"
    
    $logEntry = "[$timestamp] $level`: $message"
    Add-Content -Path "logs\application\app.log" -Value $logEntry
}

# Main loop
while ($true) {
    if ((Get-Random -Maximum 3) -eq 0) {
        Add-ApacheLog
        Write-Host "✅ Apache log generated"
    }
    
    if ((Get-Random -Maximum 4) -eq 0) {
        Add-NginxLog
        Write-Host "✅ Nginx log generated"
    }
    
    if ((Get-Random -Maximum 5) -eq 0) {
        Add-ApplicationLog
        Write-Host "✅ Application log generated"
    }
    
    Start-Sleep -Seconds (Get-Random -Minimum 2 -Maximum 5)
}
'@
    
    New-Item -Path "scripts\generate_logs.ps1" -ItemType File -Value $scriptContent -Force | Out-Null
}

# Shutdown demo
function Stop-Demo {
    Write-Step "Stopping demo..."
    Stop-LogGenerator
    docker compose down
    Write-Success "Demo stopped"
}

# Show help
function Show-Help {
    Write-ColorOutput @"

Available commands:
  start   - Start ELK Stack demo
  stop    - Stop demo
  restart - Restart demo
  logs    - Show container logs
  status  - Show container status
  help    - Show this help

Usage: .\run-elk-demo.ps1 [command]

"@ -Color "Cyan"
}

# Main demo start function
function Start-Demo {
    Write-Step "Starting ELK Stack Demo..."
    
    if (-not (Test-Docker)) { exit 1 }
    if (-not (Test-DockerCompose)) { exit 1 }
    
    Remove-OldContainers
    Start-ELKStack
    Wait-ForServices
    Start-LogGenerator
    New-KibanaIndexPattern
    Show-ServiceStatus
    Show-AccessUrls
    
    Write-ColorOutput @"

🎉 ELK Stack Demo successfully started!

📝 Next steps:
   1. Open Kibana at http://localhost:5601
   2. Go to Analytics > Discover
   3. Select index pattern 'demo-logs-*'
   4. View real-time logs coming in
   5. Create visualizations and dashboards

⏹️  To stop demo: .\run-elk-demo.ps1 stop

"@ -Color "Green"
}

# Main script logic
switch ($Action) {
    "start" { Start-Demo }
    "stop" { Stop-Demo }
    "restart" { 
        Stop-Demo
        Start-Sleep -Seconds 2
        Start-Demo
    }
    "logs" { docker compose logs -f }
    "status" { Show-ServiceStatus }
    "help" { Show-Help }
    default {
        Write-Error "Unknown command: $Action"
        Show-Help
        exit 1
    }
} 