# Database Fix Documentation - Windows Edition

## Problem
The application was showing errors like:
```
Error fetching combined dashboard data: error: relation "sales" does not exist
```

This indicated that the PostgreSQL database tables were not properly created in the Neon cloud database.

## Root Cause
1. **Missing Tables**: The `products` and `sales` tables were not created in the Neon PostgreSQL database
2. **Decimal Overflow**: The original SQL had `DECIMAL(10,2)` fields that couldn't handle the large Indonesian Rupiah values (e.g., 180,000,000.00)
3. **Manual Setup Process**: The original setup required manual execution of SQL in the Neon console

## Solution Applied

### 1. Fixed Decimal Precision
Updated table definitions to handle larger values:
```sql
-- Before
price DECIMAL(10,2)        -- Max: 99,999,999.99
total_amount DECIMAL(10,2)  -- Max: 99,999,999.99

-- After  
price DECIMAL(12,2)        -- Max: 9,999,999,999.99
total_amount DECIMAL(15,2)  -- Max: 9,999,999,999,999.99
```

### 2. Created Automated Setup Script
Created `setup-postgres-auto.js` that:
- Connects directly to Neon PostgreSQL
- Executes the SQL setup script programmatically
- Verifies table creation and data insertion
- Provides detailed feedback and error handling
- **Windows-compatible**: Handles Windows console color support

### 3. Added Windows Quick Fix Scripts
Created **TWO** Windows scripts for maximum compatibility:

#### Batch File (`fix-database.bat`)
- Traditional Windows batch file
- Works in Command Prompt
- UTF-8 encoding for emoji support
- Automatic error handling

#### PowerShell Script (`fix-database.ps1`)
- Modern PowerShell implementation
- Better error handling and color support
- REST API testing capabilities
- Process management features

## Files Modified

### Core Files
- `setup-databases.sql` - Fixed decimal precision issues
- `setup-postgres-auto.js` - New automated PostgreSQL setup (Windows-compatible)
- `fix-database.bat` - Windows batch script for one-command fix
- `fix-database.ps1` - PowerShell script for enhanced Windows experience

### Dependencies
- `package.json` - Already included `pg` dependency

## How to Use

### Quick Fix Options

#### Option 1: Batch File (Simple)
```cmd
fix-database.bat
```

#### Option 2: PowerShell (Recommended)
```powershell
.\fix-database.ps1
```

#### Option 3: Command Line (Individual steps)
```cmd
# Install dependencies
npm install

# Setup PostgreSQL
node setup-postgres-auto.js

# Setup MongoDB
node setup-mongodb.js

# Test the application
demo.bat start
```

### PowerShell Execution Policy
If you get execution policy errors, run this first:
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

## Windows-Specific Features

### 1. Console Encoding
Both scripts set UTF-8 encoding for proper emoji display:
- Batch: `chcp 65001`
- PowerShell: `[Console]::OutputEncoding = [System.Text.Encoding]::UTF8`

### 2. Color Support Detection
The Node.js script detects Windows and adjusts color output accordingly:
```javascript
if (process.platform === 'win32') {
    // Windows-specific color handling
}
```

### 3. Process Management
PowerShell script includes proper background process management:
- Starts demo in background
- Tracks process for cleanup
- Graceful shutdown handling

### 4. Error Handling
Enhanced Windows error handling:
- Exit codes for batch scripts
- Try-catch blocks in PowerShell
- Proper cleanup of temporary files

## Verification

After running the fix, you should see:
1. ✅ PostgreSQL tables created with sample data
2. ✅ MongoDB collections created with sample data
3. ✅ Health endpoint returns both databases as "healthy"
4. ✅ All API endpoints return data successfully

### Test Endpoints (Windows)
```cmd
# Health check
curl http://localhost:3000/api/health

# PostgreSQL data
curl http://localhost:3000/api/postgres/sales

# MongoDB data  
curl http://localhost:3000/api/mongodb/customers

# Combined data
curl http://localhost:3000/api/combined/dashboard
```

### PowerShell Testing
```powershell
# Health check
Invoke-RestMethod -Uri "http://localhost:3000/api/health"

# PostgreSQL data
Invoke-RestMethod -Uri "http://localhost:3000/api/postgres/sales"
```

## Sample Data Overview

### PostgreSQL
- **Products**: 10 Indonesian tech products with realistic IDR prices
- **Sales**: 30 sales transactions across 6 months (Jan-Jun 2024)
- **Total Sales**: ~1.7 billion IDR

### MongoDB
- **Customers**: 5 customers from Indonesian cities
- **Interactions**: 7 customer interaction records

## Database Connection Details

### PostgreSQL (Neon)
- Host: `ep-falling-cake-a1j2rvpd-pooler.ap-southeast-1.aws.neon.tech`
- Database: `neondb`
- SSL: Required

### MongoDB (Atlas)
- Connection: Atlas cluster with SSL
- Database: `demo_db`
- Collections: `customers`, `interactions`

## Windows-Specific Troubleshooting

### Common Windows Issues

1. **"relation does not exist"**
   - Solution: Run `node setup-postgres-auto.js`

2. **"numeric field overflow"** 
   - Solution: Fixed in updated SQL with larger DECIMAL fields

3. **"MODULE_NOT_FOUND: pg"**
   - Solution: Run `npm install`

4. **PowerShell execution policy error**
   - Solution: `Set-ExecutionPolicy RemoteSigned -Scope CurrentUser`

5. **Emoji/Unicode display issues**
   - Solution: Scripts automatically set UTF-8 encoding

6. **Windows Defender/Antivirus blocking**
   - Solution: Temporarily disable or add exception for Node.js

### Windows-Specific Commands

#### Command Prompt
```cmd
# Run batch fix
fix-database.bat

# Start demo
demo.bat start

# Check logs
demo.bat logs webapp
```

#### PowerShell
```powershell
# Run PowerShell fix
.\fix-database.ps1

# Start demo
.\demo.ps1 start

# Check with REST calls
Invoke-RestMethod -Uri "http://localhost:3000/api/health"
```

### Environment Variables (Windows)
```cmd
# Set environment variables for Windows
set POSTGRES_HOST=ep-falling-cake-a1j2rvpd-pooler.ap-southeast-1.aws.neon.tech
set POSTGRES_DB=neondb
set MONGODB_URL=mongodb+srv://user:pass@cluster.mongodb.net/demo_db
```

## Performance Notes

- **Windows Defender**: May slow down npm installs and Node.js execution
- **PowerShell**: Generally faster than Command Prompt for REST operations
- **WSL**: Consider using Windows Subsystem for Linux for better performance

## Support

For Windows-specific issues:
1. Check Windows version compatibility (Windows 10/11 recommended)
2. Ensure Node.js is properly installed and in PATH
3. Verify Docker Desktop is running (for containerized demos)
4. Check Windows Firewall settings for port 3000

---

🎉 **Once setup is complete, you can run the full demo with `demo.bat start` or `.\demo.ps1 start`** 