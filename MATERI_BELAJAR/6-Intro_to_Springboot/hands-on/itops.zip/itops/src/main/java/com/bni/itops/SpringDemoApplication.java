package com.bni.itops;

import java.util.ArrayList;
import java.util.List;	//tambahan

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping; //tambahan
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;	//tambahan
import org.springframework.web.bind.annotation.RestController;	//tambahan

// @xxx -> anotasi
//Spring Boot Annotations are a form of metadata that provides data about a spring application

/**
 * 		Layer visualized:
 * 		client -> [[Controller]->[Data]]
 * 
 */

/****************** CONTROLLER LAYER/MODEL ******************/

@SpringBootApplication
@RestController
@RequestMapping("/api/tasks")
public class SpringDemoApplication {
	// array of task : tasks
    private List<Task> tasks = new ArrayList<>();
	// id task dari elemen task yang akan disimpan di array tasks
    private long nextId = 1;

    public static void main(String[] args) {
        SpringApplication.run(SpringDemoApplication.class, args);
    }

    // POST (Create)
    @PostMapping
    public ResponseEntity<Task> createTask(@RequestBody Task task) {

	// validasi input
	if (task.getTitle() == null || task.getTitle().isEmpty()){
		return ResponseEntity.badRequest().build();
	}

		/*** PROSES INI SEHARUSNYA DIBUAT DI SATU LAYER BARU : SERVICE ***/
        task.setId(nextId++);	// set ID task yang akan ditambahkan ke array tasks
        tasks.add(task);		// simpan task ke array tasks
		/*****************************************************************/

        return ResponseEntity.status(HttpStatus.CREATED).body(task); // return code : 201
    }

    // GET All
    @GetMapping
    public ResponseEntity<List<Task>> getAllTasks() {
        return ResponseEntity.ok(tasks);
    }

    // GET by ID
    @GetMapping("/{id}")
    public ResponseEntity<Task> getTaskById(@PathVariable Long id) {
        Task task = tasks.stream()
                .filter(t -> t.getId().equals(id))
                .findFirst()
                .orElse(null);
        return task != null ? ResponseEntity.ok(task) : ResponseEntity.notFound().build();
    }

    // PUT (Update)
    @PutMapping("/{id}")
    public ResponseEntity<Task> updateTask(@PathVariable Long id, @RequestBody Task updatedTask) {
        Task existingTask = tasks.stream()
                .filter(t -> t.getId().equals(id))
                .findFirst()
                .orElse(null);
        if (existingTask == null) {
            return ResponseEntity.notFound().build();
        }
        existingTask.setTitle(updatedTask.getTitle());
        existingTask.setDescription(updatedTask.getDescription());
        existingTask.setCompleted(updatedTask.getCompleted());
        return ResponseEntity.ok(existingTask);
    }

    // DELETE (Opsional)
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTask(@PathVariable Long id) {
        boolean removed = tasks.removeIf(task -> task.getId().equals(id));
        return removed ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }
}

/****************** DATA LAYER/MODEL ******************/
// untuk konversi input (JSON) menjadi java class
class Task {
    private Long id;
	private String title;
	private String description;
	private Boolean completed;

	public Task(){
	}

	public Task(String title, String description, boolean completed)
	{
		this.title = title;
		this.description = description;
		this.completed = completed;
	}

	// getter and stter 
	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Boolean isCompleted() {
		return this.completed;
	}

	public Boolean getCompleted() {
		return this.completed;
	}

	public void setCompleted(Boolean completed) {
		this.completed = completed;
	}

	
}
