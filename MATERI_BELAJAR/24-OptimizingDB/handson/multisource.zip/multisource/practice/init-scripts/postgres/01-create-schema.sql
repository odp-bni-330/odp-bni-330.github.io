-- Create practice database schema for PostgreSQL
-- Tables: customers, orders, products, order_items

-- Create customers table
CREATE TABLE customers (
    customer_id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(20),
    address TEXT,
    city VARCHAR(100),
    country VARCHAR(100),
    registration_date DATE DEFAULT CURRENT_DATE,
    last_login TIMESTAMP,
    status VARCHAR(20) DEFAULT 'active'
);

-- Create products table
CREATE TABLE products (
    product_id SERIAL PRIMARY KEY,
    product_name VARCHAR(255) NOT NULL,
    category VARCHAR(100) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    description TEXT,
    stock_quantity INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create orders table
CREATE TABLE orders (
    order_id SERIAL PRIMARY KEY,
    customer_id INTEGER NOT NULL REFERENCES customers(customer_id),
    order_date DATE NOT NULL DEFAULT CURRENT_DATE,
    total_amount DECIMAL(10, 2) NOT NULL,
    status VARCHAR(50) DEFAULT 'pending',
    shipping_address TEXT,
    payment_method VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create order_items table (for order details)
CREATE TABLE order_items (
    item_id SERIAL PRIMARY KEY,
    order_id INTEGER NOT NULL REFERENCES orders(order_id),
    product_id INTEGER NOT NULL REFERENCES products(product_id),
    quantity INTEGER NOT NULL,
    unit_price DECIMAL(10, 2) NOT NULL,
    subtotal DECIMAL(10, 2) NOT NULL
);

-- Insert sample customers
INSERT INTO customers (name, email, phone, address, city, country, registration_date, last_login, status) VALUES
('John Doe', 'john.doe@email.com', '+62-812-3456-7890', 'Jl. Sudirman No. 1', 'Jakarta', 'Indonesia', '2023-01-15', '2024-03-01 10:30:00', 'active'),
('Jane Smith', 'jane.smith@email.com', '+62-813-4567-8901', 'Jl. Thamrin No. 2', 'Jakarta', 'Indonesia', '2023-02-10', '2024-02-28 15:45:00', 'active'),
('Michael Johnson', 'michael.johnson@email.com', '+62-814-5678-9012', 'Jl. Asia Afrika No. 3', 'Bandung', 'Indonesia', '2023-03-05', '2024-02-29 09:20:00', 'active'),
('Sarah Wilson', 'sarah.wilson@email.com', '+62-815-6789-0123', 'Jl. Gatot Subroto No. 4', 'Medan', 'Indonesia', '2023-04-12', '2024-02-27 14:15:00', 'active'),
('David Brown', 'david.brown@email.com', '+62-816-7890-1234', 'Jl. Malioboro No. 5', 'Yogyakarta', 'Indonesia', '2023-05-20', '2024-02-26 11:30:00', 'active'),
('Lisa Anderson', 'lisa.anderson@email.com', '+62-817-8901-2345', 'Jl. Pemuda No. 6', 'Semarang', 'Indonesia', '2023-06-08', '2024-02-25 16:45:00', 'active'),
('Robert Taylor', 'robert.taylor@email.com', '+62-818-9012-3456', 'Jl. Ijen No. 7', 'Malang', 'Indonesia', '2023-07-15', '2024-02-24 13:20:00', 'active'),
('Emily Davis', 'emily.davis@email.com', '+62-819-0123-4567', 'Jl. Sunset Road No. 8', 'Denpasar', 'Indonesia', '2023-08-22', '2024-02-23 12:10:00', 'active'),
('Christopher Miller', 'christopher.miller@email.com', '+62-820-1234-5678', 'Jl. Sam Ratulangi No. 9', 'Makassar', 'Indonesia', '2023-09-10', '2024-02-22 17:30:00', 'active'),
('Amanda Wilson', 'amanda.wilson@email.com', '+62-821-2345-6789', 'Jl. Sudirman No. 10', 'Palembang', 'Indonesia', '2023-10-05', '2024-02-21 08:45:00', 'active'),
('James Moore', 'james.moore@email.com', '+62-822-3456-7890', 'Jl. MH Thamrin No. 11', 'Jakarta', 'Indonesia', '2023-11-12', '2024-02-20 19:15:00', 'active'),
('Michelle Garcia', 'michelle.garcia@email.com', '+62-823-4567-8901', 'Jl. Basuki Rahmat No. 12', 'Surabaya', 'Indonesia', '2023-12-01', '2024-02-19 10:30:00', 'active');

-- Insert sample products
INSERT INTO products (product_name, category, price, description, stock_quantity) VALUES
('MacBook Pro 14"', 'Electronics', 2999.99, 'Apple MacBook Pro with M3 chip', 25),
('iPhone 15 Pro', 'Electronics', 1199.99, 'Latest iPhone with Pro camera system', 50),
('Samsung Galaxy S24', 'Electronics', 899.99, 'Android flagship smartphone', 40),
('Nike Air Max 270', 'Fashion', 149.99, 'Comfortable running shoes', 100),
('Adidas Ultraboost 22', 'Fashion', 179.99, 'Premium running shoes with Boost technology', 80),
('Sony WH-1000XM5', 'Electronics', 399.99, 'Noise-canceling wireless headphones', 60),
('The Great Gatsby', 'Books', 12.99, 'Classic American novel by F. Scott Fitzgerald', 200),
('Yoga Mat Premium', 'Sports', 49.99, 'Non-slip yoga mat for all fitness levels', 150),
('Coffee Maker Deluxe', 'Home', 299.99, 'Programmable coffee maker with grinder', 30),
('Protein Powder Whey', 'Health', 39.99, 'High-quality whey protein supplement', 75);

-- Insert sample orders (last 12 months)
INSERT INTO orders (customer_id, order_date, total_amount, status, shipping_address, payment_method) VALUES
(1, '2024-01-15', 2999.99, 'completed', 'Jl. Sudirman No. 1, Jakarta', 'credit_card'),
(2, '2024-01-16', 1349.98, 'completed', 'Jl. Thamrin No. 2, Jakarta', 'debit_card'),
(3, '2024-01-17', 899.99, 'completed', 'Jl. Asia Afrika No. 3, Bandung', 'bank_transfer'),
(4, '2024-01-18', 449.97, 'completed', 'Jl. Gatot Subroto No. 4, Medan', 'credit_card'),
(5, '2024-01-19', 359.98, 'completed', 'Jl. Malioboro No. 5, Yogyakarta', 'e_wallet'),
(6, '2024-01-20', 299.99, 'completed', 'Jl. Pemuda No. 6, Semarang', 'credit_card'),
(7, '2024-02-01', 399.99, 'completed', 'Jl. Ijen No. 7, Malang', 'bank_transfer'),
(8, '2024-02-02', 199.98, 'completed', 'Jl. Sunset Road No. 8, Denpasar', 'debit_card'),
(9, '2024-02-03', 39.99, 'completed', 'Jl. Sam Ratulangi No. 9, Makassar', 'e_wallet'),
(10, '2024-02-04', 49.99, 'completed', 'Jl. Sudirman No. 10, Palembang', 'credit_card'),
(11, '2023-08-15', 1199.99, 'completed', 'Jl. MH Thamrin No. 11, Jakarta', 'credit_card'),
(12, '2023-09-10', 329.97, 'completed', 'Jl. Basuki Rahmat No. 12, Surabaya', 'bank_transfer'),
(1, '2023-10-05', 149.99, 'completed', 'Jl. Sudirman No. 1, Jakarta', 'credit_card'),
(2, '2023-11-20', 79.98, 'completed', 'Jl. Thamrin No. 2, Jakarta', 'debit_card'),
(3, '2023-12-15', 899.99, 'completed', 'Jl. Asia Afrika No. 3, Bandung', 'bank_transfer');

-- Insert sample order items
INSERT INTO order_items (order_id, product_id, quantity, unit_price, subtotal) VALUES
-- Order 1 (customer 1): MacBook Pro
(1, 1, 1, 2999.99, 2999.99),
-- Order 2 (customer 2): iPhone + Nike shoes
(2, 2, 1, 1199.99, 1199.99),
(2, 4, 1, 149.99, 149.99),
-- Order 3 (customer 3): Samsung Galaxy
(3, 3, 1, 899.99, 899.99),
-- Order 4 (customer 4): Nike shoes (3 pairs)
(4, 4, 3, 149.99, 449.97),
-- Order 5 (customer 5): Adidas shoes (2 pairs)
(5, 5, 2, 179.99, 359.98),
-- Order 6 (customer 6): Coffee Maker
(6, 9, 1, 299.99, 299.99),
-- Order 7 (customer 7): Sony headphones
(7, 6, 1, 399.99, 399.99),
-- Order 8 (customer 8): Yoga mat + protein powder
(8, 8, 2, 49.99, 99.98),
(8, 10, 2, 39.99, 79.98),
-- Order 9 (customer 9): Protein powder
(9, 10, 1, 39.99, 39.99),
-- Order 10 (customer 10): Yoga mat
(10, 8, 1, 49.99, 49.99);

-- Create indexes for better performance
CREATE INDEX idx_customers_email ON customers(email);
CREATE INDEX idx_customers_city ON customers(city);
CREATE INDEX idx_orders_customer_id ON orders(customer_id);
CREATE INDEX idx_orders_order_date ON orders(order_date);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_order_items_order_id ON order_items(order_id);
CREATE INDEX idx_order_items_product_id ON order_items(product_id);
CREATE INDEX idx_products_category ON products(category);

-- Create practice user with appropriate permissions
CREATE USER practice_user WITH PASSWORD 'practice_pass';
GRANT CONNECT ON DATABASE ecommerce_practice TO practice_user;
GRANT USAGE ON SCHEMA public TO practice_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO practice_user;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO practice_user;

-- Grant permissions on future tables
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO practice_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT USAGE, SELECT ON SEQUENCES TO practice_user; 