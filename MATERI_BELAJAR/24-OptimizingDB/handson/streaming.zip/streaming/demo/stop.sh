#!/bin/bash

# Stop Kafka Spark Streaming Demo
echo "🛑 Stopping Kafka Spark Streaming Demo..."

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

# Stop and remove containers
print_status "Stopping all containers..."
docker-compose down

# Remove unused volumes (optional)
read -p "Do you want to remove data volumes? (y/N): " remove_volumes
if [[ $remove_volumes =~ ^[Yy]$ ]]; then
    print_warning "Removing volumes..."
    docker-compose down -v
    print_status "Volumes removed"
fi

# Clean up data directory (optional)
read -p "Do you want to clean up local data directory? (y/N): " cleanup_data
if [[ $cleanup_data =~ ^[Yy]$ ]]; then
    print_warning "Cleaning up local data..."
    rm -rf data/checkpoints/*
    rm -f data/consumer_stats.json
    print_status "Local data cleaned up"
fi

print_status "Demo stopped successfully!"
echo ""
echo "📝 To restart the demo:"
echo "   ./start.sh" 