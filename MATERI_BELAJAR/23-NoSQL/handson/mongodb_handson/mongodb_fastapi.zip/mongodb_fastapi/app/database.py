import os
from motor.motor_asyncio import AsyncIOMotorClient
from dotenv import load_dotenv

load_dotenv()

class Database:
    def __init__(self):
        self.client = None
        self.db = None

    async def connect(self):
        try:
            self.client = AsyncIOMotorClient(os.getenv("MONGODB_URI"))
            await self.client.admin.command('ping')
            self.db = self.client[os.getenv("DB_NAME", "bookstore")]
            print("✅ Connected to MongoDB!")
            await self.create_indexes()
        except Exception as e:
            print(f"❌ Failed to connect to MongoDB: {e}")
            raise

    async def create_indexes(self):
        try:
            await self.db.books.create_index([("title", "text")])
            await self.db.books.create_index([("author", 1)])
            print("✅ Database indexes created")
        except Exception as e:
            print(f"⚠️ Failed to create indexes: {e}")

    async def close(self):
        if self.client:
            self.client.close()
            print("📴 MongoDB connection closed")

db = Database()

