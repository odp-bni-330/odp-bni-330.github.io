/*
 * Written by : Bostang Palaguna
 * Date : 2025-05-28
 * File : User.java
 * Deskripsi : 
 *   Kelas ini merepresentasikan entitas `User` dalam database.
 *   Digunakan untuk menyimpan data pengguna termasuk username,
 *   password yang telah di-hash, dan peran (role) pengguna.
 *   Kelas ini merupakan bagian dari entity JPA (Java Persistence API)
 *   untuk berinteraksi dengan tabel `users` di basis data Oracle.
 */

 package com.example.connect_oracle_db.entity; // Mendefinisikan paket tempat kelas ini berada

 // Import library untuk JPA (Java Persistence API) yang digunakan dalam pemetaan objek ke tabel database
 import jakarta.persistence.Column;
 import jakarta.persistence.Entity;
 import jakarta.persistence.Id;
 import jakarta.persistence.Table;
 
 @Entity // Menandai bahwa kelas ini adalah entity JPA
 @Table(name = "users") // Menentukan nama tabel di database yang dipetakan dengan kelas ini
 public class User {
 
    @Id // Menandai kolom ini sebagai primary key
    private String username;

    @Column(name = "password_hash") // Menentukan nama kolom di database yang berbeda dari nama atribut Java
    private String passwordHash;

    private String role; // Kolom 'role' di tabel users

    // Getter untuk mengambil nilai username
    public String getUsername() {
        return username;
    }

    // Getter untuk mengambil nilai password yang sudah di-hash
    public String getPasswordHash() {
        return passwordHash;
    }

    // Getter untuk mengambil peran pengguna
    public String getRole() {
        return role;
    }

    // Setter untuk mengubah nilai username
    public void setUsername(String username) {
        this.username = username;
    }

    // Setter untuk mengubah nilai password yang sudah di-hash
    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    // Setter untuk mengubah peran pengguna
    public void setRole(String role) {
        this.role = role;
    }
 }
 