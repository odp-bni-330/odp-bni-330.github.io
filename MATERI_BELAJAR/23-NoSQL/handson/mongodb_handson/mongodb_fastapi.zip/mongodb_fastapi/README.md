# Python MongoDB & FastAPI

## Cara Penggunaan

**Langkah 0** : Setup virtual environment

pindah ke direktori proyek

```bash
python -m venv [nama_direktori_proyek]

source [nama_direktori_proyek]/bin/activate
```

**Langkah 1** : Install library yang dibutuhkan di environment

```bash
pip install -r requirements.txt
```

**Langkah 2** : Atur url mongoDB di `.env`

```conf
MONGODB_URI=mongodb+srv://bostang:<password>@cluster0.fqcn7ws.mongodb.net/
DB_NAME=bookstore
```

**Langkah 3** : Jalankan Python

```bash
python run.py
```
