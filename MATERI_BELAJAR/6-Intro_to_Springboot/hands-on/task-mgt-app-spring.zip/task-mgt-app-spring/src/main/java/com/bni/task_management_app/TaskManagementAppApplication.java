package com.bni.task_management_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskManagementAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaskManagementAppApplication.class, args);
	}

}

//  Perhatikan bahwa main file tidak berubah-ubah
// yang kita ubah-ubah adalah file yang ada di dalam:
// ../model
// ../controller
// ../repository
// ../servivce
