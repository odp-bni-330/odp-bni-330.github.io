const { Kafka } = require('kafkajs');
const faker = require('faker');

// Kafka client configuration
const kafka = new Kafka({
  clientId: 'data-producer',
  // brokers: ['localhost:9092']
  brokers: ['localhost:9093']
});

const producer = kafka.producer();
const TOPIC = 'user-events';

// Generate random user event
const generateUserEvent = () => {
  const eventTypes = ['CLICK', 'VIEW', 'PURCHASE', 'SIGNUP', 'LOGIN'];
  const randomEvent = eventTypes[Math.floor(Math.random() * eventTypes.length)];
  
  return {
    userId: faker.datatype.uuid(),
    name: faker.name.findName(),
    email: faker.internet.email(),
    eventType: randomEvent,
    timestamp: new Date().toISOString(),
    product: randomEvent === 'PURCHASE' || randomEvent === 'VIEW' ? {
      id: faker.datatype.uuid(),
      name: faker.commerce.productName(),
      price: faker.commerce.price()
    } : null
  };
};

// Send messages to Kafka
const sendMessage = async () => {
  const event = generateUserEvent();
  
  try {
    await producer.send({
      topic: TOPIC,
      messages: [
        { 
          key: event.userId, 
          value: JSON.stringify(event) 
        },
      ],
    });
    
    console.log(`Event sent: ${event.eventType} by ${event.name}`);
  } catch (error) {
    console.error('Error sending message:', error);
  }
};

// Main function
const run = async () => {
  await producer.connect();
  console.log('Producer connected to Kafka');
  
  // Send a new message every second
  setInterval(sendMessage, 1000);
  
  // Handle shutdown gracefully
  const errorTypes = ['unhandledRejection', 'uncaughtException'];
  const signalTraps = ['SIGTERM', 'SIGINT', 'SIGUSR2'];
  
  errorTypes.forEach(type => {
    process.on(type, async () => {
      try {
        console.log(`Process ${type}...`);
        await producer.disconnect();
        process.exit(0);
      } catch (e) {
        process.exit(1);
      }
    });
  });
  
  signalTraps.forEach(type => {
    process.once(type, async () => {
      try {
        await producer.disconnect();
      } finally {
        process.kill(process.pid, type);
      }
    });
  });
};

run().catch(console.error);