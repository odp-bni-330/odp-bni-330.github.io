###### Import Library ######
from elasticsearch import Elasticsearch, helpers       # elasticsearch client
import configparser                                    # baca file config.ini
import json                                            # untuk pretty print json
############################

##### Make a Connection to Elastic Cloud Deployment #####
config = configparser.ConfigParser()
config.read('example.ini')

### SEBAGAI SUPER USER ###
# es = Elasticsearch(
#     cloud_id=config['ELASTIC']['cloud_id'],
#     # http_auth=(config['ELASTIC']['user'], config['ELASTIC']['password']) # deprecated
#     basic_auth=(config['ELASTIC']['user'], config['ELASTIC']['password'])
# )
########################## 

### SEBAGAI USER BIASA ###
es = Elasticsearch(
    cloud_id=config['DEFAULT']['cloud_id'],
    api_key=(config['DEFAULT']['apikey_id'], config['DEFAULT']['apikey_key'])  # <--- ini benar
)
##########################

#########################################################

##### Searching Data #####
result = es.search(
 index='lord-of-the-rings',
  query={
    'match': {'quote': 'late'}
  }
 )

data = result['hits']['hits']
pretty_json = json.dumps(data, indent=4)
print(pretty_json)
##########################
