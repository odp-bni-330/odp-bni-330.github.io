# PowerShell script to load sample data into Elasticsearch

# Wait for Elasticsearch to be ready
Write-Host "Waiting for Elasticsearch to be ready..."
do {
    try {
        $response = Invoke-WebRequest -Uri "http://localhost:9200" -UseBasicParsing -ErrorAction SilentlyContinue
        if ($response.StatusCode -eq 200) {
            break
        }
    }
    catch {
        # Elasticsearch not ready yet
    }
    Start-Sleep -Seconds 5
    Write-Host "Still waiting for Elasticsearch..."
} while ($true)

Write-Host "Elasticsearch is ready!"

# Create an index called "products"
Write-Host "Creating products index..."
try {
    Invoke-RestMethod -Uri "http://localhost:9200/products" -Method Put
    Write-Host "Products index created successfully!"
}
catch {
    Write-Host "Error creating products index: $_"
}

# Add documents to the index
Write-Host "Adding sample products..."

# Product 1: Laptop
$laptop = @{
    name = "Laptop"
    price = 999.99
    in_stock = 10
    category = "electronics"
    tags = @("computer", "work", "portable")
} | ConvertTo-Json

try {
    Invoke-RestMethod -Uri "http://localhost:9200/products/_doc" -Method Post -Body $laptop -ContentType "application/json"
    Write-Host "Added Laptop"
}
catch {
    Write-Host "Error adding Laptop: $_"
}

# Product 2: Smartphone
$smartphone = @{
    name = "Smartphone"
    price = 699.99
    in_stock = 15
    category = "electronics"
    tags = @("mobile", "communication")
} | ConvertTo-Json

try {
    Invoke-RestMethod -Uri "http://localhost:9200/products/_doc" -Method Post -Body $smartphone -ContentType "application/json"
    Write-Host "Added Smartphone"
}
catch {
    Write-Host "Error adding Smartphone: $_"
}

# Product 3: Headphones
$headphones = @{
    name = "Headphones"
    price = 149.99
    in_stock = 8
    category = "electronics"
    tags = @("audio", "music", "wireless")
} | ConvertTo-Json

try {
    Invoke-RestMethod -Uri "http://localhost:9200/products/_doc" -Method Post -Body $headphones -ContentType "application/json"
    Write-Host "Added Headphones"
}
catch {
    Write-Host "Error adding Headphones: $_"
}

# Product 4: Coffee Maker
$coffeeMaker = @{
    name = "Coffee Maker"
    price = 89.99
    in_stock = 5
    category = "kitchen"
    tags = @("appliance", "morning", "beverage")
} | ConvertTo-Json

try {
    Invoke-RestMethod -Uri "http://localhost:9200/products/_doc" -Method Post -Body $coffeeMaker -ContentType "application/json"
    Write-Host "Added Coffee Maker"
}
catch {
    Write-Host "Error adding Coffee Maker: $_"
}

# Product 5: Blender
$blender = @{
    name = "Blender"
    price = 49.99
    in_stock = 12
    category = "kitchen"
    tags = @("appliance", "cooking")
} | ConvertTo-Json

try {
    Invoke-RestMethod -Uri "http://localhost:9200/products/_doc" -Method Post -Body $blender -ContentType "application/json"
    Write-Host "Added Blender"
}
catch {
    Write-Host "Error adding Blender: $_"
}

Write-Host "Sample data loaded successfully!" 