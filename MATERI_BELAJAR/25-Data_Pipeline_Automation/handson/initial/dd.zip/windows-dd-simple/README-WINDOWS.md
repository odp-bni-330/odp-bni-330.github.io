# Multi-Source Data Demo - Windows Edition

Demonstrasi pengambilan data dari PostgreSQL (Neon) dan MongoDB (Atlas) dengan visualisasi JavaScript yang dioptimalkan untuk Windows.

## 🎯 Quick Start for Windows

### Option 1: Batch File (Termudah)
```cmd
fix-database.bat
```

### Option 2: PowerShell (Direkomendasikan)
```powershell
.\fix-database.ps1
```

### Option 3: Manual Setup
```cmd
npm install
node setup-postgres-auto.js
node setup-mongodb.js
demo.bat start
```

## 🔧 Windows Requirements

- **Node.js** v16+ (Download dari [nodejs.org](https://nodejs.org/))
- **Docker Desktop** (Opsional, untuk containerized mode)
- **Windows 10/11** dengan PowerShell 5.1+
- **Internet Connection** untuk akses cloud databases

## 🚀 Features Windows-Specific

### 1. **Dual Script Support**
- **Batch File**: `fix-database.bat` - Kompatibel dengan Command Prompt lama
- **PowerShell**: `fix-database.ps1` - Fitur modern dengan error handling canggih

### 2. **Windows Console Optimization**
- UTF-8 encoding otomatis untuk emoji dan karakter khusus
- ANSI color detection untuk Command Prompt
- Enhanced PowerShell colors dan formatting

### 3. **Error Handling Windows-Native**
- Exit codes untuk batch scripts
- Try-catch blocks di PowerShell
- Automatic cleanup temporary files
- Windows Defender compatibility

### 4. **Process Management**
- Background process handling
- Graceful shutdown mechanisms
- Port conflict detection
- Service health monitoring

## 📊 Database Architecture

### PostgreSQL (Neon Cloud)
```
Products Table:
- id (SERIAL PRIMARY KEY)
- name (VARCHAR)
- price (DECIMAL(12,2))  ← Fixed untuk IDR besar
- category (VARCHAR)

Sales Table:
- id (SERIAL PRIMARY KEY)
- product_id (INTEGER REFERENCES products)
- quantity (INTEGER)
- total_amount (DECIMAL(15,2))  ← Support sampai 999 Triliun IDR
- sale_date (DATE)
```

### MongoDB (Atlas Cloud)
```
Customers Collection:
{
  _id: ObjectId,
  name: String,
  email: String,
  location: { city: String, country: String },
  age: Number,
  loyaltyTier: String
}

Interactions Collection:
{
  _id: ObjectId,
  customerId: ObjectId,
  type: String,
  timestamp: Date,
  details: Object
}
```

## 🛠️ Windows Commands

### Command Prompt
```cmd
# Fix semua database
fix-database.bat

# Manual setup
npm install
node setup-postgres-auto.js
node setup-mongodb.js

# Jalankan demo
demo.bat start
demo.bat stop
demo.bat logs webapp
demo.bat info
```

### PowerShell
```powershell
# Fix semua database (recommended)
.\fix-database.ps1

# Manual setup dengan error handling
try {
    npm install
    node setup-postgres-auto.js
    node setup-mongodb.js
} catch {
    Write-Host "Setup failed: $_" -ForegroundColor Red
}

# Jalankan demo
.\demo.ps1 start
.\demo.ps1 stop

# Test dengan REST API
Invoke-RestMethod -Uri "http://localhost:3000/api/health"
```

## 🌐 API Endpoints

| Endpoint | Method | Description | Windows Test |
|----------|--------|-------------|--------------|
| `/api/health` | GET | Database health status | `curl http://localhost:3000/api/health` |
| `/api/postgres/sales` | GET | PostgreSQL sales data | `curl http://localhost:3000/api/postgres/sales` |
| `/api/postgres/monthly-sales` | GET | Monthly sales trend | PowerShell: `Invoke-RestMethod -Uri "http://localhost:3000/api/postgres/monthly-sales"` |
| `/api/mongodb/customers` | GET | MongoDB customer data | `curl http://localhost:3000/api/mongodb/customers` |
| `/api/mongodb/interactions` | GET | Customer interactions | PowerShell: `Invoke-RestMethod -Uri "http://localhost:3000/api/mongodb/interactions"` |
| `/api/combined/dashboard` | GET | Combined analytics | `curl http://localhost:3000/api/combined/dashboard` |

## 🐛 Windows Troubleshooting

### Common Issues & Solutions

#### 1. PowerShell Execution Policy
```powershell
# Error: "execution of scripts is disabled"
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

#### 2. Node.js PATH Issues
```cmd
# Check if Node.js is in PATH
node --version
npm --version

# If not found, add to PATH:
# Control Panel → System → Advanced → Environment Variables
# Add Node.js installation folder to PATH
```

#### 3. Windows Defender Blocking
```cmd
# Temporarily disable real-time protection
# Or add exception for:
# - Node.js executable
# - Project folder
# - npm cache folder
```

#### 4. Port 3000 Already in Use
```cmd
# Find what's using port 3000
netstat -ano | findstr :3000

# Kill the process (replace PID)
taskkill /PID <PID> /F
```

#### 5. Database Connection Issues
```powershell
# Test connectivity
Test-NetConnection -ComputerName "ep-falling-cake-a1j2rvpd-pooler.ap-southeast-1.aws.neon.tech" -Port 5432

# Test MongoDB connectivity
Invoke-RestMethod -Uri "https://cloud.mongodb.com" -Method HEAD
```

#### 6. Unicode/Emoji Display Issues
```cmd
# Set console to UTF-8
chcp 65001

# Or use Windows Terminal instead of Command Prompt
```

## 📈 Performance Tips Windows

1. **Use Windows Terminal** instead of old Command Prompt
2. **Disable Windows Defender** real-time scanning for project folder
3. **Use SSD** untuk node_modules dan Docker volumes
4. **Consider WSL2** untuk performance Linux-like di Windows
5. **Close unnecessary applications** yang consume memory

## 🔐 Security Notes Windows

1. **Windows Firewall**: Otomatis akan prompt untuk allow Node.js
2. **Antivirus**: May flag npm packages sebagai false positive
3. **User Account Control**: Run as regular user, bukan Administrator
4. **Network Security**: Database menggunakan SSL/TLS encryption

## 📦 Files Structure Windows

```
windows-dd-simple/
├── fix-database.bat          ← Windows batch fix script
├── fix-database.ps1          ← PowerShell fix script  
├── setup-postgres-auto.js    ← Automated PostgreSQL setup
├── setup-databases.sql       ← Fixed SQL schema
├── setup-mongodb.js          ← MongoDB Atlas setup
├── server.js                 ← Express.js server
├── demo.bat                  ← Windows demo launcher
├── demo.ps1                  ← PowerShell demo launcher
├── docker-compose.yml        ← Docker configuration
├── package.json              ← Node.js dependencies
├── DATABASE-FIX.md          ← Windows fix documentation
├── README-WINDOWS.md        ← This file
└── public/
    ├── index.html            ← Frontend dashboard
    ├── style.css             ← Windows-optimized styles
    └── script.js             ← JavaScript functionality
```

## 🎨 UI Features

- **Responsive Design** untuk berbagai ukuran layar Windows
- **Real-time Charts** menggunakan Chart.js
- **Health Monitoring** untuk kedua database
- **Tab Navigation** untuk easy browsing
- **Windows-Native Icons** dengan Font Awesome
- **Dark/Light Theme** detection

## 🔄 Sample Data

### PostgreSQL Sample
- 10 produk elektronik Indonesia (Laptop ASUS ROG, Samsung Galaxy, dll)
- 30 transaksi penjualan dari Januari-Juni 2024  
- Total penjualan: ~1.7 miliar IDR
- Format mata uang: Indonesian Rupiah (IDR)

### MongoDB Sample
- 5 customer dari kota besar Indonesia (Jakarta, Surabaya, Bandung, dll)
- 7 tipe interaksi customer (purchase, support, social media, dll)
- Customer loyalty tiers: Silver, Gold, Platinum
- Timestamp dalam format ISO 8601

## 🚀 Deployment Windows

### Local Development
```cmd
# Development mode dengan auto-reload
npm run dev

# Production mode
npm start
```

### Docker pada Windows
```cmd
# Build dan run dengan Docker Desktop
docker-compose up --build

# Background mode
docker-compose up -d

# Lihat logs
docker-compose logs -f webapp
```

### Windows Service (Opsional)
```cmd
# Install sebagai Windows Service dengan PM2
npm install -g pm2
pm2 install pm2-windows-service
pm2 start server.js --name "data-demo"
pm2 save
```

## 📞 Support & Contact

Untuk Windows-specific issues:
- Check dokumentasi di `DATABASE-FIX.md`
- Test dengan PowerShell scripts dulu sebelum batch files
- Pastikan Windows version compatibility (Win10/11)
- Verify Docker Desktop jika pakai container mode

---

🎉 **Happy Coding on Windows!** 🪟

Akses dashboard di: **http://localhost:3000** 