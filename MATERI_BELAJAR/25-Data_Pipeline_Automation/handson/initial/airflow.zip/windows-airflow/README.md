# 🚀 Hands-on: Workflow Automation dengan Apache Airflow - Windows Edition

Project ini mendemonstrasikan penggunaan Apache Airflow untuk workflow automation menggunakan Docker Desktop pada Windows dengan **Neon PostgreSQL** sebagai database cloud.

## 🏗️ Struktur Direktori

```
windows/
├── dags/                       # Direktori untuk menyimpan DAG (Directed Acyclic Graph)
│   ├── example_dag.py          # Contoh DAG sederhana untuk Windows
│   └── data_processing_dag.py  # DAG untuk pemrosesan data dengan UI yang diperbaiki
├── logs/                       # Direktori untuk log Airflow
├── plugins/                    # Direktori untuk plugin Airflow
├── data/                       # Direktori untuk data output
├── docker-compose.yml          # Konfigurasi Docker Compose dengan Neon PostgreSQL
├── test-neon-connection.ps1    # Script PowerShell untuk test koneksi Neon
├── test-neon-connection.bat    # Script Batch untuk test koneksi Neon
└── README.md                   # File dokumentasi ini
```

## 🗄️ Database Configuration

Project ini menggunakan **Neon PostgreSQL** sebagai database cloud untuk:
- ✅ **Skalabilitas** yang lebih baik
- ✅ **Managed service** tanpa perlu maintenance
- ✅ **High availability** dan backup otomatis
- ✅ **SSL connection** untuk keamanan
- ✅ **Optimized for Windows Docker Desktop**

**Database URL:** `postgresql://neondb_owner:***@ep-falling-cake-a1j2rvpd-pooler.ap-southeast-1.aws.neon.tech/airflow`

## 🛠️ Prerequisites untuk Windows

1. **Docker Desktop untuk Windows** (versi terbaru)
   - Download dari: https://docs.docker.com/desktop/windows/install/
   - Pastikan WSL 2 sudah diaktifkan
   - Minimal 4GB RAM tersedia untuk Docker

2. **PowerShell atau Command Prompt**
   - Gunakan Windows PowerShell (disarankan) atau Command Prompt

3. **Koneksi Internet Stabil**
   - Diperlukan untuk koneksi ke Neon PostgreSQL

## 🚀 Cara Menjalankan

### Langkah 1: Test Koneksi Database (Opsional)
```powershell
# Test dengan PowerShell
.\test-neon-connection.ps1

# Atau test dengan Batch file
.\test-neon-connection.bat
```

### Langkah 2: Persiapan
```powershell
# Buka PowerShell sebagai Administrator (opsional, tapi disarankan)
# Navigate ke direktori windows
cd path\to\your\project\windows
```

### Langkah 3: Jalankan Docker Compose
```powershell
# Jalankan semua services Airflow
docker-compose up -d

# Atau jika ingin melihat logs secara real-time
docker-compose up
```

### Langkah 4: Akses Airflow
- Buka browser dan akses: **http://localhost:8080**
- **Username:** `admin`
- **Password:** `admin`

## 🎯 Services yang Berjalan

| Service | Description | Status |
|---------|-------------|---------|
| 🌐 **Webserver** | Airflow UI | http://localhost:8080 |
| 📅 **Scheduler** | Task scheduling | Background |
| 👷 **Worker** | Task execution | Background |
| 🔄 **Triggerer** | Deferred tasks | Background |
| 🔑 **Redis** | Message broker | Docker container |
| 🗄️ **PostgreSQL** | Database | **Neon Cloud** |

## 🎯 DAG yang Tersedia

### 1. Example Workflow (example_dag.py)
- **Deskripsi:** DAG sederhana untuk demonstrasi pada Windows
- **Tasks:** Print date, sleep, Python function, echo message
- **Tags:** `example`, `windows`

### 2. Data Processing Workflow (data_processing_dag.py)
- **Deskripsi:** Workflow pemrosesan data lengkap dengan laporan HTML yang diperbaiki
- **Tasks:** 
  - ✅ Membuat sample data (100 records)
  - ⚙️ Memproses data dan kategorisasi gaji
  - 📊 Menghasilkan laporan HTML dengan styling modern
  - 🔔 Notifikasi penyelesaian
- **Tags:** `data`, `processing`, `windows`

## 🖥️ Fitur Khusus Windows

### Docker Desktop Integration
- **Volume mounting** dioptimalkan untuk Windows paths
- **Networking** menggunakan bridge driver untuk kompatibilitas
- **Health checks** diperpanjang untuk startup yang lebih stabil dengan Neon

### Performance Optimizations
- **Worker concurrency:** 4 (optimal untuk Windows)
- **Memory management:** Improved untuk Docker Desktop
- **Database connection:** SSL-secured Neon PostgreSQL

## 📊 Monitoring dan Management

### Menggunakan PowerShell
```powershell
# Cek status containers
docker-compose ps

# Lihat logs service tertentu
docker-compose logs airflow-webserver
docker-compose logs airflow-worker

# Test koneksi database
.\test-neon-connection.ps1

# Restart service tertentu
docker-compose restart airflow-worker

# Stop semua services
docker-compose down

# Stop dan restart (no volumes to worry about)
docker-compose down && docker-compose up -d
```

### Akses Services
- **Airflow UI:** http://localhost:8080
- **Redis:** localhost:6379 (untuk debugging)
- **Database:** Neon Cloud (managed)

## 🔧 Troubleshooting Windows

### Problem: Database Connection Issues
```powershell
# Test koneksi ke Neon PostgreSQL
.\test-neon-connection.ps1

# Manual test dengan Docker
docker run --rm postgres:13 psql "postgresql://neondb_owner:npg_G47bTrUPvdfo@ep-falling-cake-a1j2rvpd-pooler.ap-southeast-1.aws.neon.tech/airflow?sslmode=require" -c "SELECT version();"
```

### Problem: Container startup lambat
```powershell
# Increase Docker Desktop memory allocation
# Settings → Resources → Memory → 6GB atau lebih
```

### Problem: Port conflicts
```powershell
# Cek port yang digunakan
netstat -an | findstr :8080
netstat -an | findstr :6379

# Jika port conflict, edit docker-compose.yml
# Ganti port mapping, misal 8080:8080 menjadi 8081:8080
```

### Problem: Volume mounting issues
```powershell
# Pastikan Docker Desktop shared drives sudah enabled
# Settings → Resources → File Sharing
# Add drive yang berisi project folder
```

### Problem: Internet connectivity
```powershell
# Test koneksi internet
ping google.com

# Test DNS resolution
nslookup ep-falling-cake-a1j2rvpd-pooler.ap-southeast-1.aws.neon.tech
```

### Problem: Database Migration
Jika muncul pesan error tentang database migration:
```powershell
docker-compose exec airflow-webserver airflow db migrate
```

## 🏥 Health Checks

Semua services memiliki health checks yang diperpanjang untuk Windows:

| Service | Health Check | Interval |
|---------|--------------|----------|
| Webserver | http://localhost:8080/health | 30s |
| Scheduler | Internal health check | 30s |
| Worker | Celery ping check | 30s |
| Redis | redis-cli ping | 10s |
| Database | **Neon Managed** | N/A |

## 📁 File Output

Hasil pemrosesan data akan tersimpan di:
- `data/sample_data.csv` - Data mentah
- `data/processed_data.csv` - Data yang sudah diproses
- `data/statistics.csv` - Statistik summary
- `data/report.html` - Laporan HTML dengan styling modern

## 🔄 Reset Instalasi

Jika mengalami masalah dan ingin reset (data Neon tidak akan terhapus):

```powershell
# Stop containers
docker-compose down

# Clean restart
docker-compose up -d
```

## 💡 Keuntungan Menggunakan Neon PostgreSQL

1. **🌍 Cloud Managed**: No need to manage PostgreSQL container
2. **📈 Auto-scaling**: Database scales with your workload  
3. **🔒 SSL Security**: Encrypted connections by default
4. **💾 Auto Backup**: Point-in-time recovery available
5. **⚡ High Performance**: Optimized for modern applications
6. **💰 Cost Effective**: Pay only for what you use
7. **🖥️ Windows Optimized**: Better for Docker Desktop performance

## 💡 Tips Penggunaan Windows

1. **Gunakan PowerShell ISE** untuk scripting yang lebih complex
2. **Monitoring resources** melalui Docker Desktop dashboard
3. **File permissions** tidak menjadi masalah seperti di Linux
4. **WSL 2 backend** memberikan performance terbaik
5. **Windows Terminal** memberikan experience yang lebih baik
6. **Regular connection tests** untuk memastikan Neon connectivity

## 🔗 Referensi

- [Apache Airflow Documentation](https://airflow.apache.org/docs/)
- [Docker Desktop for Windows Documentation](https://docs.docker.com/desktop/windows/)
- [Neon PostgreSQL Documentation](https://neon.tech/docs)
- [WSL 2 Documentation](https://docs.microsoft.com/en-us/windows/wsl/)
- [Docker Compose Documentation](https://docs.docker.com/compose/)

---

**🎉 Happy Data Processing dengan Airflow + Neon on Windows! 🎉** 