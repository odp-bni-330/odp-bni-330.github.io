package com.bni.taskmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bni.taskmanagement.model.Task;
import com.bni.taskmanagement.service.TaskService;


/*************************** LAYER CONTROLLER ***************************/

@RestController // menandakan bahwa file TaskController.java adalah presentation layer 
@RequestMapping("/api/tasks")   // assign end-point

public class TaskController {

    @Autowired  // DI (dependency injection) : membuat definisi objek secara otomatis
    // Task task = new Task(...);
    private TaskService taskService;

    // READ ALL
    @GetMapping
    public List<Task> getAllTasks(){
        return taskService.getAllTasks();
    }

    // CREATE
    @PostMapping
    public Task createTask(@RequestBody Task task){
        // RequestBody : untuk parsing JSON (input dari web/client) menjadi object
        return taskService.createTask(task);
    }
}
/*************************** END OF LAYER CONTROLLER ***************************/


