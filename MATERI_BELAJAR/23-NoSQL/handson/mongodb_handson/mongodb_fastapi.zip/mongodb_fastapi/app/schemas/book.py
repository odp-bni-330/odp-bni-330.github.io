from pydantic import BaseModel, Field
from typing import Optional, ClassVar
from pydantic.main import BaseModel as PydanticBaseModel

# Solusi untuk error BaseModel
class BaseModel(PydanticBaseModel):
    pass

class BookCreate(BaseModel):
    title: str = Field(..., min_length=1, max_length=100)
    author: str = Field(..., min_length=1, max_length=50)
    price: float = Field(..., gt=0)
    description: Optional[str] = Field(None, max_length=500)

class BookUpdate(BaseModel):
    title: Optional[str] = Field(None, min_length=1, max_length=100)
    author: Optional[str] = Field(None, min_length=1, max_length=50)
    price: Optional[float] = Field(None, gt=0)
    description: Optional[str] = Field(None, max_length=500)

