/*
 * Written by : Bostang Palaguna
 * Date : 2025-05-28
 * File : ProductAcceptController.java
 * Deskripsi : versioning API melalui Accept Header (content negotiation)
 */

/***************************************** METODE 4 : Content Negotiation (Accept Header) Versioning *****************************************/
// src/main/java/com/example/api_versioning/controller/ProductAcceptController.java
package com.example.api_versioning.controller;

import com.example.api_versioning.dto.v1.ProductV1;
import com.example.api_versioning.dto.v2.ProductV2;
import com.example.api_versioning.service.ProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/************************** Layer Controller **************************/
@RestController                         // Menandakan kelas ini Spring MVC Controller ; otomatis konversi return value ke JSON
@RequestMapping("/api/accept/products") // Menentukan base path untuk endpoint
@RequiredArgsConstructor                // Buat constructor dengan parameter untuk semua field yang final : ProductService
public class ProductAcceptController {
    
    private final ProductService productService; // dependency injection
    
    @GetMapping(produces = "application/vnd.company.app-v1+json") 
    // menggunakan header 'Accept'
    // format : Accept : application/vnd.company.app-vX+json (X = versi)
    // Vendor prefix : vnd.company.	Identifier unik untuk organisa
    public List<ProductV1> getAllProductsAcceptV1() {
        return productService.getAllProductsV1();   // return dlm bentuk JSON
    }
    
    @GetMapping(produces = "application/vnd.company.app-v2+json")
    public List<ProductV2> getAllProductsAcceptV2() {
        return productService.getAllProductsV2();
    }
}
/************************** End of Layer Controller *******************/

/* OLD CODE (TANPTA DTO)
package com.example.api_versioning.controller;

// src/main/java/com/example/api_versioning/controller/ProductAcceptController.java

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/products")
public class ProductAcceptController {
    
    @GetMapping(produces = "application/vnd.company.app-v1+json")
    public String getAllProductsAcceptV1() {
        return "Daftar produk (Versi 1 - accept header)";
    }
    
    @GetMapping(produces = "application/vnd.company.app-v2+json")
    public String getAllProductsAcceptV2() {
        return "Daftar produk dengan fitur baru (Versi 2 - accept header)";
    }
}
*/
/***************************************** End of METODE 4 : Content Negotiation (Accept Header) Versioning *****************************************/