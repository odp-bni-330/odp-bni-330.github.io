@echo off
REM ELK Stack Demo - Windows Batch Version
REM Alternative untuk user yang tidak familiar dengan PowerShell

setlocal enabledelayedexpansion

REM Check parameter
set ACTION=%1
if "%ACTION%"=="" set ACTION=start

echo.
echo ╔══════════════════════════════════════════════════════════════╗
echo ║                     ELK Stack Demo                          ║
echo ║          Elasticsearch + Logstash + Kibana + Filebeat       ║
echo ║                   Windows Batch Version                     ║
echo ╚══════════════════════════════════════════════════════════════╝
echo.

if "%ACTION%"=="start" goto START_DEMO
if "%ACTION%"=="stop" goto STOP_DEMO
if "%ACTION%"=="restart" goto RESTART_DEMO
if "%ACTION%"=="logs" goto SHOW_LOGS
if "%ACTION%"=="status" goto SHOW_STATUS
if "%ACTION%"=="help" goto SHOW_HELP

echo [ERROR] Unknown command: %ACTION%
goto SHOW_HELP

:START_DEMO
echo [INFO] Starting ELK Stack Demo...
echo.

REM Check if Docker is running
docker info >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Docker is not running! Please start Docker Desktop first.
    exit /b 1
)
echo [OK] Docker is running

REM Check Docker Compose
docker compose version >nul 2>&1
if errorlevel 1 (
    docker-compose --version >nul 2>&1
    if errorlevel 1 (
        echo [ERROR] Docker Compose not found! Please install Docker Compose.
        exit /b 1
    )
    echo [OK] Docker Compose (legacy) is available
) else (
    echo [OK] Docker Compose is available
)

REM Clean up old containers
echo [INFO] Cleaning up old containers...
docker compose down -v --remove-orphans >nul 2>&1

REM Start ELK Stack
echo [INFO] Starting ELK Stack containers...
docker compose up -d
if errorlevel 1 (
    echo [ERROR] Failed to start ELK Stack
    exit /b 1
)
echo [OK] ELK Stack containers started

REM Wait for Elasticsearch
echo [INFO] Waiting for Elasticsearch to be ready...
:WAIT_ES
timeout /t 5 /nobreak >nul
curl -s http://localhost:9200 >nul 2>&1
if errorlevel 1 (
    echo Waiting...
    goto WAIT_ES
)
echo [OK] Elasticsearch is ready!

REM Wait for Kibana
echo [INFO] Waiting for Kibana to be ready...
:WAIT_KIBANA
timeout /t 5 /nobreak >nul
curl -s http://localhost:5601 >nul 2>&1
if errorlevel 1 (
    echo Waiting...
    goto WAIT_KIBANA
)
echo [OK] Kibana is ready!

REM Create index pattern
echo [INFO] Creating index pattern in Kibana...
timeout /t 10 /nobreak >nul
curl -X POST "localhost:5601/api/saved_objects/index-pattern" -H "kbn-xsrf: true" -H "Content-Type: application/json" -d "{\"attributes\": {\"title\": \"demo-logs-*\", \"timeFieldName\": \"@timestamp\"}}" >nul 2>&1
echo [OK] Index pattern created

REM Show service status
echo.
echo [INFO] Service status:
docker compose ps

REM Show access URLs
echo.
echo ╔══════════════════════════════════════════════════════════════╗
echo ║                    Service Access URLs                      ║
echo ╠══════════════════════════════════════════════════════════════╣
echo ║  📊 Kibana Dashboard: http://localhost:5601                 ║
echo ║  🔍 Elasticsearch:    http://localhost:9200                 ║
echo ║  ⚙️  Logstash:         http://localhost:9600                 ║
echo ╚══════════════════════════════════════════════════════════════╝
echo.
echo [SUCCESS] ELK Stack Demo successfully started!
echo.
echo Next steps:
echo 1. Open Kibana at http://localhost:5601
echo 2. Go to Analytics ^> Discover
echo 3. Select index pattern 'demo-logs-*'
echo 4. View real-time logs coming in
echo 5. Create visualizations and dashboards
echo.
echo To start log generator manually:
echo   powershell -ExecutionPolicy Bypass -File "scripts\generate_logs.ps1"
echo.
echo To stop demo: run-elk-demo.bat stop
goto END

:STOP_DEMO
echo [INFO] Stopping ELK Stack Demo...
docker compose down
echo [OK] Demo stopped
goto END

:RESTART_DEMO
echo [INFO] Restarting ELK Stack Demo...
call %0 stop
timeout /t 2 /nobreak >nul
call %0 start
goto END

:SHOW_LOGS
docker compose logs -f
goto END

:SHOW_STATUS
docker compose ps
goto END

:SHOW_HELP
echo.
echo Available commands:
echo   start   - Start ELK Stack demo
echo   stop    - Stop demo
echo   restart - Restart demo
echo   logs    - Show container logs
echo   status  - Show container status
echo   help    - Show this help
echo.
echo Usage: run-elk-demo.bat [command]
echo.
echo Note: For full functionality, use PowerShell version:
echo   powershell -ExecutionPolicy Bypass -File "run-elk-demo.ps1" [command]
goto END

:END
endlocal 