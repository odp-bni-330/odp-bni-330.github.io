/*
 * Written by : Bostang Palaguna
 * Date : 2025-05-28
 * File : ProductV2.java
 * Deskripsi : Deklarasi class ProductV2 (DTO)
 */

// src/main/java/com/example/api_versioning/dto/v2/ProductV2.java
package com.example.api_versioning.dto.v2; // package definition

// import library
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/************************** Layer Model/DTO **************************/
@Data                   // generasi otomatis getter & setter
@NoArgsConstructor      // buat constructor tanpa parameter (default constructor)
@AllArgsConstructor     // buat constructor dengan semua parameter
public class ProductV2 {
    private Long id;
    private String productName;
    private double price;
    private String manufacturer;
}
/************************** End of Layer Model/DTO *******************/
