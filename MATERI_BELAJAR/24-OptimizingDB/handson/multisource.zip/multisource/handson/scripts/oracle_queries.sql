-- Script untuk Oracle SQL Developer

-- Membuat tabel Customers
CREATE TABLE customers (
    customer_id NUMBER PRIMARY KEY,
    customer_name VARCHAR2(100),
    email VARCHAR2(100),
    registration_date DATE,
    status VARCHAR2(20)
);

-- Membuat tabel Products
CREATE TABLE products (
    product_id NUMBER PRIMARY KEY,
    product_name VARCHAR2(100),
    category VARCHAR2(50),
    price NUMBER(10,2),
    stock_quantity NUMBER
);

-- Membuat tabel Transactions
CREATE TABLE transactions (
    transaction_id NUMBER PRIMARY KEY,
    customer_id NUMBER,
    transaction_date DATE,
    total_amount NUMBER(10,2),
    payment_method VARCHAR2(50),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

-- Membuat tabel Transaction_Items
CREATE TABLE transaction_items (
    item_id NUMBER PRIMARY KEY,
    transaction_id NUMBER,
    product_id NUMBER,
    quantity NUMBER,
    unit_price NUMBER(10,2),
    FOREIGN KEY (transaction_id) REFERENCES transactions(transaction_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

-- Insert data ke tabel Customers
INSERT INTO customers VALUES (1, 'John Doe', 'john.doe@email.com', TO_DATE('2022-01-15', 'YYYY-MM-DD'), 'active');
INSERT INTO customers VALUES (2, 'Jane Smith', 'jane.smith@email.com', TO_DATE('2022-02-20', 'YYYY-MM-DD'), 'active');
INSERT INTO customers VALUES (3, 'Robert Johnson', 'robert.j@email.com', TO_DATE('2022-03-10', 'YYYY-MM-DD'), 'inactive');
INSERT INTO customers VALUES (4, 'Emily Davis', 'emily.d@email.com', TO_DATE('2022-04-05', 'YYYY-MM-DD'), 'active');
INSERT INTO customers VALUES (5, 'Michael Brown', 'michael.b@email.com', TO_DATE('2022-05-12', 'YYYY-MM-DD'), 'active');

-- Insert data ke tabel Products
INSERT INTO products VALUES (101, 'Smartphone X', 'Electronics', 899.99, 50);
INSERT INTO products VALUES (102, 'Laptop Pro', 'Electronics', 1299.99, 30);
INSERT INTO products VALUES (103, 'Coffee Maker', 'Home Appliances', 79.99, 100);
INSERT INTO products VALUES (104, 'Running Shoes', 'Sports', 129.99, 200);
INSERT INTO products VALUES (105, 'Wireless Earbuds', 'Electronics', 149.99, 75);

-- Insert data ke tabel Transactions
INSERT INTO transactions VALUES (1001, 1, TO_DATE('2023-01-10', 'YYYY-MM-DD'), 899.99, 'Credit Card');
INSERT INTO transactions VALUES (1002, 2, TO_DATE('2023-01-15', 'YYYY-MM-DD'), 1299.99, 'PayPal');
INSERT INTO transactions VALUES (1003, 3, TO_DATE('2023-01-20', 'YYYY-MM-DD'), 79.99, 'Credit Card');
INSERT INTO transactions VALUES (1004, 4, TO_DATE('2023-01-25', 'YYYY-MM-DD'), 279.98, 'Debit Card');
INSERT INTO transactions VALUES (1005, 5, TO_DATE('2023-02-01', 'YYYY-MM-DD'), 1049.98, 'Credit Card');
INSERT INTO transactions VALUES (1006, 1, TO_DATE('2023-02-05', 'YYYY-MM-DD'), 149.99, 'PayPal');
INSERT INTO transactions VALUES (1007, 2, TO_DATE('2023-02-10', 'YYYY-MM-DD'), 129.99, 'Credit Card');

-- Insert data ke tabel Transaction_Items
INSERT INTO transaction_items VALUES (10001, 1001, 101, 1, 899.99);
INSERT INTO transaction_items VALUES (10002, 1002, 102, 1, 1299.99);
INSERT INTO transaction_items VALUES (10003, 1003, 103, 1, 79.99);
INSERT INTO transaction_items VALUES (10004, 1004, 104, 1, 129.99);
INSERT INTO transaction_items VALUES (10005, 1004, 103, 1, 149.99);
INSERT INTO transaction_items VALUES (10006, 1005, 102, 1, 1299.99);
INSERT INTO transaction_items VALUES (10007, 1005, 105, 1, 149.99);
INSERT INTO transaction_items VALUES (10008, 1006, 105, 1, 149.99);
INSERT INTO transaction_items VALUES (10009, 1007, 104, 1, 129.99);

-- ===== QUERY ANALISIS =====

-- 1. Analisis Total Penjualan per Kategori Produk
SELECT 
    p.category,
    SUM(ti.quantity * ti.unit_price) AS total_sales
FROM 
    transaction_items ti
JOIN 
    products p ON ti.product_id = p.product_id
GROUP BY 
    p.category
ORDER BY 
    total_sales DESC;

-- 2. Analisis Metode Pembayaran yang Paling Populer
SELECT 
    payment_method,
    COUNT(*) AS transaction_count,
    SUM(total_amount) AS total_amount
FROM 
    transactions
GROUP BY 
    payment_method
ORDER BY 
    transaction_count DESC;

-- 3. Analisis Tren Penjualan Bulanan
SELECT 
    TO_CHAR(transaction_date, 'YYYY-MM') AS month,
    COUNT(*) AS transaction_count,
    SUM(total_amount) AS total_sales
FROM 
    transactions
GROUP BY 
    TO_CHAR(transaction_date, 'YYYY-MM')
ORDER BY 
    month;

-- 4. Analisis Produk Terlaris
SELECT 
    p.product_id,
    p.product_name,
    SUM(ti.quantity) AS total_quantity_sold,
    SUM(ti.quantity * ti.unit_price) AS total_revenue
FROM 
    transaction_items ti
JOIN 
    products p ON ti.product_id = p.product_id
GROUP BY 
    p.product_id, p.product_name
ORDER BY 
    total_quantity_sold DESC;

-- 5. Analisis Customer Lifetime Value
SELECT 
    c.customer_id,
    c.customer_name,
    COUNT(t.transaction_id) AS transaction_count,
    SUM(t.total_amount) AS total_spent
FROM 
    customers c
LEFT JOIN 
    transactions t ON c.customer_id = t.customer_id
GROUP BY 
    c.customer_id, c.customer_name
ORDER BY 
    total_spent DESC;

-- 6. Query untuk Ekspor Data Integrasi
SELECT 
    p.product_id,
    p.product_name,
    p.category,
    SUM(ti.quantity) AS total_quantity_sold,
    SUM(ti.quantity * ti.unit_price) AS total_revenue
FROM 
    products p
LEFT JOIN 
    transaction_items ti ON p.product_id = ti.product_id
GROUP BY 
    p.product_id, p.product_name, p.category
ORDER BY 
    p.product_id;