-- Membuat Tabel customers
CREATE TABLE customers (
    customer_id SERIAL PRIMARY KEY,
    customer_name VARCHAR(255),
    region VARCHAR(50)
);

-- Membuat Tabel orders
CREATE TABLE orders (
    order_id SERIAL PRIMARY KEY,
    customer_id INTEGER,
    order_date DATE,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

-- Membuat Tabel order_items
CREATE TABLE order_items (
    order_item_id SERIAL PRIMARY KEY,
    order_id INTEGER,
    product_name VARCHAR(255),
    quantity INTEGER,
    unit_price NUMERIC(10, 2),
    FOREIGN KEY (order_id) REFERENCES orders(order_id)
);

-- Menyisipkan data ke dalam tabel customers
INSERT INTO customers (customer_name, region) VALUES
('Andi', 'Jakarta'),
('Budi', 'Bandung'),
('Cici', 'Jakarta'),
('Dedi', 'Jakarta'),
('Eka', 'Surabaya');

-- Menyisipkan data ke dalam tabel orders
INSERT INTO orders (customer_id, order_date) VALUES
(1, '2025-06-01'),
(1, '2025-06-15'),
(2, '2025-06-10'),
(3, '2025-06-05'),
(3, '2025-06-20'),
(4, '2025-06-08');

-- Menyisipkan data ke dalam tabel order_items
INSERT INTO order_items (order_id, product_name, quantity, unit_price) VALUES
(1, 'Laptop', 1, 10000000.00),
(1, 'Mouse', 2, 50000.00),
(2, 'Keyboard', 1, 750000.00),
(3, 'Smartphone', 1, 7000000.00),
(4, 'Headphones', 2, 350000.00),
(5, 'Smartwatch', 1, 1500000.00),
(6, 'Tablet', 1, 5000000.00);

-- Query untuk mendapatkan nama pelanggan, total pesanan, dan total uang yang dibelanjakan
-- Simpan sebagai view untuk referensi
CREATE VIEW jakarta_customer_spending AS
SELECT   
    c.customer_name,  
    COUNT(o.order_id) AS total_orders,  
    SUM(oi.quantity * oi.unit_price) AS total_spent
FROM   
    customers c  
LEFT JOIN 
    orders o ON c.customer_id = o.customer_id  
LEFT JOIN 
    order_items oi ON o.order_id = oi.order_id
WHERE   
    c.region = 'Jakarta'
GROUP BY   
    c.customer_id, c.customer_name
ORDER BY   
    total_spent DESC;