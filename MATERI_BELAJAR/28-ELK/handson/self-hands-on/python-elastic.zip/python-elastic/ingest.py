###### Import Library ######
from elasticsearch import Elasticsearch, helpers       # elasticsearch client
import configparser                                    # baca file config.ini
# import json                                            # untuk pretty print json
############################

##### Make a Connection to Elastic Cloud Deployment #####
config = configparser.ConfigParser()
config.read('example.ini')

##### Make a Connection to Elastic Cloud Deployment #####
config = configparser.ConfigParser()
config.read('example.ini')

### SEBAGAI SUPER USER ###
# es = Elasticsearch(
#     cloud_id=config['ELASTIC']['cloud_id'],
#     # http_auth=(config['ELASTIC']['user'], config['ELASTIC']['password']) # deprecated
#     basic_auth=(config['ELASTIC']['user'], config['ELASTIC']['password'])
# )
########################## 

### SEBAGAI USER BIASA ###
es = Elasticsearch(
    cloud_id=config['DEFAULT']['cloud_id'],
    api_key=(config['DEFAULT']['apikey_id'], config['DEFAULT']['apikey_key'])  # <--- ini benar
)
##########################

#########################################################

# confirm that you have connected to the deployment
print(es.info())

##### Ingest data #####
# Index document
es.index(
 index='lord-of-the-rings',
 document={
  'character': 'Aragon',
  'quote': 'It is not this day.'
 })

es.index(
 index='lord-of-the-rings',
 document={
  'character': 'Gandalf',
  'quote': 'A wizard is never late, nor is he early.'
 })

es.index(
 index='lord-of-the-rings',
 document={
  'character': 'Frodo Baggins',
  'quote': 'You are late'
 })

# refresh index
es.indices.refresh(index='lord-of-the-rings')

# When using the es.index API, the request automatically creates the lord-of-the-rings index,