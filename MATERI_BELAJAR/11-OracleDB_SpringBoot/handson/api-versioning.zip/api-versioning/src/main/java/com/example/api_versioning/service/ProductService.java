/*
 * Written by : Bostang Palaguna
 * Date : 2025-05-28
 * File : ProductService.java
 * Deskripsi : Implementasi business logic dari aplikasi
 */

// src/main/java/com/example/api_versioning/service/ProductService.java
package com.example.api_versioning.service;

// import library
import com.example.api_versioning.dto.v1.ProductV1;
import com.example.api_versioning.dto.v2.ProductV2;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;

/************************** Layer Service **************************/

@Service // anotasi yg menandakan bahwa kelas ini adalah Service (komponen bisnis logic)
public class ProductService {
    
    // method untuk dapatkan daftar produk (v1)
    public List<ProductV1> getAllProductsV1() {
        return Arrays.asList(
            new ProductV1(1L, "Produk A", 10000),
            new ProductV1(2L, "Produk B", 20000)
        );
    }
    
    // method untuk dapatkan daftar produk (v2)
    public List<ProductV2> getAllProductsV2() {
        return Arrays.asList(
            new ProductV2(1L, "Produk A", 10000, "PT. Maju Jaya"),
            new ProductV2(2L, "Produk B", 20000, "PT. Sukses Selalu")
        );
    }
}

/************************** End of Layer Service *******************/