/*
 * Written by : Bostang Palaguna
 * Date : 2025-05-28
 * File : ProductService.java
 * Deskripsi : Mendeklarasikan business logic dari aplikasi
 */

// src/main/java/com/example/api_caching/service/ProductService.java
package com.example.api_caching.service; // package declaration

// library import
import com.example.api_caching.model.Product;
import com.example.api_caching.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Service layer untuk manajemen produk dengan caching mechanism.
 * Menggunakan Spring Cache Abstraction untuk optimasi performa.
 */

/************************** Layer Service **************************/
@Service                    // Menandakan sebagai Spring Service (business logic layer).
@RequiredArgsConstructor    // Lombok annotation yang membuat constructor untuk field final
public class ProductService {
    
    private final ProductRepository productRepository; // dependency injection
        // Dependency untuk berinteraksi dengan database.
    
    // === CACHEABLE OPERATIONS === //
    
    /**
     * Mendapatkan semua produk dari cache/database.
     * Hasil akan di-cache dengan key 'products'.
     * Jika cache kosong, akan memanggil database dan simulate slow process.
     */
    @Cacheable(value = "products")
    public List<Product> getAllProducts() {
        simulateSlowService();
        return productRepository.findAll();
    }
    
    /**
     * Mendapatkan produk berdasarkan ID dari cache/database.
     * Hasil akan di-cache dengan key = #id.
     * 
     * @param id Product ID
     * @return Product atau null jika tidak ditemukan
     */
    @Cacheable(value = "product", key = "#id")
    public Product getProductById(Long id) {
        simulateSlowService();
        return productRepository.findById(id).orElse(null);
    }
    
    // === CACHE MODIFICATION OPERATIONS === //
    
    /**
     * Update produk dan update cache terkait.
     * Cache akan diupdate dengan key = product.id.
     * 
     * @param product Produk yang akan diupdate
     * @return Produk yang telah diupdate
     */
    @CachePut(value = "product", key = "#product.id")
    public Product updateProduct(Product product) {
        return productRepository.save(product);
    }

    /*
     * Alternatif implementasi update dengan validasi existance
     * dan partial update field.
     * Uncomment jika diperlukan.
     */
    /*
    @CachePut(value = "product", key = "#product.id")
    public Product updateProduct(Product product) {
        return productRepository.findById(product.getId())
            .map(existing -> {
                existing.setName(product.getName());
                existing.setPrice(product.getPrice());
                existing.setCategory(product.getCategory());
                return productRepository.save(existing);
            })
            .orElseThrow(() -> new ResponseStatusException(
                HttpStatus.NOT_FOUND, "Product not found"));
    }
    */
    
    /**
     * Menghapus produk dan cache terkait.
     * 
     * @param id Product ID yang akan dihapus
     */
    @CacheEvict(value = "product", key = "#id")
    public void deleteProduct(Long id) {
        productRepository.deleteById(id);
    }
    
    // === CACHE MANAGEMENT === //
    
    /**
     * Membersihkan semua cache produk.
     * Digunakan ketika perlu refresh data dari sumber asli.
     */
    @CacheEvict(value = {"products", "product"}, allEntries = true)
    public void clearAllCaches() {
        // Intentionally empty - hanya untuk cache eviction
    }

    /**
     * Membuat produk baru dan membersihkan cache daftar produk.
     * 
     * @param product Produk baru
     * @return Produk yang telah dibuat
     */
    @CacheEvict(value = "products", allEntries = true)
    public Product createProduct(Product product) {
        simulateSlowService();
        return productRepository.save(product);
    }

    // === UTILITY METHODS === //
    
    /**
     * Simulasi proses yang memakan waktu (3 detik).
     * Digunakan untuk demonstrasi caching benefit.
     */
    private void simulateSlowService() {
        try {
            Thread.sleep(3000); 
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            e.printStackTrace();
        }
    }
}
/************************** End of Layer Service *******************/
