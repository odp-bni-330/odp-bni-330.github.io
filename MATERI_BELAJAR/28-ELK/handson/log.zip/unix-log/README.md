# ELK Stack Demo 🚀

Demo lengkap untuk **Elasticsearch**, **Logstash**, **Kibana**, dan **Filebeat** menggunakan Docker Compose dengan log generator otomatis.

## 📋 Daftar Isi

- [Fitur](#-fitur)
- [Prasyarat](#-prasyarat)
- [Instalasi](#-instalasi)
- [Penggunaan](#-penggunaan)
- [Struktur Proyek](#-struktur-proyek)
- [Konfigurasi](#-konfigurasi)
- [Troubleshooting](#-troubleshooting)

## ✨ Fitur

- **Elasticsearch 8.11.0** - Search dan analytics engine
- **Logstash 8.11.0** - Data processing pipeline
- **Kibana 8.11.0** - Data visualization dan dashboard
- **Filebeat 8.11.0** - Log shipper
- **Log Generator** - Otomatis menggenerate sample logs
- **Docker Compose** - Deployment yang mudah
- **Script Otomatis** - Setup dan management yang simpel

## 🛠 Prasyarat

- **Docker** (versi 20.10+)
- **Docker Compose** (versi 2.0+)
- **Bash** (untuk menjalankan script)
- **Curl** (untuk health checks)
- **4GB RAM minimum** untuk semua container

## 📦 Instalasi

1. **Clone atau download proyek ini**
   ```bash
   git clone <repository-url>
   cd elk-stack-demo
   ```

2. **Berikan permission untuk script**
   ```bash
   chmod +x run-elk-demo.sh
   chmod +x scripts/generate_logs.sh
   ```

3. **Jalankan demo**
   ```bash
   ./run-elk-demo.sh start
   ```

## 🎯 Penggunaan

### Memulai Demo

```bash
# Memulai seluruh ELK Stack
./run-elk-demo.sh start
```

Script akan secara otomatis:
- ✅ Memeriksa Docker dan Docker Compose
- ✅ Membersihkan container lama
- ✅ Menjalankan semua service (Elasticsearch, Logstash, Kibana, Filebeat)
- ✅ Menunggu service siap
- ✅ Memulai log generator
- ✅ Membuat index pattern di Kibana

### Perintah Lainnya

```bash
# Menghentikan demo
./run-elk-demo.sh stop

# Restart demo
./run-elk-demo.sh restart

# Melihat logs container
./run-elk-demo.sh logs

# Melihat status container
./run-elk-demo.sh status

# Bantuan
./run-elk-demo.sh help
```

### Mengakses Service

| Service | URL | Deskripsi |
|---------|-----|-----------|
| **Kibana** | http://localhost:5601 | Dashboard dan visualisasi |
| **Elasticsearch** | http://localhost:9200 | REST API |
| **Logstash** | http://localhost:9600 | Monitoring API |

## 📁 Struktur Proyek

```
elk-stack-demo/
├── docker-compose.yml          # Docker Compose configuration
├── run-elk-demo.sh            # Script utama untuk menjalankan demo
├── README.md                  # Dokumentasi ini
├── filebeat/
│   └── filebeat.yml          # Konfigurasi Filebeat
├── logstash/
│   ├── config/
│   │   └── logstash.yml      # Konfigurasi Logstash
│   └── pipeline/
│       └── logstash.conf     # Pipeline processing rules
├── logs/                     # Sample log files
│   ├── apache/
│   │   └── access.log
│   ├── nginx/
│   │   └── access.log
│   └── application/
│       └── app.log
└── scripts/
    └── generate_logs.sh      # Log generator script
```

## ⚙️ Konfigurasi

### Filebeat Configuration

- **Input**: Monitor log files di direktori `./logs/`
- **Output**: Kirim ke Logstash port 5044
- **Multiline**: Support untuk Apache dan Application logs

### Logstash Configuration

- **Input**: Beats input port 5044
- **Filter**: 
  - Grok patterns untuk Apache, Nginx, Application logs
  - GeoIP enrichment
  - Field type conversion
- **Output**: Elasticsearch dengan index pattern `demo-logs-YYYY.MM.dd`

### Elasticsearch Configuration

- **Mode**: Single node
- **Security**: Disabled (untuk demo)
- **Memory**: 512MB heap size

### Kibana Configuration

- **Port**: 5601
- **Index Pattern**: `demo-logs-*` (otomatis dibuat)

## 🎨 Menggunakan Kibana

1. **Buka Kibana** di http://localhost:5601

2. **Pergi ke Discover**
   - Sidebar → Analytics → Discover
   - Pilih index pattern: `demo-logs-*`

3. **Lihat Data Real-time**
   - Log akan muncul secara real-time
   - Filter berdasarkan log type, IP, status code, dll

4. **Buat Visualisasi**
   - Sidebar → Analytics → Visualize Library
   - Buat chart untuk:
     - HTTP status codes distribution
     - Top client IPs
     - Request methods over time
     - Error rate trends

5. **Buat Dashboard**
   - Sidebar → Analytics → Dashboard
   - Kombinasikan visualisasi yang sudah dibuat

## 🔍 Sample Queries

### Elasticsearch Queries

```bash
# Cek index yang tersedia
curl "localhost:9200/_cat/indices?v"

# Search semua logs
curl "localhost:9200/demo-logs-*/_search?pretty"

# Search error logs
curl "localhost:9200/demo-logs-*/_search?q=log_level:ERROR&pretty"

# Count documents
curl "localhost:9200/demo-logs-*/_count?pretty"
```

### Kibana Query Examples

```
# Filter logs dengan status 404
response:404

# Filter logs dari IP tertentu
clientip:"192.168.1.100"

# Filter application errors
fields.log_type:"application" AND log_level:"ERROR"

# Filter berdasarkan waktu
@timestamp:[now-1h TO now]
```

## 🐛 Troubleshooting

### Container Tidak Mau Start

```bash
# Cek status Docker
docker info

# Cek logs container
docker-compose logs elasticsearch
docker-compose logs logstash
docker-compose logs kibana
docker-compose logs filebeat
```

### Elasticsearch Tidak Bisa Diakses

```bash
# Cek health Elasticsearch
curl localhost:9200/_cluster/health?pretty

# Cek memory usage
docker stats elasticsearch
```

### Kibana Tidak Menampilkan Data

1. **Cek apakah index ada:**
   ```bash
   curl "localhost:9200/_cat/indices?v"
   ```

2. **Cek apakah Filebeat mengirim data:**
   ```bash
   docker-compose logs filebeat
   ```

3. **Cek Logstash processing:**
   ```bash
   docker-compose logs logstash
   ```

### Memory Issues

Jika mengalami masalah memory:

1. **Turunkan heap size di docker-compose.yml:**
   ```yaml
   environment:
     - ES_JAVA_OPTS=-Xms256m -Xmx256m  # dari 512m ke 256m
   ```

2. **Restart container:**
   ```bash
   ./run-elk-demo.sh restart
   ```

### Log Generator Tidak Berjalan

```bash
# Cek apakah process masih berjalan
ps aux | grep generate_logs

# Jalankan manual untuk debug
./scripts/generate_logs.sh

# Cek output log generator
cat log_generator.out
```

## 🏁 Membersihkan Demo

```bash
# Stop demo dan hapus semua container + volume
./run-elk-demo.sh stop
docker-compose down -v --remove-orphans

# Hapus image (opsional)
docker rmi $(docker images -q docker.elastic.co/elasticsearch/elasticsearch:8.11.0)
docker rmi $(docker images -q docker.elastic.co/logstash/logstash:8.11.0)
docker rmi $(docker images -q docker.elastic.co/kibana/kibana:8.11.0)
docker rmi $(docker images -q docker.elastic.co/beats/filebeat:8.11.0)
```

## 📊 Sample Dashboard Ideas

Setelah data terkumpul, Anda bisa membuat visualisasi seperti:

1. **HTTP Status Codes** - Pie chart
2. **Requests Over Time** - Line chart
3. **Top Client IPs** - Data table
4. **Error Rate** - Metric visualization
5. **Geographic Distribution** - Maps (GeoIP)
6. **Request Methods** - Donut chart
7. **Response Time Trends** - Area chart

---

## 🎉 Selamat!

Demo ELK Stack Anda sudah siap! Mulai eksplorasi data logging dengan Elasticsearch, Logstash, Kibana, dan Filebeat. 

**Happy Logging!** 📈📊 