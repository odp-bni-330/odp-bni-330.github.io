# Test Neon PostgreSQL Connection for Windows
# PowerShell script for testing database connectivity

Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "    Testing Neon PostgreSQL Connection" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host ""

# Test connection using docker
Write-Host "[INFO] Testing Neon PostgreSQL connection..." -ForegroundColor Yellow

# Connection string
$connectionString = "postgresql://neondb_owner:npg_G47bTrUPvdfo@ep-falling-cake-a1j2rvpd-pooler.ap-southeast-1.aws.neon.tech/airflow?sslmode=require"

try {
    # Use a temporary container to test the connection
    Write-Host "[INFO] Running PostgreSQL test container..." -ForegroundColor Yellow
    
    $result = docker run --rm postgres:13 psql $connectionString -c "SELECT version();" 2>&1
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host ""
        Write-Host "✅ SUCCESS: Connection to Neon PostgreSQL is working!" -ForegroundColor Green
        Write-Host ""
        Write-Host "Database Version Info:" -ForegroundColor Cyan
        Write-Host $result
        Write-Host ""
        Write-Host "Your Airflow services can now use the Neon database." -ForegroundColor Green
        Write-Host "You can start Airflow with: docker-compose up -d" -ForegroundColor White
    } else {
        throw "Connection failed"
    }
} catch {
    Write-Host ""
    Write-Host "❌ ERROR: Failed to connect to Neon PostgreSQL" -ForegroundColor Red
    Write-Host ""
    Write-Host "Please check:" -ForegroundColor Yellow
    Write-Host "1. Your internet connection" -ForegroundColor White
    Write-Host "2. The Neon database credentials" -ForegroundColor White
    Write-Host "3. That the Neon database is running" -ForegroundColor White
    Write-Host "4. Firewall settings" -ForegroundColor White
    Write-Host "5. Docker Desktop is running" -ForegroundColor White
    Write-Host ""
    Write-Host "Error details:" -ForegroundColor Red
    Write-Host $result
}

Write-Host ""
Write-Host "==========================================" -ForegroundColor Cyan

# Pause to keep window open if run from explorer
if ($Host.Name -eq "ConsoleHost") {
    Write-Host "Press any key to continue..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
} 