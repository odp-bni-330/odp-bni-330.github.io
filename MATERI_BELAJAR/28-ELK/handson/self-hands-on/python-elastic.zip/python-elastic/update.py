###### Import Library ######
from elasticsearch import Elasticsearch, helpers       # elasticsearch client
import configparser                                    # baca file config.ini
import json                                            # untuk pretty print json
############################

##### Make a Connection to Elastic Cloud Deployment #####
config = configparser.ConfigParser()
config.read('example.ini')

##### Make a Connection to Elastic Cloud Deployment #####
config = configparser.ConfigParser()
config.read('example.ini')

### SEBAGAI SUPER USER ###
# es = Elasticsearch(
#     cloud_id=config['ELASTIC']['cloud_id'],
#     # http_auth=(config['ELASTIC']['user'], config['ELASTIC']['password']) # deprecated
#     basic_auth=(config['ELASTIC']['user'], config['ELASTIC']['password'])
# )
########################## 

### SEBAGAI USER BIASA ###
es = Elasticsearch(
    cloud_id=config['DEFAULT']['cloud_id'],
    api_key=(config['DEFAULT']['apikey_id'], config['DEFAULT']['apikey_key'])  # <--- ini benar
)
##########################
#########################################################

##### Updating Data #####
es.update(
 index='lord-of-the-rings',
 id='7BZ4qZcB9xjJZ76_SiMP',
 doc={'birthplace': 'The Shire'}        # properti yang ditambahkan
 )
#########################


data = es.get(index='lord-of-the-rings', id='7BZ4qZcB9xjJZ76_SiMP')
print(data)