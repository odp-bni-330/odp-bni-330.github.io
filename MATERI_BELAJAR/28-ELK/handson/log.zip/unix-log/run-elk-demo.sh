#!/bin/bash

set -e

# Warna untuk output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Banner
echo -e "${PURPLE}"
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║                     ELK Stack Demo                          ║"
echo "║          Elasticsearch + Logstash + Kibana + Filebeat       ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo -e "${NC}"

# Fungsi untuk print dengan warna
print_step() {
    echo -e "${BLUE}🔧 $1${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_info() {
    echo -e "${CYAN}ℹ️  $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

# Fungsi untuk memeriksa apakah Docker sudah berjalan
check_docker() {
    print_step "Memeriksa Docker..."
    if ! docker info &> /dev/null; then
        print_error "Docker tidak berjalan! Silakan jalankan Docker terlebih dahulu."
        exit 1
    fi
    print_success "Docker sudah berjalan"
}

# Fungsi untuk memeriksa docker-compose
check_docker_compose() {
    print_step "Memeriksa Docker Compose..."
    if ! command -v docker-compose &> /dev/null && ! docker compose version &> /dev/null; then
        print_error "Docker Compose tidak ditemukan! Silakan install Docker Compose."
        exit 1
    fi
    print_success "Docker Compose tersedia"
}

# Fungsi untuk membersihkan container lama
cleanup_old_containers() {
    print_step "Membersihkan container lama..."
    docker-compose down -v --remove-orphans 2>/dev/null || true
    print_success "Container lama sudah dibersihkan"
}

# Fungsi untuk membangun dan menjalankan container
start_elk_stack() {
    print_step "Membangun dan menjalankan ELK Stack..."
    docker-compose up -d
    print_success "ELK Stack container sudah dimulai"
}

# Fungsi untuk menunggu service siap
wait_for_services() {
    print_step "Menunggu service siap..."
    
    print_info "Menunggu Elasticsearch..."
    until curl -s http://localhost:9200 >/dev/null 2>&1; do
        echo -n "."
        sleep 5
    done
    print_success "Elasticsearch siap!"
    
    print_info "Menunggu Kibana..."
    until curl -s http://localhost:5601 >/dev/null 2>&1; do
        echo -n "."
        sleep 5
    done
    print_success "Kibana siap!"
}

# Fungsi untuk membuat index pattern di Kibana
setup_kibana_index_pattern() {
    print_step "Membuat index pattern di Kibana..."
    
    # Tunggu beberapa detik untuk memastikan log sudah masuk
    sleep 10
    
    # Buat index pattern
    curl -X POST "localhost:5601/api/saved_objects/index-pattern/demo-logs" \
        -H "kbn-xsrf: true" \
        -H "Content-Type: application/json" \
        -d '{
            "attributes": {
                "title": "demo-logs-*",
                "timeFieldName": "@timestamp"
            }
        }' >/dev/null 2>&1 || true
    
    print_success "Index pattern dibuat (demo-logs-*)"
}

# Fungsi untuk menampilkan status service
show_service_status() {
    print_step "Status service:"
    echo -e "${CYAN}"
    docker-compose ps
    echo -e "${NC}"
}

# Fungsi untuk menampilkan URL akses
show_access_urls() {
    echo -e "${GREEN}"
    echo "🌐 URL Akses Service:"
    echo "   📊 Kibana Dashboard: http://localhost:5601"
    echo "   🔍 Elasticsearch:    http://localhost:9200"
    echo "   ⚙️  Logstash:         http://localhost:9600"
    echo -e "${NC}"
}

# Fungsi untuk menjalankan log generator
start_log_generator() {
    print_step "Memulai log generator..."
    chmod +x scripts/generate_logs.sh
    
    print_info "Log generator akan berjalan di background..."
    print_info "File log akan diupdate secara real-time"
    
    # Jalankan log generator di background
    nohup ./scripts/generate_logs.sh > log_generator.out 2>&1 &
    LOG_GENERATOR_PID=$!
    echo $LOG_GENERATOR_PID > log_generator.pid
    
    print_success "Log generator dimulai (PID: $LOG_GENERATOR_PID)"
}

# Fungsi untuk menghentikan log generator
stop_log_generator() {
    if [ -f log_generator.pid ]; then
        LOG_GENERATOR_PID=$(cat log_generator.pid)
        if kill -0 $LOG_GENERATOR_PID 2>/dev/null; then
            kill $LOG_GENERATOR_PID
            print_success "Log generator dihentikan"
        fi
        rm -f log_generator.pid
    fi
}

# Fungsi untuk shutdown
shutdown_demo() {
    print_step "Menghentikan demo..."
    stop_log_generator
    docker-compose down
    print_success "Demo dihentikan"
}

# Fungsi untuk menampilkan bantuan
show_help() {
    echo -e "${CYAN}"
    echo "Perintah yang tersedia:"
    echo "  start   - Memulai ELK Stack demo"
    echo "  stop    - Menghentikan demo"
    echo "  restart - Restart demo"
    echo "  logs    - Menampilkan logs container"
    echo "  status  - Menampilkan status container"
    echo "  help    - Menampilkan bantuan ini"
    echo -e "${NC}"
}

# Fungsi utama untuk memulai demo
start_demo() {
    print_step "Memulai ELK Stack Demo..."
    
    check_docker
    check_docker_compose
    cleanup_old_containers
    start_elk_stack
    wait_for_services
    start_log_generator
    setup_kibana_index_pattern
    show_service_status
    show_access_urls
    
    echo -e "${GREEN}"
    echo "🎉 ELK Stack Demo berhasil dimulai!"
    echo ""
    echo "📝 Langkah selanjutnya:"
    echo "   1. Buka Kibana di http://localhost:5601"
    echo "   2. Pergi ke Analytics > Discover"
    echo "   3. Pilih index pattern 'demo-logs-*'"
    echo "   4. Lihat log real-time yang masuk"
    echo "   5. Buat visualisasi dan dashboard"
    echo ""
    echo "⏹️  Untuk menghentikan demo: ./run-elk-demo.sh stop"
    echo -e "${NC}"
}

# Main script logic
case "${1:-start}" in
    "start")
        start_demo
        ;;
    "stop")
        shutdown_demo
        ;;
    "restart")
        shutdown_demo
        sleep 2
        start_demo
        ;;
    "logs")
        docker-compose logs -f
        ;;
    "status")
        show_service_status
        ;;
    "help"|"-h"|"--help")
        show_help
        ;;
    *)
        print_error "Perintah tidak dikenal: $1"
        show_help
        exit 1
        ;;
esac 