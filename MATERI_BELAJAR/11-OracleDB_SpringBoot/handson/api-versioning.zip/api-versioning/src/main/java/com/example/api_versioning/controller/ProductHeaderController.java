/*
 * Written by : Bostang Palaguna
 * Date : 2025-05-28
 * File : ProductHeaderController.java
 * Deskripsi : versioning API melalui HTTP Headers (bukan URI path)
 */

/***************************************** METODE 3 : Header Versioning *****************************************/

// src/main/java/com/example/api_versioning/controller/ProductHeaderController.java
package com.example.api_versioning.controller; // package declaration

// import library
import com.example.api_versioning.dto.v1.ProductV1;
import com.example.api_versioning.dto.v2.ProductV2;
import com.example.api_versioning.service.ProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/************************** Layer Controller **************************/
@RestController                         // Menandakan kelas ini Spring MVC Controller ; otomatis konversi return value ke JSON
@RequestMapping("/api/header/products") // Menentukan base path untuk endpoint
@RequiredArgsConstructor                // Buat constructor dengan parameter untuk semua field yang final : ProductService
public class ProductHeaderController {
    
    private final ProductService productService;    // dependency injection
    
    @GetMapping(headers = "X-API-VERSION=1")        // Hanya akan dipanggil jika request mengandung header X-API-VERSION: 1
    public List<ProductV1> getAllProductsHeaderV1() {
        return productService.getAllProductsV1();   // return dlm bentuk json
    }
    
    @GetMapping(headers = "X-API-VERSION=2")        // Hanya akan dipanggil jika request mengandung header X-API-VERSION: 1
    public List<ProductV2> getAllProductsHeaderV2() {
        return productService.getAllProductsV2();   // return dlm bentuk json
    }
}

/************************** End of Layer Controller *******************/

/* OLD CODE (TANPTA DTO)
package com.example.api_versioning.controller;

// src/main/java/com/example/api_versioning/controller/ProductHeaderController.java

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/products")
public class ProductHeaderController {
    
    @GetMapping(headers = "X-API-VERSION=1")
    public String getAllProductsHeaderV1() {
        return "Daftar produk (Versi 1 - header)";
    }
    
    @GetMapping(headers = "X-API-VERSION=2")
    public String getAllProductsHeaderV2() {
        return "Daftar produk dengan fitur baru (Versi 2 - header)";
    }
}
*/
/***************************************** End of METODE 3 : Header Versioning *****************************************/