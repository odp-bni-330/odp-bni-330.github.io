# Database Fix Script for Windows DD Simple (PowerShell)
# Set UTF-8 encoding for proper display
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# Colors for Windows PowerShell
$colors = @{
    Red = "Red"
    Green = "Green"
    Yellow = "Yellow"
    Blue = "Blue"
    Magenta = "Magenta"
    Cyan = "Cyan"
    White = "White"
}

function Write-ColorText {
    param(
        [string]$Text,
        [string]$Color = "White"
    )
    Write-Host $Text -ForegroundColor $colors[$Color]
}

function Write-Info {
    param([string]$Message)
    Write-ColorText "ℹ️  $Message" "Blue"
}

function Write-Success {
    param([string]$Message)
    Write-ColorText "✅ $Message" "Green"
}

function Write-Warning {
    param([string]$Message)
    Write-ColorText "⚠️  $Message" "Yellow"
}

function Write-Error {
    param([string]$Message)
    Write-ColorText "❌ $Message" "Red"
}

function Write-Header {
    param([string]$Message)
    Write-ColorText "🚀 $Message" "Magenta"
}

Write-Host ""
Write-Header "Database Fix Script for Windows DD Simple"
Write-Host ""

# Check if Node.js is available
try {
    $nodeVersion = node --version 2>$null
    if (-not $nodeVersion) {
        throw "Node.js not found"
    }
    Write-Info "Node.js found: $nodeVersion"
} catch {
    Write-Error "Node.js is required to run this script."
    Write-Info "Please install Node.js from: https://nodejs.org/"
    Read-Host "Press Enter to exit"
    exit 1
}

# Check if npm dependencies are installed
if (-not (Test-Path "node_modules")) {
    Write-Info "Installing npm dependencies..."
    try {
        npm install
        if ($LASTEXITCODE -ne 0) {
            throw "npm install failed"
        }
        Write-Success "Dependencies installed successfully"
    } catch {
        Write-Error "Failed to install npm dependencies"
        Read-Host "Press Enter to exit"
        exit 1
    }
}

Write-Host ""
Write-Header "Setting up PostgreSQL (Neon Database)"
try {
    node setup-postgres-auto.js
    if ($LASTEXITCODE -ne 0) {
        throw "PostgreSQL setup failed"
    }
    Write-Success "PostgreSQL setup completed successfully!"
} catch {
    Write-Error "PostgreSQL setup failed"
    Read-Host "Press Enter to exit"
    exit 1
}

Write-Host ""
Write-Header "Setting up MongoDB (Atlas Database)"
try {
    node setup-mongodb.js
    if ($LASTEXITCODE -ne 0) {
        throw "MongoDB setup failed"
    }
    Write-Success "MongoDB setup completed successfully!"
} catch {
    Write-Error "MongoDB setup failed"
    Read-Host "Press Enter to exit"
    exit 1
}

Write-Host ""
Write-Header "Testing Database Connections"
Write-Info "Starting demo application for testing..."

# Start the demo in background
$demoProcess = Start-Process -FilePath "powershell.exe" -ArgumentList "-Command", ".\demo.ps1 start" -WindowStyle Hidden -PassThru

# Wait for services to start
Write-Info "Waiting for services to initialize..."
Start-Sleep -Seconds 8

# Test health endpoint
Write-Info "Testing health endpoint..."
try {
    $healthResponse = Invoke-RestMethod -Uri "http://localhost:3000/api/health" -Method GET -TimeoutSec 5
    
    if ($healthResponse.services.postgresql -eq "healthy" -and $healthResponse.services.mongodb -eq "healthy") {
        Write-Success "Both databases are healthy!"
        
        # Test PostgreSQL data
        Write-Info "Testing PostgreSQL data..."
        try {
            $pgResponse = Invoke-RestMethod -Uri "http://localhost:3000/api/postgres/sales" -Method GET -TimeoutSec 5
            if ($pgResponse -and $pgResponse.Count -gt 0) {
                Write-Success "PostgreSQL data loading successfully!"
            } else {
                Write-Warning "PostgreSQL data test failed - no data returned"
            }
        } catch {
            Write-Warning "PostgreSQL data test failed - connection error"
        }
        
        # Test MongoDB data
        Write-Info "Testing MongoDB data..."
        try {
            $mongoResponse = Invoke-RestMethod -Uri "http://localhost:3000/api/mongodb/customers" -Method GET -TimeoutSec 5
            if ($mongoResponse -and $mongoResponse.Count -gt 0) {
                Write-Success "MongoDB data loading successfully!"
            } else {
                Write-Warning "MongoDB data test failed - no data returned"
            }
        } catch {
            Write-Warning "MongoDB data test failed - connection error"
        }
        
    } else {
        Write-Warning "Some database connections are unhealthy"
        Write-Host "PostgreSQL: $($healthResponse.services.postgresql)"
        Write-Host "MongoDB: $($healthResponse.services.mongodb)"
    }
} catch {
    Write-Error "Failed to connect to health endpoint"
}

# Stop the demo
Write-Info "Stopping test application..."
try {
    .\demo.ps1 stop | Out-Null
} catch {
    # Try to kill the process if stop command fails
    if ($demoProcess -and -not $demoProcess.HasExited) {
        $demoProcess.Kill()
    }
}

Write-Host ""
Write-Header "Database Fix Complete!"
Write-Host ""
Write-Success "🎉 All databases have been set up successfully!"
Write-Host ""
Write-Info "You can now run the demo with:"
Write-ColorText "   demo.bat start" "Cyan"
Write-ColorText "   OR" "White"
Write-ColorText "   .\demo.ps1 start" "Cyan"
Write-Host ""
Write-Info "Access the dashboard at:"
Write-ColorText "   http://localhost:3000" "Cyan"
Write-Host ""
Read-Host "Press Enter to exit" 