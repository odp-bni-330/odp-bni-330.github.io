# Hands-on: Query Elasticsearch with Kibana (Windows)

This guide will walk you through setting up Elasticsearch and Kibana using Docker on Windows, and performing basic queries.

## Prerequisites
- Docker Desktop for Windows installed and running
- PowerShell 5.1 or later (or PowerShell Core)
- Basic understanding of REST APIs

## Setup

1. Start the Elasticsearch and Kibana containers:
```powershell
docker-compose up -d
```

2. Wait for the services to start (this may take a minute or two)

3. Verify Elasticsearch is running:
```powershell
Invoke-WebRequest -Uri "http://localhost:9200" -UseBasicParsing
```

4. Access Kibana at http://localhost:5601 in your browser

## Exercise 1: Index Sample Data

### Option A: Using PowerShell Script
Run the provided PowerShell script to load sample data:
```powershell
.\sample-data-script.ps1
```

### Option B: Manual PowerShell Commands
Let's create an index and add some sample data manually:

```powershell
# Create an index called "products"
Invoke-RestMethod -Uri "http://localhost:9200/products" -Method Put

# Add a document to the index
$laptop = @{
  name = "Laptop"
  price = 999.99
  in_stock = 10
  category = "electronics"
  tags = @("computer", "work", "portable")
} | ConvertTo-Json

Invoke-RestMethod -Uri "http://localhost:9200/products/_doc" -Method Post -Body $laptop -ContentType "application/json"

# Add more documents
$smartphone = @{
  name = "Smartphone"
  price = 699.99
  in_stock = 15
  category = "electronics"
  tags = @("mobile", "communication")
} | ConvertTo-Json

Invoke-RestMethod -Uri "http://localhost:9200/products/_doc" -Method Post -Body $smartphone -ContentType "application/json"

$headphones = @{
  name = "Headphones"
  price = 149.99
  in_stock = 8
  category = "electronics"
  tags = @("audio", "music", "wireless")
} | ConvertTo-Json

Invoke-RestMethod -Uri "http://localhost:9200/products/_doc" -Method Post -Body $headphones -ContentType "application/json"

$coffeeMaker = @{
  name = "Coffee Maker"
  price = 89.99
  in_stock = 5
  category = "kitchen"
  tags = @("appliance", "morning", "beverage")
} | ConvertTo-Json

Invoke-RestMethod -Uri "http://localhost:9200/products/_doc" -Method Post -Body $coffeeMaker -ContentType "application/json"

$blender = @{
  name = "Blender"
  price = 49.99
  in_stock = 12
  category = "kitchen"
  tags = @("appliance", "cooking")
} | ConvertTo-Json

Invoke-RestMethod -Uri "http://localhost:9200/products/_doc" -Method Post -Body $blender -ContentType "application/json"
```

### Option C: Using curl (if available)
If you have curl installed on Windows, you can also use the same commands as in the Unix version:

```powershell
# Create an index called "products"
curl -X PUT "localhost:9200/products"

# Add documents (same as Unix version)
curl -X POST "localhost:9200/products/_doc" -H "Content-Type: application/json" -d'
{
  "name": "Laptop",
  "price": 999.99,
  "in_stock": 10,
  "category": "electronics",
  "tags": ["computer", "work", "portable"]
}'
```

## Exercise 2: Basic Queries with PowerShell REST API

### Search all documents
```powershell
$searchAll = @{
  query = @{
    match_all = @{}
  }
} | ConvertTo-Json -Depth 3

Invoke-RestMethod -Uri "http://localhost:9200/products/_search" -Method Get -Body $searchAll -ContentType "application/json"
```

### Search by exact field value
```powershell
$searchElectronics = @{
  query = @{
    match = @{
      category = "electronics"
    }
  }
} | ConvertTo-Json -Depth 3

Invoke-RestMethod -Uri "http://localhost:9200/products/_search" -Method Get -Body $searchElectronics -ContentType "application/json"
```

### Range query for price
```powershell
$priceRange = @{
  query = @{
    range = @{
      price = @{
        gte = 100
        lte = 800
      }
    }
  }
} | ConvertTo-Json -Depth 3

Invoke-RestMethod -Uri "http://localhost:9200/products/_search" -Method Get -Body $priceRange -ContentType "application/json"
```

### Boolean query (AND condition)
```powershell
$boolQuery = @{
  query = @{
    bool = @{
      must = @(
        @{ match = @{ category = "electronics" } },
        @{ range = @{ price = @{ lt = 700 } } }
      )
    }
  }
} | ConvertTo-Json -Depth 4

Invoke-RestMethod -Uri "http://localhost:9200/products/_search" -Method Get -Body $boolQuery -ContentType "application/json"
```

## Exercise 3: Using Kibana

1. Open Kibana at http://localhost:5601
2. Navigate to Dev Tools (from the left menu)
3. Try the following queries in the Console:

```
# Get all indices
GET _cat/indices?v

# Search all products
GET products/_search
{
  "query": {
    "match_all": {}
  }
}

# Search with a specific term
GET products/_search
{
  "query": {
    "match": {
      "name": "Laptop"
    }
  }
}

# Search with a wildcard
GET products/_search
{
  "query": {
    "wildcard": {
      "name": "*phone*"
    }
  }
}

# Aggregation - average price by category
GET products/_search
{
  "size": 0,
  "aggs": {
    "avg_price_by_category": {
      "terms": {
        "field": "category.keyword"
      },
      "aggs": {
        "avg_price": {
          "avg": {
            "field": "price"
          }
        }
      }
    }
  }
}
```

## Exercise 4: Create a Kibana Dashboard

1. Go to Stack Management > Index Patterns
2. Create an index pattern for "products*"
3. Go to Visualize and create visualizations:
   - Pie chart of products by category
   - Bar chart of product prices
   - Data table showing all products

## Cleanup

To stop and remove the containers:
```powershell
docker-compose down
```

To remove the data volume as well:
```powershell
docker-compose down -v
```

## Troubleshooting

### Docker Desktop Issues
- Make sure Docker Desktop is running
- Check that WSL 2 backend is enabled (for better performance)
- Ensure sufficient memory is allocated to Docker (at least 4GB recommended)

### PowerShell Execution Policy
If you get execution policy errors, you may need to temporarily allow script execution:
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

### Network Issues
If you can't access Elasticsearch or Kibana:
- Check Windows Firewall settings
- Verify ports 9200 and 5601 are not blocked
- Try using `localhost` instead of `127.0.0.1` or vice versa

### Memory Issues
If Elasticsearch fails to start:
- Increase Docker Desktop memory allocation
- Reduce ES_JAVA_OPTS memory settings in docker-compose.yml if needed 