# 🚀 Quick Start Guide - Airflow on Windows

## ⚡ Super Quick Start (1-2-3)

### Method 1: Using Batch Files (Easiest)
1. **Double-click** `start-airflow.bat`
2. **Wait** for services to start (2-3 minutes)
3. **Open browser** to http://localhost:8080 (login: admin/admin)

### Method 2: Using PowerShell (Advanced)
1. **Right-click** on `manage-airflow.ps1` → "Run with PowerShell"
2. **Choose option 1** (Start Airflow)
3. **Open browser** when prompted

### Method 3: Command Line
```powershell
# Open PowerShell in this directory
docker-compose up -d
```

## 📋 Prerequisites Checklist
- [ ] **Docker Desktop** installed and running
- [ ] **WSL 2** enabled (for better performance)
- [ ] **4GB+ RAM** available for Docker
- [ ] **Ports 8080, 5432, 6379** not in use

## 🎯 What You Get

### DAGs Available:
1. **example_workflow** - Simple demo with bash and Python tasks
2. **data_processing_workflow** - Complete data pipeline with HTML reports

### Services Running:
- 🌐 **Webserver**: http://localhost:8080 (UI)
- 📅 **Scheduler**: Background task scheduling
- 👷 **Worker**: Task execution
- 🗄️ **PostgreSQL**: Database (port 5432)
- 🔑 **Redis**: Message broker (port 6379)

## 🛠️ Management Commands

### Batch Files:
- `start-airflow.bat` - Start all services
- `stop-airflow.bat` - Stop all services  
- `reset-airflow.bat` - Complete reset (deletes all data)

### PowerShell (Advanced):
```powershell
# Interactive menu
.\manage-airflow.ps1

# Direct commands
.\manage-airflow.ps1 -Action start
.\manage-airflow.ps1 -Action stop
.\manage-airflow.ps1 -Action status
.\manage-airflow.ps1 -Action logs
```

### Docker Compose (Manual):
```powershell
docker-compose up -d        # Start
docker-compose down         # Stop
docker-compose ps           # Status
docker-compose logs -f      # View logs
```

## 🔍 Checking Results

### Data Processing Output:
After running `data_processing_workflow`, check:
- `data/sample_data.csv` - Original data
- `data/processed_data.csv` - Processed data
- `data/statistics.csv` - Summary stats
- `data/report.html` - **Open this in browser!**

### Logs Location:
- Container logs: `docker-compose logs airflow-worker`
- Airflow logs: `logs/` directory
- Task logs: Available in Airflow UI

## ⚠️ Troubleshooting

### Common Issues:
1. **Port 8080 in use**: Change in docker-compose.yml
2. **Slow startup**: Increase Docker memory to 6GB+
3. **Container fails**: Check Docker Desktop is running
4. **Volume issues**: Enable file sharing in Docker Desktop

### Quick Fixes:
```powershell
# Restart everything
docker-compose restart

# Complete reset
.\reset-airflow.bat

# Check what's using port 8080
netstat -an | findstr :8080
```

## 🎉 Success Indicators

✅ **All working correctly when:**
- Airflow UI loads at http://localhost:8080
- Both DAGs appear in the UI
- DAGs can be triggered manually
- Tasks complete successfully
- Output files appear in `data/` folder

---

**🚀 Happy Airflow-ing on Windows! 🚀** 