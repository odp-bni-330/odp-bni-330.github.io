# Studi Kasus: Analisis Transaksi Real-Time

## 📋 Deskripsi Kasus

Sistem ini mengimplementasikan analisis transaksi penjualan real-time menggunakan Apache Kafka untuk streaming data, Apache Spark untuk pemrosesan stream, dan dashboard interaktif untuk visualisasi serta notifikasi.

### 🔄 Proses
- **Kafka mentransfer data transaksi penjualan** - Streaming data transaksi secara real-time
- **Spark menganalisis produk terlaris** - Pemrosesan data untuk identifikasi trend dan pattern
- **Output dashboard real-time dan notifikasi** - Visualisasi metrics dan alert system

### 📊 Output yang Diharapkan

#### 1. Dashboard Penjualan
- **Visualisasi metrik real-time** - Charts dan graphs untuk monitoring live data
- **Top products analysis** - Identifikasi produk terlaris per periode
- **Sales by category** - Breakdown penjualan berdasarkan kategori
- **Geographic distribution** - Analisis penjualan per lokasi
- **Trend analysis** - Pattern penjualan berdasarkan waktu

#### 2. Notifikasi
- **Alert untuk produk populer** - Notification ketika produk mencapai threshold tertentu
- **Sales milestone alerts** - Peringatan untuk target penjualan
- **Anomaly detection** - Deteksi pola tidak normal dalam transaksi

#### 3. Analisis Tren
- **Prediksi berdasarkan pola** - Forecasting menggunakan historical data
- **Seasonal analysis** - Analisis pola musiman
- **Performance metrics** - KPI dan metrik performa real-time

## 🏗️ Arsitektur Sistem

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Data Source   │───▶│  Kafka Broker   │───▶│ Spark Streaming │───▶│   Dashboard     │
│  (Transactions) │    │   (Buffer)      │    │  (Processing)   │    │ (Visualization) │
└─────────────────┘    └─────────────────┘    └─────────────────┘    └─────────────────┘
                                                        │
                                                        ▼
                                               ┌─────────────────┐
                                               │  Notifications  │
                                               │    System       │
                                               └─────────────────┘
```

### Komponen Utama:

1. **Kafka Producer**: Generator data transaksi penjualan dengan simulasi real-world
2. **Apache Kafka**: Message broker untuk streaming data transaksi
3. **Apache Spark**: Engine untuk real-time processing dan analytics
4. **Streamlit Dashboard**: Interface visualisasi dengan auto-refresh capability
5. **Notification System**: Alert system untuk event monitoring
6. **Data Storage**: Persistent storage untuk historical analysis

## 🎯 Fitur Utama

### Real-Time Analytics
- ✅ **Live transaction processing** - Pemrosesan transaksi secara real-time
- ✅ **Top products identification** - Identifikasi produk terlaris otomatis
- ✅ **Category-wise sales analysis** - Breakdown penjualan per kategori
- ✅ **Geographic sales distribution** - Mapping penjualan berdasarkan lokasi
- ✅ **Hourly/daily trend analysis** - Analisis pola penjualan temporal

### Dashboard Features
- 📊 **Interactive charts** dengan Plotly
- 🔄 **Auto-refresh capability** (configurable interval)
- 📱 **Responsive design** untuk berbagai device
- 🎨 **Real-time data visualization** dengan color coding
- 📈 **Trend indicators** dan performance metrics

### Notification System
- 🚨 **Popular product alerts** - Alert ketika produk trending
- 💰 **Sales milestone notifications** - Peringatan target penjualan
- 📊 **Performance threshold alerts** - Monitor KPI secara real-time
- 🔔 **Custom alert rules** - Konfigurasi alert sesuai kebutuhan

### Trend Analysis
- 📈 **Predictive analytics** - Forecasting berdasarkan historical data
- 📅 **Seasonal pattern detection** - Identifikasi pola musiman
- 🎯 **Performance forecasting** - Prediksi performa penjualan
- 📊 **Statistical analysis** - Analisis statistik lanjutan

## 🚀 Cara Menjalankan

### Prerequisites
- Docker dan Docker Compose
- Python 3.9+
- Minimum 4GB RAM
- Port 8501, 8080, 9092 tersedia

### Quick Start

1. **Clone repository dan masuk ke directory**
```bash
cd study-case
```

2. **Jalankan sistem lengkap**
```bash
./run.sh
```

3. **Akses aplikasi**
- 📊 **Dashboard**: http://localhost:8501
- ⚡ **Spark UI**: http://localhost:8080
- 📋 **Kafka**: localhost:9092

### Manual Execution

```bash
# Build dashboard container
docker-compose build streamlit-dashboard

# Start all services
docker-compose up -d

# Install Python dependencies
docker exec python-kafka pip install kafka-python==2.0.2

# Start Spark streaming
docker exec spark-master spark-submit --master spark://spark-master:7077 \
  --packages org.apache.spark:spark-sql-kafka-0-10_2.12:3.3.0 \
  /opt/spark-apps/spark_streaming.py &

# Start data generator
docker exec -d python-kafka python /app/kafka_producer.py
```

## 📁 Struktur Proyek

```
study-case/
├── docker-compose.yml           # Konfigurasi Docker services
├── run.sh                      # Script untuk menjalankan sistem
├── stop.sh                     # Script untuk menghentikan sistem
├── requirements.txt            # Python dependencies
├── README.md                   # Dokumentasi proyek
├── dashboard/                  # Streamlit dashboard
│   ├── app.py                 # Aplikasi dashboard utama
│   ├── Dockerfile             # Docker config untuk dashboard
│   └── requirements.txt       # Dashboard dependencies
├── spark-apps/                # Aplikasi Spark dan Kafka
│   ├── kafka_producer.py      # Generator data transaksi
│   └── spark_streaming.py     # Aplikasi Spark streaming
└── spark-data/               # Storage untuk output Spark
    ├── top_products/          # Data produk terlaris
    ├── sales_by_category/     # Data penjualan per kategori
    ├── sales_by_location/     # Data penjualan per lokasi
    ├── hourly_trends/         # Data trend per jam
    ├── notifications/         # Data notifikasi
    └── checkpoints/           # Spark checkpoints
```

## 📊 Data Schema

### Transaction Data
```json
{
  "transaction_id": "tx-1234567890",
  "product_id": 1,
  "product_name": "Laptop Pro",
  "category": "Electronics",
  "quantity": 2,
  "price_per_unit": 1500.0,
  "total_amount": 3000.0,
  "payment_method": "Credit Card",
  "location": "Jakarta",
  "customer_segment": "Premium",
  "timestamp": "2024-01-15 14:30:25",
  "hour_of_day": 14,
  "day_of_week": "Monday"
}
```

## 🔧 Konfigurasi Advanced

### Custom Alert Rules
```python
# Contoh konfigurasi alert dalam spark_streaming.py
ALERT_THRESHOLDS = {
    "popular_product_threshold": 50,    # Units sold per window
    "high_sales_threshold": 100000,     # Total sales per window
    "anomaly_threshold": 3.0            # Standard deviation multiplier
}
```

### Dashboard Customization
```python
# Konfigurasi refresh interval dan layout
REFRESH_INTERVAL = 10  # seconds
CHART_UPDATE_INTERVAL = 5  # seconds
MAX_PRODUCTS_DISPLAY = 10
```

## 🔍 Monitoring dan Troubleshooting

### Health Checks
```bash
# Check container status
docker-compose ps

# View Spark logs
docker logs spark-master

# View Kafka topics
docker exec kafka kafka-topics --bootstrap-server localhost:9092 --list

# Check dashboard logs
docker logs streamlit-dashboard
```

### Performance Tuning
- **Spark Memory**: Adjust `SPARK_WORKER_MEMORY` in docker-compose.yml
- **Kafka Partitions**: Increase partitions untuk higher throughput
- **Batch Size**: Tune `batch_size` di kafka_producer.py
- **Window Size**: Adjust window size di spark_streaming.py

## 🛑 Menghentikan Sistem

```bash
# Gunakan stop script
./stop.sh

# Atau manual
docker-compose down

# Clean up everything
docker-compose down --volumes --remove-orphans
```

## 🔮 Pengembangan Lanjutan

### Implementasi Tambahan
1. **Machine Learning Integration** - Predictive analytics dengan MLlib
2. **Database Integration** - Persistent storage dengan PostgreSQL/MongoDB
3. **API Gateway** - REST API untuk external integration
4. **Advanced Alerting** - Integration dengan Slack, Email, SMS
5. **Security Features** - Authentication dan authorization
6. **Scalability** - Multi-node Kafka dan Spark cluster

### Customization Options
- **Custom Data Sources** - Integration dengan external APIs
- **Advanced Analytics** - Custom metrics dan calculations
- **Visualization Options** - Additional chart types dan layouts
- **Export Features** - PDF reports dan data export
- **Mobile Dashboard** - Responsive mobile interface

---

**🎯 Studi Kasus ini mendemonstrasikan implementasi complete real-time analytics pipeline dengan focus pada business intelligence dan actionable insights untuk decision making.**