const cron = require("node-cron");
const { exec } = require("child_process");

console.log("cron running");
// Konfigurasi
const user = "postgres";
const password = "Ishlah123";
const database = "barulagibank";
const host = "localhost";

// Generate nama file backup dengan format DDDMMMYYYY
function generateFilename() {
  const now = new Date();
  const options = {
    weekday: "short",
    day: "2-digit",
    month: "short",
    year: "numeric",
    timeZone: "Asia/Jakarta",
  };
  const formatted = now.toLocaleDateString("en-US", options).replace(/ /g, "");
  return `barulagibank_${formatted}.backup`;
}

// Cron job: setiap hari jam 23:20 WIB
cron.schedule(
  "20 23 * * *", // 23:20
  () => {
    const filename = generateFilename();
    const command = `PGPASSWORD=${password} pg_dump -U ${user} -h ${host} -F c -f ${filename} ${database}`;

    console.log(
      `[${new Date().toLocaleString("id-ID", {
        timeZone: "Asia/Jakarta",
      })}] Running backup...`
    );

    exec(command, (error, stdout, stderr) => {
      if (error) {
        console.error(`❌ Error during backup: ${error.message}`);
        return;
      }
      if (stderr) {
        console.error(`⚠️ Stderr: ${stderr}`);
      }
      console.log(`✅ Backup saved as ${filename}`);
    });
  },
  {
    scheduled: true,
    timezone: "Asia/Jakarta", // ⬅️ Ini penting untuk UTC+7
  }
);
