/*
 * Written by : Bostang Palaguna
 * Date : 2025-05-28
 * File : ProductControllerV1.java
 * Deskripsi : versioning API melalui URI path
 */

/***************************************** METODE 1 : URI Path Versioning *****************************************/
package com.example.api_versioning.controller.v1;   // package declaration

// import library
import com.example.api_versioning.dto.v1.ProductV1;
import com.example.api_versioning.service.ProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/************************** Layer Controller **************************/
@RestController                      // Menandakan kelas ini Spring MVC Controller ; otomatis konversi return value ke JSON
@RequestMapping("/api/v1/products")  // Menentukan base path untuk endpoint
@RequiredArgsConstructor             // Buat constructor dengan parameter untuk semua field yang final : ProductService
public class ProductControllerV1 {
    
    private final ProductService productService; // Dependency Injection
        // final: dependency ini wajib (non-null)
    
    @GetMapping     // Menangani HTTP GET request ke path /api/v1/products
    public List<ProductV1> getAllProductsV1() {
        return productService.getAllProductsV1();   // return dalam bentuk JSON
    }
}
/************************** End of Layer Controller *******************/

/* OLD CODE (TANPTA DTO)
// src/main/java/com/example/api_versioning/controller/v1/ProductControllerV1.java
package com.example.api_versioning.controller.v1;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/products")
public class ProductControllerV1 {
    
    @GetMapping
    public String getAllProductsV1() {
        return "Daftar produk (Versi 1)";
    }
    
    @GetMapping("/{id}")
    public String getProductByIdV1(@PathVariable Long id) {
        return "Produk dengan ID " + id + " (Versi 1)";
    }
}
*/
/***************************************** End of METODE 1 : URI Path Versioning **********************************/