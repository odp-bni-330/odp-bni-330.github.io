/*
 * Written by : Bostang Palaguna
 * Date : 2025-05-28
 * File : DataLoader.java
 * Deskripsi : mengisi data awal (seed data) ke DB saat app awal dijalankan
 */

// src/main/java/com/example/api_caching/DataLoader.java
package com.example.api_caching;    // package declaration

// library import
import com.example.api_caching.model.Product;
import com.example.api_caching.repository.ProductRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/************************** UTILITY untuk load data ke DB **************************/

@Component  // menandakan kelas ini spring bean ; terdeteksi otomatis saat component scanning

public class DataLoader implements CommandLineRunner {
// Kelas untuk mengisi data awal (seed data) ke DB saat aplikasi Spring Boot pertama kali dijalankan

// CommandLineRunner: memiliki method:
    // void run(String... args) throws Exception;
    // Dipanggil otomatis setelah aplikasi siap 
    private final ProductRepository productRepository;  // depency injection
        // final: Menjamin immutability dan keamanan thread

    // JPA Repository atau Spring Data interface
    public DataLoader(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }
    
    @Override // menandakan bahwa sebuah method meng-override (menimpa) method dari superclass (kelas induk) atau interface yang diimplementasikan.
    public void run(String... args) throws Exception {
        // Membuat 5 entri produk dengan kategori berbeda
        // id akan di-generate otomatis oleh JPA (Java persisten API)
        productRepository.save(new Product(null, "Laptop", 1200.00, "Electronics"));
        productRepository.save(new Product(null, "Smartphone", 800.00, "Electronics"));
        productRepository.save(new Product(null, "Headphones", 150.00, "Electronics"));
        productRepository.save(new Product(null, "Book", 20.00, "Stationery"));
        productRepository.save(new Product(null, "Notebook", 5.00, "Stationery"));
    }
}

/************************** End of UTILITY **************************/