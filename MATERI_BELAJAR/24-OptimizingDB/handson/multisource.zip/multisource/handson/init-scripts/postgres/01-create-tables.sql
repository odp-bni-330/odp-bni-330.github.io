-- Create Products table
CREATE TABLE products (
    product_id SERIAL PRIMARY KEY,
    product_name VARCHAR(255) NOT NULL,
    category VARCHAR(100) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    stock_quantity INTEGER NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create Sales table
CREATE TABLE sales (
    sale_id SERIAL PRIMARY KEY,
    customer_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    quantity INTEGER NOT NULL,
    unit_price DECIMAL(10, 2) NOT NULL,
    total_amount DECIMAL(10, 2) NOT NULL,
    sale_date DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

-- Insert sample products
INSERT INTO products (product_name, category, price, stock_quantity) VALUES
('MacBook Pro 14"', 'Electronics', 2999.99, 50),
('iPhone 15 Pro', 'Electronics', 1199.99, 100),
('Samsung Galaxy S24', 'Electronics', 899.99, 75),
('Nike Air Max 270', 'Fashion', 149.99, 200),
('Adidas Ultraboost 22', 'Fashion', 179.99, 150),
('The Great Gatsby', 'Books', 12.99, 500),
('To Kill a Mockingbird', 'Books', 14.99, 400),
('Yoga Mat Premium', 'Sports', 49.99, 100),
('Protein Powder Whey', 'Health', 39.99, 80),
('Coffee Maker Deluxe', 'Home', 299.99, 30);

-- Insert sample sales
INSERT INTO sales (customer_id, product_id, quantity, unit_price, total_amount, sale_date) VALUES
(1001, 1, 1, 2999.99, 2999.99, '2024-01-15'),
(1002, 2, 2, 1199.99, 2399.98, '2024-01-16'),
(1003, 3, 1, 899.99, 899.99, '2024-01-17'),
(1004, 4, 3, 149.99, 449.97, '2024-01-18'),
(1005, 5, 2, 179.99, 359.98, '2024-01-19'),
(1006, 6, 5, 12.99, 64.95, '2024-01-20'),
(1007, 7, 3, 14.99, 44.97, '2024-01-21'),
(1008, 8, 1, 49.99, 49.99, '2024-01-22'),
(1009, 9, 2, 39.99, 79.98, '2024-01-23'),
(1010, 10, 1, 299.99, 299.99, '2024-01-24'),
(1011, 1, 1, 2999.99, 2999.99, '2024-02-01'),
(1012, 2, 1, 1199.99, 1199.99, '2024-02-02'),
(1013, 4, 2, 149.99, 299.98, '2024-02-03'),
(1014, 6, 10, 12.99, 129.90, '2024-02-04'),
(1015, 8, 2, 49.99, 99.98, '2024-02-05');

-- Create indexes for better performance
CREATE INDEX idx_sales_customer_id ON sales(customer_id);
CREATE INDEX idx_sales_product_id ON sales(product_id);
CREATE INDEX idx_sales_sale_date ON sales(sale_date);
CREATE INDEX idx_products_category ON products(category); 