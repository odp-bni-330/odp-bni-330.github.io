const { Pool } = require('pg');
const fs = require('fs');
const path = require('path');
const os = require('os');

// Database configuration (matching the docker-compose environment)
const dbConfig = {
    host: 'ep-falling-cake-a1j2rvpd-pooler.ap-southeast-1.aws.neon.tech',
    port: 5432,
    database: 'neondb',
    user: 'neondb_owner',
    password: 'npg_G47bTrUPvdfo',
    ssl: {
        rejectUnauthorized: false
    }
};

// Linux-optimized console colors with terminal capability detection
const colors = {
    reset: '\x1b[0m',
    bright: '\x1b[1m',
    green: '\x1b[32m',
    red: '\x1b[31m',
    yellow: '\x1b[33m',
    blue: '\x1b[34m',
    magenta: '\x1b[35m',
    cyan: '\x1b[36m'
};

// Detect if we're in a color-capable terminal
const supportsColor = () => {
    if (process.env.FORCE_COLOR) return true;
    if (process.env.NO_COLOR) return false;
    if (!process.stdout.isTTY) return false;
    
    const term = process.env.TERM;
    if (term === 'dumb') return false;
    
    // Most Linux terminals support colors
    return true;
};

const colorEnabled = supportsColor();

function log(message, color = 'reset') {
    if (colorEnabled) {
        console.log(`${colors[color]}${message}${colors.reset}`);
    } else {
        console.log(message);
    }
}

function getSystemInfo() {
    return {
        platform: os.platform(),
        release: os.release(),
        arch: os.arch(),
        distro: process.env.DISTRIB_ID || 'Unknown',
        shell: process.env.SHELL || 'Unknown',
        term: process.env.TERM || 'Unknown'
    };
}

async function setupPostgreSQL() {
    const pool = new Pool(dbConfig);
    
    try {
        const sysInfo = getSystemInfo();
        log('🐧 Starting PostgreSQL Database Setup for Linux DD Simple', 'magenta');
        log(`📟 System: ${sysInfo.platform} ${sysInfo.arch} | Shell: ${path.basename(sysInfo.shell)} | Terminal: ${sysInfo.term}`, 'cyan');
        log('📍 Connecting to Neon PostgreSQL...', 'blue');
        
        // Test connection with timeout
        const client = await pool.connect();
        log('✅ Connected to PostgreSQL successfully!', 'green');
        
        // Read and execute SQL setup script
        log('📝 Reading SQL setup script...', 'blue');
        const sqlPath = path.join(__dirname, 'setup-databases.sql');
        
        if (!fs.existsSync(sqlPath)) {
            throw new Error('setup-databases.sql file not found!');
        }
        
        const sqlContent = fs.readFileSync(sqlPath, 'utf8');
        log('✅ SQL script loaded successfully!', 'green');
        
        log('🔧 Executing database setup...', 'blue');
        
        // Execute the SQL script
        const result = await client.query(sqlContent);
        
        log('✅ Database setup completed successfully!', 'green');
        
        // Verify tables were created
        log('🔍 Verifying table creation...', 'blue');
        
        const tablesQuery = `
            SELECT table_name 
            FROM information_schema.tables 
            WHERE table_schema = 'public' 
            AND table_name IN ('products', 'sales')
            ORDER BY table_name;
        `;
        
        const tablesResult = await client.query(tablesQuery);
        
        if (tablesResult.rows.length === 2) {
            log('✅ Tables verified: products, sales', 'green');
            
            // Check data
            const productCount = await client.query('SELECT COUNT(*) as count FROM products');
            const salesCount = await client.query('SELECT COUNT(*) as count FROM sales');
            
            log(`📊 Sample data loaded:`, 'cyan');
            log(`   • Products: ${productCount.rows[0].count}`, 'cyan');
            log(`   • Sales: ${salesCount.rows[0].count}`, 'cyan');
            
            // Test a sample query to ensure data integrity
            log('🧪 Testing data integrity...', 'blue');
            const testQuery = await client.query(`
                SELECT p.name, SUM(s.total_amount) as total_sales
                FROM products p
                LEFT JOIN sales s ON p.id = s.product_id
                GROUP BY p.id, p.name
                ORDER BY total_sales DESC NULLS LAST
                LIMIT 3
            `);
            
            log('✅ Top 3 products by sales:', 'green');
            testQuery.rows.forEach((row, index) => {
                const sales = row.total_sales ? `Rp ${parseInt(row.total_sales).toLocaleString('id-ID')}` : 'No sales';
                log(`   ${index + 1}. ${row.name}: ${sales}`, 'cyan');
            });
            
            // Linux-specific performance info
            log('🐧 Linux system performance:', 'yellow');
            const loadAvg = os.loadavg();
            const memInfo = {
                total: Math.round(os.totalmem() / 1024 / 1024 / 1024),
                free: Math.round(os.freemem() / 1024 / 1024 / 1024)
            };
            log(`   • Load Average: ${loadAvg[0].toFixed(2)}, ${loadAvg[1].toFixed(2)}, ${loadAvg[2].toFixed(2)}`, 'yellow');
            log(`   • Memory: ${memInfo.free}GB free / ${memInfo.total}GB total`, 'yellow');
            
        } else {
            log('⚠️  Warning: Not all tables were created', 'yellow');
        }
        
        client.release();
        log('🎉 PostgreSQL setup completed successfully!', 'green');
        
    } catch (error) {
        log('❌ PostgreSQL setup failed:', 'red');
        log(error.message, 'red');
        
        if (error.code) {
            log(`Error Code: ${error.code}`, 'red');
        }
        
        // Provide more specific error guidance for Linux
        if (error.code === '22003') {
            log('💡 This appears to be a numeric overflow error.', 'yellow');
            log('   The decimal values might be too large for the field type.', 'yellow');
        } else if (error.code === 'ENOTFOUND') {
            log('💡 DNS resolution failed. Check your internet connection.', 'yellow');
            log('   On Linux, you might need to check /etc/resolv.conf', 'yellow');
        } else if (error.code === 'ECONNREFUSED') {
            log('💡 Connection refused. Check firewall settings.', 'yellow');
            log('   Linux: sudo ufw status or iptables -L', 'yellow');
        }
        
        throw error;
    } finally {
        await pool.end();
    }
}

// Run the setup
if (require.main === module) {
    setupPostgreSQL()
        .then(() => {
            log('\n🚀 Setup completed! You can now run your application.', 'bright');
            log('💡 Try running: ./demo.sh start', 'cyan');
            log('💡 Or with systemd: systemctl --user start node-demo', 'cyan');
            process.exit(0);
        })
        .catch((error) => {
            log('\n❌ Setup failed. Please check the error above.', 'red');
            log('💡 Linux troubleshooting:', 'yellow');
            log('   • Check network: ping 8.8.8.8', 'yellow');
            log('   • Check DNS: nslookup ep-falling-cake-a1j2rvpd-pooler.ap-southeast-1.aws.neon.tech', 'yellow');
            log('   • Check firewall: sudo ufw status', 'yellow');
            process.exit(1);
        });
}

module.exports = { setupPostgreSQL }; 