package com.bni.taskmanagement.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
// import javax.annotation.processing.Generated;


/*************************** LAYER MODEL ***************************/
@Entity // menandakan bahwa Task.java adalah 'layer model'
@Table(name = "tasks") // kustomisasi nama tabel
@Data
// Lombok
    // tidak perlu membuat setter-getter secara manual
@NoArgsConstructor // constructor tanpa argumen Task
@AllArgsConstructor // constructor dengan argumen

/**
 * @NoArgsConstructor setara dengan:
 * 
 * public Task(){};
 * 
 * @AllArgsConstructor setara dengan:
 * 
 * publicTask(Long id, string Title, string description, boolean completed){
 *  this.id = id,
 *  this.Title = Title,
 *  this.description = description,
 *  this.completed = completed
 * };
 */

// representasi DB
public class Task{
    // primary🔑
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Title is required")
    @Size(min = 3, max = 100, message = "Title must be between 3 and 100 characters")

    private String title;

    @Size(max = 500, message = "Description cannot exceed 500 characters")

    private String description;

    private Boolean completed;
    
}

/*************************** END OF LAYER MODEL ***************************/