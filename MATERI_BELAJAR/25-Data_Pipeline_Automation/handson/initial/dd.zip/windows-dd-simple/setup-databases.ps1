#!/usr/bin/env pwsh
# Database Setup Script for Windows Demo

param(
    [Parameter()]
    [ValidateSet("all", "postgres", "mongodb")]
    [string]$Database = "all"
)

# Colors for PowerShell output
function Write-Info { param($Message) Write-Host "ℹ️  $Message" -ForegroundColor Blue }
function Write-Success { param($Message) Write-Host "✅ $Message" -ForegroundColor Green }
function Write-Warning { param($Message) Write-Host "⚠️  $Message" -ForegroundColor Yellow }
function Write-Error { param($Message) Write-Host "❌ $Message" -ForegroundColor Red }
function Write-Header { param($Message) Write-Host "🚀 $Message" -ForegroundColor Magenta }

function Show-Help {
    Write-Header "Database Setup Script - Help"
    Write-Host ""
    Write-Host "Usage: .\setup-databases.ps1 [database]" -ForegroundColor White
    Write-Host ""
    Write-Host "Parameters:" -ForegroundColor White
    Write-Host "  all        Setup both PostgreSQL and MongoDB (default)" -ForegroundColor Gray
    Write-Host "  postgres   Setup only PostgreSQL (Neon)" -ForegroundColor Gray
    Write-Host "  mongodb    Setup only MongoDB (Atlas)" -ForegroundColor Gray
    Write-Host ""
    Write-Host "Examples:" -ForegroundColor White
    Write-Host "  .\setup-databases.ps1" -ForegroundColor Cyan
    Write-Host "  .\setup-databases.ps1 postgres" -ForegroundColor Cyan
    Write-Host "  .\setup-databases.ps1 mongodb" -ForegroundColor Cyan
}

function Setup-PostgreSQL {
    Write-Header "Setting up PostgreSQL (Neon Database)"
    Write-Info "Please follow these steps to setup your Neon PostgreSQL database:"
    Write-Host ""
    Write-Host "1. Go to your Neon Console: " -NoNewline -ForegroundColor White
    Write-Host "https://console.neon.tech/" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "2. Select your database: " -NoNewline -ForegroundColor White
    Write-Host "neondb" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "3. Open the SQL Editor and run the following file:" -ForegroundColor White
    Write-Host "   File: " -NoNewline -ForegroundColor White
    Write-Host "setup-databases.sql" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "4. Or copy and paste the SQL commands from:" -ForegroundColor White
    $sqlPath = Join-Path $PWD "setup-databases.sql"
    Write-Host "   $sqlPath" -ForegroundColor Cyan
    Write-Host ""
    Write-Warning "Make sure to run all the SQL commands in the file!"
    Write-Host ""
    
    # Check if SQL file exists
    if (Test-Path "setup-databases.sql") {
        Write-Info "SQL setup file found: setup-databases.sql"
        Write-Host ""
        Write-Host "The SQL file contains:" -ForegroundColor White
        Write-Host "  • CREATE TABLE statements for products and sales" -ForegroundColor Gray
        Write-Host "  • Sample data for 10 products" -ForegroundColor Gray
        Write-Host "  • Sample sales data for 6 months" -ForegroundColor Gray
        Write-Host "  • Performance indexes" -ForegroundColor Gray
    } else {
        Write-Error "SQL setup file not found! Please make sure setup-databases.sql exists."
        return $false
    }
    
    Write-Host ""
    $response = Read-Host "Have you completed the PostgreSQL setup? (y/n)"
    if ($response -match "^[yY]") {
        Write-Success "PostgreSQL setup marked as complete!"
        return $true
    } else {
        Write-Warning "Please complete the PostgreSQL setup before proceeding."
        return $false
    }
}

function Setup-MongoDB {
    Write-Header "Setting up MongoDB (Atlas Database)"
    
    # Check if Node.js is available
    try {
        $nodeVersion = node --version 2>$null
        if ($LASTEXITCODE -eq 0) {
            Write-Info "Node.js found: $nodeVersion"
        } else {
            throw "Node.js not found"
        }
    }
    catch {
        Write-Error "Node.js is required to run the MongoDB setup script."
        Write-Info "Please install Node.js from: https://nodejs.org/"
        return $false
    }
    
    # Check if setup script exists
    if (-not (Test-Path "setup-mongodb.js")) {
        Write-Error "MongoDB setup script not found! Please make sure setup-mongodb.js exists."
        return $false
    }
    
    Write-Info "Running MongoDB Atlas setup script..."
    Write-Host ""
    
    try {
        # Run the MongoDB setup script
        $process = Start-Process -FilePath "node" -ArgumentList "setup-mongodb.js" -Wait -PassThru -NoNewWindow
        
        if ($process.ExitCode -eq 0) {
            Write-Success "MongoDB Atlas setup completed successfully!"
            return $true
        } else {
            Write-Error "MongoDB setup failed with exit code: $($process.ExitCode)"
            return $false
        }
    }
    catch {
        Write-Error "Failed to run MongoDB setup script: $($_.Exception.Message)"
        return $false
    }
}

function Test-DatabaseConnections {
    Write-Header "Testing Database Connections"
    
    Write-Info "Starting webapp container to test connections..."
    
    try {
        # Check if Docker is available
        docker info 2>$null | Out-Null
        if ($LASTEXITCODE -ne 0) {
            Write-Error "Docker is not running. Please start Docker Desktop first."
            return $false
        }
        
        # Start the webapp temporarily
        Write-Info "Building and starting webapp container..."
        docker-compose up -d --build webapp
        
        if ($LASTEXITCODE -eq 0) {
            Write-Info "Waiting for services to initialize..."
            Start-Sleep -Seconds 10
            
            # Test health endpoint
            try {
                $response = Invoke-RestMethod -Uri "http://localhost:3000/api/health" -TimeoutSec 30
                
                if ($response.services.postgresql -eq "healthy" -and $response.services.mongodb -eq "healthy") {
                    Write-Success "Both databases are connected and healthy!"
                    Write-Host ""
                    Write-Host "Database Status:" -ForegroundColor White
                    Write-Host "  PostgreSQL: " -NoNewline -ForegroundColor White
                    Write-Host "✅ Connected" -ForegroundColor Green
                    Write-Host "  MongoDB: " -NoNewline -ForegroundColor White
                    Write-Host "✅ Connected" -ForegroundColor Green
                    
                    return $true
                } else {
                    Write-Warning "Database connection issues detected:"
                    Write-Host "  PostgreSQL: $($response.services.postgresql)" -ForegroundColor Yellow
                    Write-Host "  MongoDB: $($response.services.mongodb)" -ForegroundColor Yellow
                    return $false
                }
            }
            catch {
                Write-Error "Failed to test database connections: $($_.Exception.Message)"
                return $false
            }
        } else {
            Write-Error "Failed to start webapp container"
            return $false
        }
    }
    catch {
        Write-Error "Error during connection test: $($_.Exception.Message)"
        return $false
    }
    finally {
        # Clean up
        Write-Info "Stopping test containers..."
        docker-compose down 2>$null | Out-Null
    }
}

# Main execution
Write-Header "Database Setup for Windows Demo"
Write-Host ""

$postgresSuccess = $true
$mongoSuccess = $true

if ($Database -eq "all" -or $Database -eq "postgres") {
    $postgresSuccess = Setup-PostgreSQL
    Write-Host ""
}

if ($Database -eq "all" -or $Database -eq "mongodb") {
    $mongoSuccess = Setup-MongoDB
    Write-Host ""
}

if ($postgresSuccess -and $mongoSuccess) {
    Write-Header "Running Connection Tests"
    $testSuccess = Test-DatabaseConnections
    
    Write-Host ""
    if ($testSuccess) {
        Write-Success "🎉 Database setup completed successfully!"
        Write-Host ""
        Write-Info "You can now run the demo with:"
        Write-Host "  .\demo.ps1 start" -ForegroundColor Cyan
        Write-Host ""
        Write-Info "Access the dashboard at:"
        Write-Host "  http://localhost:3000" -ForegroundColor Cyan
    } else {
        Write-Warning "Database setup completed but connection tests failed."
        Write-Info "Please check your database configurations and try again."
    }
} else {
    Write-Error "Database setup incomplete. Please resolve the issues above."
    Write-Host ""
    Write-Info "For help, run:"
    Write-Host "  .\setup-databases.ps1 help" -ForegroundColor Cyan
}

if ($args[0] -eq "help" -or $args[0] -eq "--help" -or $args[0] -eq "-h") {
    Show-Help
} 