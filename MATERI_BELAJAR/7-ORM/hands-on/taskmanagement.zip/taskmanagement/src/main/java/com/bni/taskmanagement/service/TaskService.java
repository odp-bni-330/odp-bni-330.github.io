package com.bni.taskmanagement.service;

import java.util.List;

import java.util.Optional;  // Ini yang benar
import org.springframework.stereotype.Service;

import com.bni.taskmanagement.model.Task;
import com.bni.taskmanagement.repository.TaskRepository;

/*************************** LAYER SERVICE ***************************/
// tempat semua business logic

@Service
public class TaskService {

    // mengkoneksikan layer service ke layer repository
    private final TaskRepository taskRepository;
    // private : access modifier, meaning the field can only be accessed within the same class.
    // final : field cannot be reassigned after it is initialized

    // constructor
    public TaskService(TaskRepository taskRepository){
        this.taskRepository = taskRepository;
    }

    // CREATE
    // method untuk membuat sebuah Object:task
    public Task createTask(Task task){
        return taskRepository.save(task);
    }

    // READ ALL
    // method untuk mengembalikan semua task dalam bentuk List of Object:Task
    public List<Task> getAllTasks(){
        // karena yang di-return ada banyak Task, maka mengembalikan List of Task
        return taskRepository.findAll();
    }

    // READ BY ID
    // method untuk mengembalikan task by ID
    public Task getTaskById(Long id) {
        Optional<Task> optionalTask = taskRepository.findById(id);
        
        // Jika task ditemukan, kembalikan task tersebut
        // Jika tidak, lempar exception (bisa disesuaikan dengan kebutuhan)
        return optionalTask.orElseThrow(() -> 
            new RuntimeException("Task not found with id: " + id));
    }

    // UPDATE
    // method untuk mengupdate task by ID
    public Task updateTask(Long id, Task taskDetails) {
        // 1. Cari task yang akan diupdate
        Task existingTask = getTaskById(id);
        
        // 2. Update field-field yang diperlukan
        existingTask.setTitle(taskDetails.getTitle());
        existingTask.setDescription(taskDetails.getDescription());
        existingTask.setCompleted(taskDetails.getCompleted());
        // (Sesuaikan dengan field yang ada di model Task Anda)
        
        // 3. Simpan perubahan
        return taskRepository.save(existingTask);
    }

    // DELETE
    // method untuk hapus task
    public void deleteTask(Long id){
        // 1. Verifikasi bahwa task ada
        Task task = getTaskById(id);
        
        // 2. Jika ada, hapus task
        taskRepository.delete(task);
    }
}

/*************************** END OF LAYER SERVICE ***************************/

/*
// VERSI AWAL (DI KELAS)
@Service
public class TaskService {

    // mengkoneksikan layer service ke layer repository
    private final TaskRepository taskRepository;
    // private : access modifier, meaning the field can only be accessed within the same class.
    // final : field cannot be reassigned after it is initialized

    // constructor
    public TaskService(TaskRepository taskRepository){
        this.taskRepository = taskRepository;
    }

    // method untuk membuat sebuah Object:task
    public Task createTask(Task task){
        return taskRepository.save(task);
    }

    // method untuk mengembalikan semua task dalam bentuk List of Object:Task
    public List<Task> getAllTasks(){
        // karena yang di-return ada banyak Task, maka mengembalikan List of Task
        return taskRepository.findAll();
    }

    // method untuk mengembalikan task by ID

    // method untuk mengupdate task by ID

    // method untuk hapus task
    public void deleteTask(Long id){
        taskRepository.deleteById(id);
    }

}
*/