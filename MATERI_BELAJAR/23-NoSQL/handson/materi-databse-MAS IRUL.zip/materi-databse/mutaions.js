const { Pool } = require("pg");
const { faker } = require("@faker-js/faker");

const pool = new Pool({
  user: "postgres",
  host: "localhost",
  database: "newbank", // sesuaikan
  password: "Ishlah123", // sesuaikan
  port: 5432,
});

async function insertMutations() {
  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    // Ambil semua ID account
    const res = await client.query("SELECT id FROM accounts");
    const accountIds = res.rows.map((row) => row.id);

    if (accountIds.length === 0) {
      throw new Error("Tabel accounts kosong. Silakan isi terlebih dahulu.");
    }

    const mutationTypes = ["credit", "debit"];
    const values = [];

    for (let i = 0; i < 50000; i++) {
      const accountId = faker.helpers.arrayElement(accountIds);
      const mutationType = faker.helpers.arrayElement(mutationTypes);
      const amount = faker.finance.amount(10000, 10000000, 2); // 10rb s/d 10jt
      const description = faker.lorem.sentence(3);
      const referenceCode = `REF${faker.string.alphanumeric(10).toUpperCase()}`;

      values.push(
        `(${accountId}, '${mutationType}', ${amount}, '${description.replace(
          /'/g,
          "''"
        )}', '${referenceCode}')`
      );
    }

    const query = `
      INSERT INTO mutations (account_id, mutation_type, amount, description, reference_code)
      VALUES ${values.join(", ")};
    `;

    await client.query(query);
    await client.query("COMMIT");
    console.log("✅ Berhasil insert 50.000 mutasi.");
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("❌ Error:", err.message);
  } finally {
    client.release();
  }
}

insertMutations();
