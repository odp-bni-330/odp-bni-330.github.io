/*
 * Written by : Bostang Palaguna
 * Date : 2025-05-28
 * File : AuthService.java
 * Deskripsi : 
 *   Kelas service yang menangani logika bisnis terkait autentikasi pengguna.
 *   Meliputi proses registrasi pengguna baru dan verifikasi kredensial saat login.
 */

 package com.example.connect_oracle_db.service; // Deklarasi package

 // Import entitas dan komponen yang dibutuhkan
 import com.example.connect_oracle_db.entity.User;
 import com.example.connect_oracle_db.repository.UserRepository;
 
 import java.util.Optional;
 
 import org.springframework.beans.factory.annotation.Autowired;
 import org.springframework.security.crypto.password.PasswordEncoder;
 import org.springframework.stereotype.Service;
 
 /************************** Layer Service **************************/
 
 @Service // Menandai kelas ini sebagai service Spring (dapat digunakan untuk injeksi dependency)
 public class AuthService {
 
     @Autowired // Injeksi repository untuk akses ke database user
     private UserRepository repo;
 
     @Autowired // Injeksi encoder untuk mengenkripsi dan memverifikasi password
     private PasswordEncoder encoder;
 
     /**
      * Mendaftarkan pengguna baru.
      * Jika username sudah ada di database, registrasi akan ditolak.
      * Password pengguna akan di-hash menggunakan encoder sebelum disimpan.
      *
      * @param username nama pengguna
      * @param password password mentah dari pengguna
      * @return pesan hasil proses registrasi
      */
     public String register(String username, String password) {
         if (repo.existsById(username)) {
             return "User already exists"; // Jika username sudah digunakan
         }
 
         // Membuat objek User baru dan mengatur atributnya
         User user = new User();
         user.setUsername(username);
         user.setPasswordHash(encoder.encode(password)); // Hash password sebelum disimpan
         user.setRole("USER"); // Secara default, pengguna baru memiliki role USER
 
         repo.save(user); // Simpan ke database
         return "Registered"; // Kembalikan pesan berhasil
     }
 
     /**
      * Memverifikasi kredensial pengguna saat login.
      * Akan mengecek apakah username ada, dan jika ada, mencocokkan password yang diberikan.
      *
      * @param username nama pengguna
      * @param password password mentah yang diberikan
      * @return true jika login berhasil, false jika gagal
      */
     public boolean login(String username, String password) {
         Optional<User> user = repo.findByUsername(username); // Cari user berdasarkan username
 
         // Jika user ditemukan, cocokkan password dengan hash yang tersimpan
         return user.isPresent() && encoder.matches(password, user.get().getPasswordHash());
     }
 }
 /************************** End of Layer Service *******************/
 