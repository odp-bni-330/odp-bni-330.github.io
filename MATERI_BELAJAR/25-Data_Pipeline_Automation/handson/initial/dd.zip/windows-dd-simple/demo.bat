@echo off
setlocal enabledelayedexpansion

:: Demo Multi-Source Data Visualization Management Script for Windows
:: Colors for Windows Command Prompt
set "RED=[91m"
set "GREEN=[92m"
set "YELLOW=[93m"
set "BLUE=[94m"
set "PURPLE=[95m"
set "CYAN=[96m"
set "NC=[0m"

:: Check if Docker is running
:check_docker
docker info >nul 2>&1
if %errorlevel% neq 0 (
    echo %RED%❌ Docker is not running. Please start Docker first.%NC%
    exit /b 1
)
goto :eof

:: Check Docker Compose availability
:check_docker_compose
docker-compose --version >nul 2>&1
if %errorlevel% neq 0 (
    docker compose version >nul 2>&1
    if %errorlevel% neq 0 (
        echo %RED%❌ Docker Compose is not available.%NC%
        exit /b 1
    ) else (
        set "DOCKER_COMPOSE_CMD=docker compose"
    )
) else (
    set "DOCKER_COMPOSE_CMD=docker-compose"
)
goto :eof

:: Start demo environment
:start_demo
echo %PURPLE%🚀 Starting Demo Environment%NC%
call :check_docker
call :check_docker_compose

echo %BLUE%ℹ️  Building and starting containers...%NC%
%DOCKER_COMPOSE_CMD% up -d --build
if %errorlevel% neq 0 (
    echo %RED%❌ Failed to start containers%NC%
    exit /b 1
)

echo %BLUE%ℹ️  Waiting for services to be ready...%NC%
timeout /t 10 /nobreak >nul

echo %GREEN%✅ Demo environment started!%NC%
echo %BLUE%ℹ️  Access the demo at: %CYAN%http://localhost:3000%NC%
goto :eof

:: Stop demo environment
:stop_demo
echo %PURPLE%🚀 Stopping Demo Environment%NC%
call :check_docker_compose
%DOCKER_COMPOSE_CMD% down
echo %GREEN%✅ Demo environment stopped!%NC%
goto :eof

:: Restart demo environment
:restart_demo
call :stop_demo
timeout /t 2 /nobreak >nul
call :start_demo
goto :eof

:: Check status
:check_status
echo %PURPLE%🚀 Demo Environment Status%NC%
call :check_docker_compose
%DOCKER_COMPOSE_CMD% ps
goto :eof

:: View logs
:view_logs
call :check_docker_compose
if "%~2"=="" (
    %DOCKER_COMPOSE_CMD% logs -f
) else (
    %DOCKER_COMPOSE_CMD% logs -f %2
)
goto :eof

:: Cleanup demo
:cleanup_demo
echo %PURPLE%🚀 Cleaning Up Demo Environment%NC%
call :check_docker_compose
echo %YELLOW%⚠️  This will remove all containers and volumes. Continue? (y/N)%NC%
set /p response=
if /i "!response!"=="y" (
    %DOCKER_COMPOSE_CMD% down -v --remove-orphans
    echo %GREEN%✅ Cleanup completed!%NC%
) else if /i "!response!"=="yes" (
    %DOCKER_COMPOSE_CMD% down -v --remove-orphans
    echo %GREEN%✅ Cleanup completed!%NC%
)
goto :eof

:: Show connection info
:show_info
echo %PURPLE%🚀 Demo Connection Information%NC%
echo.
echo %BLUE%ℹ️  🌐 Web Application: http://localhost:3000%NC%
echo %BLUE%ℹ️  🐘 PostgreSQL: Neon Cloud Database%NC%
echo %BLUE%ℹ️  🍃 MongoDB: Atlas Cloud Database%NC%
goto :eof

:: Show help
:show_help
echo %PURPLE%🚀 Demo Multi-Source Data Visualization - Help%NC%
echo.
echo Commands:
echo   start       Start the demo environment
echo   stop        Stop the demo environment
echo   restart     Restart the demo environment
echo   status      Show status of services
echo   logs [svc]  Show logs
echo   cleanup     Remove containers and volumes
echo   info        Show connection information
echo   help        Show this help
goto :eof

:: Main command router
if "%~1"=="start" call :start_demo
if "%~1"=="stop" call :stop_demo
if "%~1"=="restart" call :restart_demo
if "%~1"=="status" call :check_status
if "%~1"=="logs" call :view_logs %*
if "%~1"=="cleanup" call :cleanup_demo
if "%~1"=="info" call :show_info
if "%~1"=="help" call :show_help
if "%~1"=="--help" call :show_help
if "%~1"=="-h" call :show_help
if "%~1"=="" (
    echo %RED%❌ No command specified. Use 'help' for commands.%NC%
    call :show_help
)

:: Check for unknown commands
if not "%~1"=="start" if not "%~1"=="stop" if not "%~1"=="restart" if not "%~1"=="status" if not "%~1"=="logs" if not "%~1"=="cleanup" if not "%~1"=="info" if not "%~1"=="help" if not "%~1"=="--help" if not "%~1"=="-h" if not "%~1"=="" (
    echo %RED%❌ Unknown command: %1%NC%
    call :show_help
    exit /b 1
) 