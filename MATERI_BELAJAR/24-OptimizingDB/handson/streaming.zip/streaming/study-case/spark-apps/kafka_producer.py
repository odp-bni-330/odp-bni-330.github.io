from kafka import KafkaProducer
import json
import time
import random
from datetime import datetime, timedelta
import uuid

# Configure Kafka producer
producer = KafkaProducer(
    bootstrap_servers=['kafka:29092'],
    value_serializer=lambda v: json.dumps(v).encode('utf-8')
)

# Enhanced product data with more realistic pricing and categories
products = [
    # Electronics - High value products
    {"product_id": 1, "name": "MacBook Pro 16\"", "category": "Electronics", "price": 2500, "stock": 30, "popularity_weight": 3},
    {"product_id": 2, "name": "iPhone 15 Pro", "category": "Electronics", "price": 1200, "stock": 80, "popularity_weight": 8},
    {"product_id": 3, "name": "Samsung Galaxy S24", "category": "Electronics", "price": 1000, "stock": 60, "popularity_weight": 6},
    {"product_id": 4, "name": "Gaming Laptop RTX 4070", "category": "Electronics", "price": 1800, "stock": 25, "popularity_weight": 4},
    {"product_id": 5, "name": "iPad Air", "category": "Electronics", "price": 700, "stock": 50, "popularity_weight": 5},
    
    # Fashion - Medium value products  
    {"product_id": 6, "name": "Nike Air Jordan", "category": "Fashion", "price": 180, "stock": 100, "popularity_weight": 7},
    {"product_id": 7, "name": "Adidas Ultraboost", "category": "Fashion", "price": 150, "stock": 120, "popularity_weight": 6},
    {"product_id": 8, "name": "Levi's Jeans", "category": "Fashion", "price": 80, "stock": 200, "popularity_weight": 5},
    {"product_id": 9, "name": "Zara Jacket", "category": "Fashion", "price": 120, "stock": 90, "popularity_weight": 4},
    {"product_id": 10, "name": "Nike T-Shirt", "category": "Fashion", "price": 35, "stock": 300, "popularity_weight": 8},
    
    # Home & Garden - Low to medium value
    {"product_id": 11, "name": "Robot Vacuum", "category": "Home & Garden", "price": 300, "stock": 40, "popularity_weight": 5},
    {"product_id": 12, "name": "Air Fryer", "category": "Home & Garden", "price": 120, "stock": 80, "popularity_weight": 7},
    {"product_id": 13, "name": "Coffee Machine", "category": "Home & Garden", "price": 250, "stock": 50, "popularity_weight": 4},
    {"product_id": 14, "name": "Smart Light Bulb", "category": "Home & Garden", "price": 25, "stock": 500, "popularity_weight": 6},
    {"product_id": 15, "name": "Plant Pot Set", "category": "Home & Garden", "price": 45, "stock": 150, "popularity_weight": 3},
    
    # Books & Media - Low value, high volume
    {"product_id": 16, "name": "Programming Book", "category": "Books & Media", "price": 40, "stock": 200, "popularity_weight": 4},
    {"product_id": 17, "name": "Bluetooth Headphones", "category": "Books & Media", "price": 80, "stock": 150, "popularity_weight": 7},
    {"product_id": 18, "name": "Gaming Mouse", "category": "Books & Media", "price": 60, "stock": 180, "popularity_weight": 5},
    {"product_id": 19, "name": "Mechanical Keyboard", "category": "Books & Media", "price": 150, "stock": 70, "popularity_weight": 4},
    {"product_id": 20, "name": "USB-C Cable", "category": "Books & Media", "price": 15, "stock": 1000, "popularity_weight": 9},
]

# Customer segments with different purchasing behaviors
customer_segments = [
    {"segment": "Premium", "weight": 2, "avg_quantity": 2, "price_sensitivity": 0.1},
    {"segment": "Regular", "weight": 6, "avg_quantity": 1.5, "price_sensitivity": 0.3},
    {"segment": "Budget", "weight": 2, "avg_quantity": 1, "price_sensitivity": 0.6},
]

# Indonesian cities with population weights
locations = [
    {"city": "Jakarta", "weight": 25},
    {"city": "Surabaya", "weight": 15},
    {"city": "Bandung", "weight": 12},
    {"city": "Medan", "weight": 10},
    {"city": "Semarang", "weight": 8},
    {"city": "Yogyakarta", "weight": 7},
    {"city": "Makassar", "weight": 6},
    {"city": "Denpasar", "weight": 5},
    {"city": "Palembang", "weight": 4},
    {"city": "Malang", "weight": 3},
    {"city": "Balikpapan", "weight": 3},
    {"city": "Pontianak", "weight": 2},
]

# Payment methods with popularity
payment_methods = [
    {"method": "Credit Card", "weight": 30},
    {"method": "Debit Card", "weight": 25},
    {"method": "Digital Wallet", "weight": 25},
    {"method": "Bank Transfer", "weight": 15},
    {"method": "Cash on Delivery", "weight": 5},
]

def weighted_choice(choices, weight_key="weight"):
    """Select item based on weights"""
    total = sum(choice[weight_key] for choice in choices)
    r = random.uniform(0, total)
    upto = 0
    for choice in choices:
        if upto + choice[weight_key] >= r:
            return choice
        upto += choice[weight_key]
    return choices[-1]

def get_time_based_multiplier():
    """Simulate realistic shopping patterns based on time"""
    current_hour = datetime.now().hour
    current_day = datetime.now().weekday()  # 0=Monday, 6=Sunday
    
    # Hour-based multiplier (peak hours: 10-14, 19-22)
    if 10 <= current_hour <= 14 or 19 <= current_hour <= 22:
        hour_multiplier = 1.5
    elif 6 <= current_hour <= 9 or 15 <= current_hour <= 18:
        hour_multiplier = 1.2
    else:
        hour_multiplier = 0.5
    
    # Day-based multiplier (weekends are busier)
    if current_day in [5, 6]:  # Saturday, Sunday
        day_multiplier = 1.3
    elif current_day == 4:  # Friday
        day_multiplier = 1.1
    else:
        day_multiplier = 1.0
        
    return hour_multiplier * day_multiplier

def generate_transaction():
    """Generate realistic transaction data"""
    timestamp = datetime.now()
    
    # Select customer segment
    customer_segment = weighted_choice(customer_segments)
    
    # Select location
    location = weighted_choice(locations)
    
    # Select payment method
    payment = weighted_choice(payment_methods)
    
    # Select product based on popularity and customer segment
    product_weights = []
    for product in products:
        base_weight = product["popularity_weight"]
        
        # Adjust weight based on customer segment and price
        if customer_segment["segment"] == "Premium":
            if product["price"] > 500:
                base_weight *= 1.5
        elif customer_segment["segment"] == "Budget":
            if product["price"] < 100:
                base_weight *= 1.5
            elif product["price"] > 300:
                base_weight *= 0.3
                
        product_weights.append({"product": product, "weight": base_weight})
    
    selected_product = weighted_choice(product_weights, "weight")["product"]
    
    # Determine quantity based on customer segment and product price
    base_quantity = max(1, int(random.normalvariate(customer_segment["avg_quantity"], 0.5)))
    if selected_product["price"] > 1000:  # Expensive items typically bought in smaller quantities
        quantity = min(base_quantity, 2)
    else:
        quantity = min(base_quantity, 5)
    
    # Calculate total amount
    total_amount = selected_product["price"] * quantity
    
    # Add some price variations (discounts/promotions)
    if random.random() < 0.1:  # 10% chance of discount
        discount = random.uniform(0.05, 0.2)  # 5-20% discount
        total_amount *= (1 - discount)
    
    transaction = {
        "transaction_id": f"tx-{uuid.uuid4().hex[:12]}",
        "product_id": selected_product["product_id"],
        "product_name": selected_product["name"],
        "category": selected_product["category"],
        "quantity": quantity,
        "price_per_unit": selected_product["price"],
        "total_amount": round(total_amount, 2),
        "payment_method": payment["method"],
        "location": location["city"],
        "customer_segment": customer_segment["segment"],
        "timestamp": timestamp.strftime("%Y-%m-%d %H:%M:%S"),
        "hour_of_day": timestamp.hour,
        "day_of_week": timestamp.strftime("%A"),
        "day_of_month": timestamp.day,
        "month": timestamp.month,
        "year": timestamp.year
    }
    
    return transaction

def send_transactions(topic_name="sales_transactions", continuous=True, base_delay=0.3):
    """
    Generate and send realistic transaction data to Kafka
    """
    try:
        transaction_count = 0
        print("🚀 Starting real-time transaction data generator...")
        print("📊 Simulating realistic e-commerce transaction patterns")
        
        while True:
            # Calculate current load based on time
            time_multiplier = get_time_based_multiplier()
            
            # Adjust delay based on time (busier times = more frequent transactions)
            current_delay = base_delay / time_multiplier
            
            # Generate and send transaction
            transaction = generate_transaction()
            producer.send(topic_name, transaction)
            
            transaction_count += 1
            
            # Enhanced logging
            print(f"📦 Transaction #{transaction_count}")
            print(f"   Product: {transaction['product_name']} ({transaction['category']})")
            print(f"   Customer: {transaction['customer_segment']} from {transaction['location']}")
            print(f"   Amount: ${transaction['total_amount']:,.2f} via {transaction['payment_method']}")
            print(f"   Time: {transaction['timestamp']}")
            print(f"   Delay: {current_delay:.2f}s (multiplier: {time_multiplier:.2f})")
            print("-" * 80)
            
            # Flush every 10 transactions to ensure delivery
            if transaction_count % 10 == 0:
                producer.flush()
                print(f"✅ Flushed batch of 10 transactions (Total: {transaction_count})")
                
            time.sleep(current_delay)
            
            if not continuous:
                break
                
    except KeyboardInterrupt:
        print("\n🛑 Producer stopped by user")
        print(f"📊 Total transactions generated: {transaction_count}")
    except Exception as e:
        print(f"❌ Error generating data: {e}")
        import traceback
        traceback.print_exc()
    finally:
        producer.flush()
        producer.close()

if __name__ == "__main__":
    print("=" * 80)
    print("🏪 REAL-TIME TRANSACTION DATA GENERATOR")
    print("📈 Studi Kasus: Analisis Transaksi Real-Time")
    print("=" * 80)
    send_transactions()