from fastapi import APIRouter, HTTPException, Depends, status
from motor.motor_asyncio import AsyncIOMotorDatabase
from bson import ObjectId

from app.database import db
from app.models.book import BookModel
from app.schemas.book import BookCreate, BookUpdate  # Tambahkan BookUpdate

router = APIRouter(
    prefix="/books",
    tags=["books"],
    responses={404: {"description": "Not found"}},
)

async def get_db() -> AsyncIOMotorDatabase:
    return db.db

def convert_objectid_to_str(document):
    if document and "_id" in document:
        document["_id"] = str(document["_id"])
    return document

@router.post("/", response_model=BookModel, status_code=status.HTTP_201_CREATED)
async def create_book(book: BookCreate, database: AsyncIOMotorDatabase = Depends(get_db)):
    try:
        book_data = book.model_dump()
        result = await database.books.insert_one(book_data)
        
        created_book = await database.books.find_one({"_id": result.inserted_id})
        if not created_book:
            raise HTTPException(status_code=500, detail="Failed to retrieve created book")
        
        # Konversi ObjectId ke string sebelum validasi
        created_book = convert_objectid_to_str(created_book)
        return BookModel.model_validate(created_book)
        
    except Exception as e:
        raise HTTPException(
            status_code=400, 
            detail=f"Failed to create book: {str(e)}"
        )

@router.get("/", response_model=list[BookModel])
async def list_books(database: AsyncIOMotorDatabase = Depends(get_db)):
    try:
        books = []
        async for book in database.books.find():
            # Konversi ObjectId ke string untuk setiap dokumen
            book = convert_objectid_to_str(book)
            books.append(BookModel.model_validate(book))
        return books
    except Exception as e:
        raise HTTPException(
            status_code=500, 
            detail=f"Failed to fetch books: {str(e)}"
        )

@router.get("/{book_id}", response_model=BookModel)
async def get_book(
    book_id: str, 
    database: AsyncIOMotorDatabase = Depends(get_db)
):
    """
    Mendapatkan detail satu buku berdasarkan ID
    
    Parameters:
    - book_id: ID buku yang ingin dilihat (format ObjectId MongoDB)
    
    Returns:
    - Detail buku lengkap dalam format BookModel
    """
    try:
        # Validasi format ObjectId
        if not ObjectId.is_valid(book_id):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Format ID buku tidak valid"
            )

        # Cari buku di database
        book = await database.books.find_one({"_id": ObjectId(book_id)})
        
        if not book:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Buku tidak ditemukan"
            )

        # Konversi ObjectId ke string dan validasi dengan Pydantic
        book = convert_objectid_to_str(book)
        return BookModel.model_validate(book)
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Terjadi kesalahan: {str(e)}"
        )

@router.put("/{book_id}", response_model=BookModel)
async def update_book(
    book_id: str,
    book_update: BookUpdate,  # Pastikan BookUpdate sudah diimpor
    database: AsyncIOMotorDatabase = Depends(get_db)
):
    try:
        # Validasi ObjectId
        if not ObjectId.is_valid(book_id):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid book ID format"
            )

        # Hanya ambil field yang tidak None dari request
        update_data = {
            k: v for k, v in book_update.model_dump(exclude_unset=True).items() 
            if v is not None
        }

        if not update_data:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="No data provided for update"
            )

        # Lakukan update di MongoDB
        result = await database.books.update_one(
            {"_id": ObjectId(book_id)},
            {"$set": update_data}
        )

        if result.matched_count == 0:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Book not found"
            )

        # Ambil data yang sudah diupdate
        updated_book = await database.books.find_one({"_id": ObjectId(book_id)})
        updated_book = convert_objectid_to_str(updated_book)
        
        return BookModel.model_validate(updated_book)

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update book: {str(e)}"
        )

@router.delete("/{book_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_book(
    book_id: str,
    database: AsyncIOMotorDatabase = Depends(get_db)
):
    try:
        # Validasi ObjectId
        if not ObjectId.is_valid(book_id):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid book ID format"
            )

        # Hapus buku dari database
        result = await database.books.delete_one({"_id": ObjectId(book_id)})

        if result.deleted_count == 0:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Book not found"
            )

        # Return 204 No Content
        return None

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to delete book: {str(e)}"
        )

