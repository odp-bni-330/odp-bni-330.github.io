import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import os
import glob
import json
import time
from datetime import datetime, timedelta
import numpy as np

# Configure page settings
st.set_page_config(
    page_title="Real-Time Transaction Analytics",
    page_icon="🏪",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for better styling
st.markdown("""
<style>
    .main-header {
        font-size: 3rem;
        color: #1f77b4;
        text-align: center;
        margin-bottom: 2rem;
    }
    .metric-container {
        background-color: #f0f2f6;
        padding: 1rem;
        border-radius: 0.5rem;
        margin: 0.5rem 0;
    }
    .alert-high {
        background-color: #ffebee;
        border-left: 5px solid #f44336;
        padding: 1rem;
        margin: 0.5rem 0;
        border-radius: 0.25rem;
    }
    .alert-medium {
        background-color: #fff3e0;
        border-left: 5px solid #ff9800;
        padding: 1rem;
        margin: 0.5rem 0;
        border-radius: 0.25rem;
    }
    .alert-info {
        background-color: #e3f2fd;
        border-left: 5px solid #2196f3;
        padding: 1rem;
        margin: 0.5rem 0;
        border-radius: 0.25rem;
    }
</style>
""", unsafe_allow_html=True)

# Dashboard configuration
REFRESH_INTERVAL = 10  # seconds
CHART_UPDATE_INTERVAL = 5  # seconds
MAX_PRODUCTS_DISPLAY = 15
MAX_NOTIFICATIONS_DISPLAY = 10

def get_latest_json_data(directory):
    """Read the latest JSON file from a directory"""
    try:
        os.makedirs(directory, exist_ok=True)
        list_of_files = glob.glob(f"{directory}/*.json")
        if not list_of_files:
            return None
        
        # Get the most recent file
        latest_file = max(list_of_files, key=os.path.getctime)
        
        # Read JSON data
        with open(latest_file, 'r') as f:
            data = [json.loads(line) for line in f]
        
        if data:
            return pd.DataFrame(data)
        return None
    except Exception as e:
        st.sidebar.error(f"Error reading {directory}: {e}")
        return None

def load_all_data():
    """Load all data from different sources"""
    data = {}
    
    # Load main analytics data
    data['top_products'] = get_latest_json_data("/app/data/top_products")
    data['sales_by_category'] = get_latest_json_data("/app/data/sales_by_category")
    data['sales_by_location'] = get_latest_json_data("/app/data/sales_by_location")
    data['customer_segments'] = get_latest_json_data("/app/data/customer_segments")
    data['hourly_trends'] = get_latest_json_data("/app/data/hourly_trends")
    
    # Load notifications
    data['popular_products_alerts'] = get_latest_json_data("/app/data/notifications/popular_products")
    
    return data

def create_metrics_summary(data):
    """Create summary metrics for the dashboard"""
    try:
        metrics = {}
        
        # Calculate total sales from categories
        if data['sales_by_category'] is not None and not data['sales_by_category'].empty:
            metrics['total_sales'] = data['sales_by_category']['total_sales'].sum()
            metrics['total_transactions'] = data['sales_by_category']['transaction_count'].sum()
            metrics['avg_transaction_value'] = metrics['total_sales'] / metrics['total_transactions'] if metrics['total_transactions'] > 0 else 0
        else:
            metrics['total_sales'] = 0
            metrics['total_transactions'] = 0
            metrics['avg_transaction_value'] = 0
        
        # Calculate active locations
        if data['sales_by_location'] is not None and not data['sales_by_location'].empty:
            metrics['active_locations'] = len(data['sales_by_location'])
        else:
            metrics['active_locations'] = 0
        
        # Calculate active products
        if data['top_products'] is not None and not data['top_products'].empty:
            metrics['active_products'] = len(data['top_products'])
        else:
            metrics['active_products'] = 0
        
        return metrics
    except Exception:
        return {'total_sales': 0, 'total_transactions': 0, 'avg_transaction_value': 0, 'active_locations': 0, 'active_products': 0}

def display_notifications(data):
    """Display real-time notifications and alerts"""
    st.subheader("🚨 Live Notifications & Alerts")
    
    # Check for popular product alerts
    if data['popular_products_alerts'] is not None and not data['popular_products_alerts'].empty:
        recent_alerts = data['popular_products_alerts'].head(MAX_NOTIFICATIONS_DISPLAY)
        
        for _, alert in recent_alerts.iterrows():
            severity = alert.get('severity', 'INFO')
            alert_type = alert.get('alert_type', 'UNKNOWN')
            message = alert.get('alert_message', 'No message')
            
            if severity == 'HIGH':
                st.markdown(f'<div class="alert-high"><strong>🔥 {alert_type}</strong><br>{message}</div>', unsafe_allow_html=True)
            elif severity == 'MEDIUM':
                st.markdown(f'<div class="alert-medium"><strong>⚠️ {alert_type}</strong><br>{message}</div>', unsafe_allow_html=True)
            else:
                st.markdown(f'<div class="alert-info"><strong>ℹ️ {alert_type}</strong><br>{message}</div>', unsafe_allow_html=True)
    else:
        st.info("🔍 Monitoring for alerts... No notifications at the moment.")

def create_top_products_chart(df):
    """Create enhanced top products visualization"""
    if df is None or df.empty:
        st.info("📦 Waiting for product data...")
        return
    
    # Sort and limit products
    df_sorted = df.nlargest(MAX_PRODUCTS_DISPLAY, 'units_sold')
    
    # Create subplot with secondary y-axis
    fig = make_subplots(specs=[[{"secondary_y": True}]])
    
    # Add bars for units sold
    fig.add_trace(
        go.Bar(
            x=df_sorted['product_name'],
            y=df_sorted['units_sold'],
            name="Units Sold",
            marker_color='lightblue',
            text=df_sorted['units_sold'],
            textposition='outside'
        ),
        secondary_y=False,
    )
    
    # Add line for total sales
    fig.add_trace(
        go.Scatter(
            x=df_sorted['product_name'],
            y=df_sorted['total_sales'],
            mode='lines+markers',
            name="Total Sales ($)",
            line=dict(color='red', width=3),
            marker=dict(size=8)
        ),
        secondary_y=True,
    )
    
    # Update layout
    fig.update_layout(
        title="🏆 Top Products Performance",
        xaxis_title="Products",
        height=400,
        hovermode='x unified'
    )
    fig.update_yaxes(title_text="Units Sold", secondary_y=False)
    fig.update_yaxes(title_text="Total Sales ($)", secondary_y=True)
    
    # Rotate x-axis labels for better readability
    fig.update_xaxes(tickangle=45)
    
    st.plotly_chart(fig, use_container_width=True)
    
    # Display top products table
    with st.expander("📊 Top Products Details"):
        display_df = df_sorted[['product_name', 'category', 'units_sold', 'total_sales', 'avg_transaction_value']].round(2)
        display_df.columns = ['Product', 'Category', 'Units Sold', 'Total Sales ($)', 'Avg Transaction ($)']
        st.dataframe(display_df, use_container_width=True)

def create_category_analysis(df):
    """Create enhanced category analysis with market share"""
    if df is None or df.empty:
        st.info("📊 Waiting for category data...")
        return
    
    col1, col2 = st.columns(2)
    
    with col1:
        # Pie chart for market share
        fig_pie = px.pie(
            df,
            values='total_sales',
            names='category',
            title="🥧 Market Share by Category",
            color_discrete_sequence=px.colors.qualitative.Set3
        )
        fig_pie.update_traces(textposition='inside', textinfo='percent+label')
        st.plotly_chart(fig_pie, use_container_width=True)
    
    with col2:
        # Bar chart for detailed metrics
        fig_bar = go.Figure()
        
        fig_bar.add_trace(go.Bar(
            x=df['category'],
            y=df['total_sales'],
            name='Total Sales',
            marker_color='skyblue',
            text=df['total_sales'].round(2),
            textposition='outside'
        ))
        
        fig_bar.update_layout(
            title="💰 Sales by Category",
            xaxis_title="Category",
            yaxis_title="Total Sales ($)",
            height=400
        )
        
        st.plotly_chart(fig_bar, use_container_width=True)
    
    # Category performance table
    with st.expander("📈 Category Performance Details"):
        if 'market_share' in df.columns:
            display_df = df[['category', 'total_sales', 'transaction_count', 'market_share']].round(3)
            display_df.columns = ['Category', 'Total Sales ($)', 'Transactions', 'Market Share']
            display_df['Market Share'] = (display_df['Market Share'] * 100).round(1).astype(str) + '%'
        else:
            display_df = df[['category', 'total_sales', 'transaction_count']].round(2)
            display_df.columns = ['Category', 'Total Sales ($)', 'Transactions']
        st.dataframe(display_df, use_container_width=True)

def create_geographic_analysis(df):
    """Create geographic sales distribution analysis"""
    if df is None or df.empty:
        st.info("🌍 Waiting for location data...")
        return
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        # Geographic sales bar chart
        fig = px.bar(
            df.head(10),
            x='location',
            y='total_sales',
            color='avg_transaction_value',
            title="🗺️ Sales by Location",
            color_continuous_scale='Viridis',
            text='total_sales'
        )
        fig.update_traces(texttemplate='$%{text:,.0f}', textposition='outside')
        fig.update_layout(height=400, xaxis_title="Location", yaxis_title="Total Sales ($)")
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        # Top locations summary
        st.subheader("🏆 Top Locations")
        for idx, row in df.head(5).iterrows():
            st.metric(
                label=row['location'],
                value=f"${row['total_sales']:,.0f}",
                delta=f"{row['transaction_count']} transactions"
            )

def create_customer_segment_analysis(df):
    """Create customer segment behavior analysis"""
    if df is None or df.empty:
        st.info("👥 Waiting for customer segment data...")
        return
    
    col1, col2 = st.columns(2)
    
    with col1:
        # Segment comparison
        fig = px.bar(
            df,
            x='customer_segment',
            y=['total_sales', 'avg_transaction_value'],
            title="👥 Customer Segment Analysis",
            barmode='group',
            color_discrete_sequence=['lightcoral', 'lightblue']
        )
        fig.update_layout(height=400, xaxis_title="Customer Segment")
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        # Segment metrics
        st.subheader("📊 Segment Metrics")
        for _, row in df.iterrows():
            st.metric(
                label=f"{row['customer_segment']} Customers",
                value=f"${row['total_sales']:,.0f}",
                delta=f"Avg: ${row['avg_transaction_value']:.2f}"
            )

def create_trend_analysis(df):
    """Create trend analysis with predictions"""
    if df is None or df.empty:
        st.info("📈 Waiting for trend data...")
        return
    
    # Sort by hour for proper time series
    df_sorted = df.sort_values('hour_of_day')
    
    # Create time series chart
    fig = make_subplots(specs=[[{"secondary_y": True}]])
    
    # Add sales trend
    fig.add_trace(
        go.Scatter(
            x=df_sorted['hour_of_day'],
            y=df_sorted['total_sales'],
            mode='lines+markers',
            name='Sales Trend',
            line=dict(color='blue', width=3),
            marker=dict(size=8)
        ),
        secondary_y=False,
    )
    
    # Add transaction count
    fig.add_trace(
        go.Bar(
            x=df_sorted['hour_of_day'],
            y=df_sorted['transaction_count'],
            name='Transaction Count',
            opacity=0.6,
            marker_color='lightgreen'
        ),
        secondary_y=True,
    )
    
    fig.update_layout(
        title="📈 Hourly Sales Trends & Predictions",
        xaxis_title="Hour of Day",
        height=400,
        hovermode='x unified'
    )
    fig.update_yaxes(title_text="Total Sales ($)", secondary_y=False)
    fig.update_yaxes(title_text="Transaction Count", secondary_y=True)
    
    st.plotly_chart(fig, use_container_width=True)
    
    # Trend insights
    if not df_sorted.empty:
        peak_hour = df_sorted.loc[df_sorted['total_sales'].idxmax(), 'hour_of_day']
        peak_sales = df_sorted['total_sales'].max()
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("🕐 Peak Sales Hour", f"{int(peak_hour)}:00", f"${peak_sales:,.0f}")
        with col2:
            avg_sales = df_sorted['total_sales'].mean()
            st.metric("📊 Average Hourly Sales", f"${avg_sales:,.0f}")
        with col3:
            total_hours = len(df_sorted)
            st.metric("⏰ Active Hours", total_hours)

def main():
    """Main dashboard function"""
    # Header
    st.markdown('<h1 class="main-header">🏪 Real-Time Transaction Analytics</h1>', unsafe_allow_html=True)
    st.markdown("### 📈 Studi Kasus: Analisis Transaksi Real-Time dengan Dashboard & Notifikasi")
    
    # Sidebar controls
    st.sidebar.title("⚙️ Dashboard Controls")
    
    # Auto-refresh settings
    auto_refresh = st.sidebar.checkbox("🔄 Auto Refresh", value=True)
    refresh_interval = st.sidebar.slider("Refresh Interval (seconds)", 5, 60, REFRESH_INTERVAL)
    
    # Manual refresh button
    if st.sidebar.button("🔄 Refresh Now"):
        st.experimental_rerun()
    
    # Current time
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    st.sidebar.write(f"🕐 Last updated: {current_time}")
    
    # Load data
    with st.spinner("📊 Loading real-time data..."):
        data = load_all_data()
    
    # Create metrics summary
    metrics = create_metrics_summary(data)
    
    # Display key metrics
    st.subheader("📊 Real-Time Metrics")
    col1, col2, col3, col4, col5 = st.columns(5)
    
    with col1:
        st.metric(
            label="💰 Total Sales",
            value=f"${metrics['total_sales']:,.0f}",
            delta="5-min window"
        )
    
    with col2:
        st.metric(
            label="🛒 Transactions",
            value=f"{metrics['total_transactions']:,}",
            delta="5-min window"
        )
    
    with col3:
        st.metric(
            label="💳 Avg Transaction",
            value=f"${metrics['avg_transaction_value']:.2f}",
            delta="Current period"
        )
    
    with col4:
        st.metric(
            label="🌍 Active Locations",
            value=f"{metrics['active_locations']}",
            delta="Cities"
        )
    
    with col5:
        st.metric(
            label="📦 Active Products",
            value=f"{metrics['active_products']}",
            delta="SKUs"
        )
    
    # Notifications section
    with st.container():
        display_notifications(data)
    
    # Main analytics sections
    st.markdown("---")
    
    # Top Products Analysis
    st.subheader("🏆 Top Products Analysis")
    create_top_products_chart(data['top_products'])
    
    # Category and Geographic Analysis
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("📊 Category Performance")
        create_category_analysis(data['sales_by_category'])
    
    with col2:
        st.subheader("🌍 Geographic Distribution")
        create_geographic_analysis(data['sales_by_location'])
    
    # Customer Segments and Trends
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("👥 Customer Segments")
        create_customer_segment_analysis(data['customer_segments'])
    
    with col2:
        st.subheader("📈 Trend Analysis")
        create_trend_analysis(data['hourly_trends'])
    
    # Footer
    st.markdown("---")
    st.markdown("**🎯 Real-Time Transaction Analytics** | Powered by Kafka + Spark + Streamlit")
    
    # Auto-refresh logic
    if auto_refresh:
        time.sleep(refresh_interval)
        st.experimental_rerun()

if __name__ == "__main__":
    main()