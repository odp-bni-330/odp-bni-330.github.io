/*
 * Written by : Bostang Palaguna
 * Date : 2025-05-28
 * File : ProductRepository.java
 * Deskripsi : Spring Data JPA Repository Interface yg sediakan operasi CRUD dasar thd entitas product
 */

// src/main/java/com/example/api_caching/repository/ProductRepository.java
package com.example.api_caching.repository; // package declaration

// library import
import com.example.api_caching.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

/************************** Layer Repository **************************/
public interface ProductRepository extends JpaRepository<Product, Long> {
    // extends JpaRepository : inherit / wariskan semua operasi standar JPA

    /**
     * operasi yang bisa langsung digunakan:
     * - crud :
     *      save(), findById(), findAll(), deleteById(), count()
     * - Pagination/Sorting :
     *      findAll(Pageable pageable)
            findAll(Sort sort)
     * - Batch Operations:
     *      saveAll(), deleteAll()
     *  */ 

    // apabila ingin menambahkan method, bisa dibuat di sini.
}
/************************** End of Layer Repository *******************/
