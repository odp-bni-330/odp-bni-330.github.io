-- Membuat Tabel customers
CREATE TABLE customers (
    customer_id INT PRIMARY KEY,
    customer_name VARCHAR(255),
    region VARCHAR(50)
);

-- Membuat Tabel orders
CREATE TABLE orders (
    order_id INT PRIMARY KEY,
    customer_id INT,
    order_date DATE,
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

-- Membuat Tabel order_items
CREATE TABLE order_items (
    order_item_id INT PRIMARY KEY,
    order_id INT,
    product_name VARCHAR(255),
    quantity INT,
    unit_price DECIMAL(10, 2),
    FOREIGN KEY (order_id) REFERENCES orders(order_id)
);

-- Menyisipkan data ke dalam tabel customers
INSERT INTO customers (customer_id, customer_name, region) VALUES
(1, 'Andi', 'Jakarta'),
(2, 'Budi', 'Bandung'),
(3, 'Cici', 'Jakarta'),
(4, 'Dedi', 'Jakarta'),
(5, 'Eka', 'Surabaya');

-- Menyisipkan data ke dalam tabel orders
INSERT INTO orders (order_id, customer_id, order_date) VALUES
(101, 1, TO_DATE('2025-06-01', 'YYYY-MM-DD')),
(102, 1, TO_DATE('2025-06-15', 'YYYY-MM-DD')),
(103, 2, TO_DATE('2025-06-10', 'YYYY-MM-DD')),
(104, 3, TO_DATE('2025-06-05', 'YYYY-MM-DD')),
(105, 3, TO_DATE('2025-06-20', 'YYYY-MM-DD')),
(106, 4, TO_DATE('2025-06-08', 'YYYY-MM-DD'));

-- Menyisipkan data ke dalam tabel order_items
INSERT INTO order_items (order_item_id, order_id, product_name, quantity, unit_price) VALUES
(1, 101, 'Laptop', 1, 10000000.00),
(2, 101, 'Mouse', 2, 50000.00),
(3, 102, 'Keyboard', 1, 750000.00),
(4, 103, 'Smartphone', 1, 7000000.00),
(5, 104, 'Headphones', 2, 350000.00),
(6, 105, 'Smartwatch', 1, 1500000.00),
(7, 106, 'Tablet', 1, 5000000.00);

-- Query untuk mendapatkan nama pelanggan, total pesanan, dan total uang yang dibelanjakan
SELECT   
    c.customer_name,  
    COUNT(o.order_id) AS total_orders,  
    SUM(oi.quantity * oi.unit_price) AS total_spent
FROM   
    customers c  
LEFT JOIN 
    orders o ON c.customer_id = o.customer_id  
LEFT JOIN 
    order_items oi ON o.order_id = oi.order_id
WHERE   
    c.region = 'Jakarta'
GROUP BY   
    c.customer_id, c.customer_name
ORDER BY   
    total_spent DESC;