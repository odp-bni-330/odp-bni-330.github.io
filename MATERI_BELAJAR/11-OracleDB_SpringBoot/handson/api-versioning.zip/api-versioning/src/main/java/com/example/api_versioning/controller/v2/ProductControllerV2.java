/*
 * Written by : Bostang Palaguna
 * Date : 2025-05-28
 * File : ProductControllerV2.java
 * Deskripsi : versioning API melalui URI path
 */

/***************************************** METODE 1 : URI Path Versioning *****************************************/
// Update ProductControllerV2.java
package com.example.api_versioning.controller.v2;       // package declaration

// import library
import com.example.api_versioning.dto.v2.ProductV2;
import com.example.api_versioning.service.ProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/************************** Layer Controller **************************/
@RestController                      // Menandakan kelas ini Spring MVC Controller ; otomatis konversi return value ke JSON
@RequestMapping("/api/v2/products")  // Menentukan base path untuk endpoint
@RequiredArgsConstructor             // Buat constructor dengan parameter untuk semua field yang final : ProductService
public class ProductControllerV2 {
    
    private final ProductService productService; // Dependency Injection
    
    @GetMapping     // Menangani HTTP GET request ke path /api/v2/products
    public List<ProductV2> getAllProductsV2() {
        return productService.getAllProductsV2();   // return dalam bentuk JSON
    }
}
/************************** End of Layer Controller *******************/

/* OLD CODE (TANPTA DTO)
// src/main/java/com/example/api_versioning/controller/v2/ProductControllerV2.java
package com.example.api_versioning.controller.v2;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v2/products")
public class ProductControllerV2 {
    
    @GetMapping
    public String getAllProductsV2() {
        return "Daftar produk dengan fitur baru (Versi 2)";
    }
    
    @GetMapping("/{id}")
    public String getProductByIdV2(@PathVariable Long id) {
        return "Produk dengan ID " + id + " dengan detail tambahan (Versi 2)";
    }
}
*/
/***************************************** End of METODE 1 : URI Path Versioning *****************************************/