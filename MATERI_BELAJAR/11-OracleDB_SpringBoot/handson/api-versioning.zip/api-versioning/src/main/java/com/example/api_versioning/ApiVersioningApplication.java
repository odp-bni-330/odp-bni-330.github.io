/*
 * Written by : Bostang Palaguna
 * Date : 2025-05-28
 * File : ApiVersioningApplication.java
 * Deskripsi : Main class dari aplikasi
 */

package com.example.api_versioning; // package declaration

// import library
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/************************** main class dari aplikasi Spring Boot **************************/

@SpringBootApplication
// anotasi yang terdiri:
	// @Configuration → class sumber definisi bean Spring
	// @EnableAutoConfiguration → tambahkan bean bdskan aturan classpath
	// @ComponentScan → pindai komponen, config, services dalam paket
public class ApiVersioningApplication { // deklarasi kelas utama aplikasi

	// metode utama yang akan dijalankan pertama kali ketika aplikasi dimulai
	public static void main(String[] args) {
		// Meluncurkan app
		SpringApplication.run(ApiVersioningApplication.class, args);
	}

}

/************************** End of main class dari aplikasi Spring Boot *******************/