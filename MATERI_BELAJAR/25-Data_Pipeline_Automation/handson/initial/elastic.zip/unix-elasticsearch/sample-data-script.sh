#!/bin/bash

# Wait for Elasticsearch to be ready
echo "Waiting for Elasticsearch to be ready..."
until curl -s http://localhost:9200 > /dev/null; do
  sleep 5
done
echo "Elasticsearch is ready!"

# Create an index called "products"
echo "Creating products index..."
curl -X PUT "localhost:9200/products"

# Add documents to the index
echo "Adding sample products..."
curl -X POST "localhost:9200/products/_doc" -H "Content-Type: application/json" -d'
{
  "name": "Laptop",
  "price": 999.99,
  "in_stock": 10,
  "category": "electronics",
  "tags": ["computer", "work", "portable"]
}'

curl -X POST "localhost:9200/products/_doc" -H "Content-Type: application/json" -d'
{
  "name": "Smartphone",
  "price": 699.99,
  "in_stock": 15,
  "category": "electronics",
  "tags": ["mobile", "communication"]
}'

curl -X POST "localhost:9200/products/_doc" -H "Content-Type: application/json" -d'
{
  "name": "Headphones",
  "price": 149.99,
  "in_stock": 8,
  "category": "electronics",
  "tags": ["audio", "music", "wireless"]
}'

curl -X POST "localhost:9200/products/_doc" -H "Content-Type: application/json" -d'
{
  "name": "Coffee Maker",
  "price": 89.99,
  "in_stock": 5,
  "category": "kitchen",
  "tags": ["appliance", "morning", "beverage"]
}'

curl -X POST "localhost:9200/products/_doc" -H "Content-Type: application/json" -d'
{
  "name": "Blender",
  "price": 49.99,
  "in_stock": 12,
  "category": "kitchen",
  "tags": ["appliance", "cooking"]
}'

echo "Sample data loaded successfully!"