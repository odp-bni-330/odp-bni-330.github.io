@echo off
echo ========================================
echo   Starting Apache Airflow on Windows
echo ========================================
echo.

echo [INFO] Checking Docker Desktop status...
docker --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Docker is not running or not installed!
    echo Please start Docker Desktop and try again.
    pause
    exit /b 1
)
echo [OK] Docker is running

echo.
echo [INFO] Starting Airflow services...
docker-compose up -d

echo.
echo [INFO] Waiting for services to start...
timeout /t 10 >nul

echo.
echo [INFO] Checking service status...
docker-compose ps

echo.
echo ========================================
echo    Airflow is starting up!
echo ========================================
echo.
echo Web UI will be available at:
echo   http://localhost:8080
echo.
echo Default credentials:
echo   Username: admin
echo   Password: admin
echo.
echo To view logs: docker-compose logs -f
echo To stop: docker-compose down
echo.
echo Press any key to open Airflow in browser...
pause >nul
start http://localhost:8080 