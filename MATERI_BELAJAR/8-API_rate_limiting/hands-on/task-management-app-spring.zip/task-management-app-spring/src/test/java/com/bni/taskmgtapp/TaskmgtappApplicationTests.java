package com.bni.taskmgtapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskmgtappApplicationTests {

	@Test
	void contextLoads() {
	}

}
