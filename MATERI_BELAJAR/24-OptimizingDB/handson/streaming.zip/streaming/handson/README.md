# Hands-on: Persiapan Simulasi Kafka dan Spark Streaming

Proyek ini menyediakan simulasi hands-on lengkap untuk Apache Kafka dan Spark Streaming menggunakan Docker, sesuai dengan workflow komprehensif yang mencakup persiapan, konfigurasi, dan proses simulasi.

## 📋 Kriteria Proyek
✅ **Menggunakan Docker** - Docker Compose untuk orchestration  
✅ **Ada file .sh** - Script `run_simulation.sh` untuk automasi  
✅ **Ada file README.md** - Dokumentasi lengkap  

## 🎯 Hands-on: Persiapan Simulasi

### 1️⃣ Instalasi Apache Kafka
**Download dan setup lingkungan**
- Kafka broker dengan Confluent Platform
- Zookeeper untuk cluster management
- Kafka tools untuk management

### 2️⃣ Instalasi Spark Streaming
**Konfigurasi environment**
- Spark master dan worker nodes
- Spark SQL dengan Kafka connector
- Python environment untuk development

### 3️⃣ Verifikasi Instalasi
**Tes konektivitas dan fungsi dasar**
- Spark UI: http://localhost:8080
- Kafka broker: localhost:9092
- Container health checks

## ⚙️ Konfigurasi Kafka

### Setup Consumer
**Konfigurasi penerima data**
- Spark Streaming sebagai consumer
- Auto offset management
- Batch processing configuration

### Setup Producer
**Konfigurasi pengirim data**
- Python Kafka producer
- JSON serialization
- Batch sending optimization

### Membuat Topik
**Definisi kategori pesan**
- `transactions` topic untuk data transaksi
- Single partition untuk demo
- Replication factor 1

## 🔧 Setup Spark Streaming

### Konfigurasi Spark
**Setting parameter dan resources**
- Master-worker architecture
- Memory allocation (1GB worker)
- Core allocation (1 core worker)

### Koneksi dengan Kafka
**Integrasi source dan sink**
- Kafka bootstrap servers configuration
- Stream reading dari earliest offset
- JSON schema definition

### Definisi Transformasi
**Logika pemrosesan data**
- Window-based aggregation (1 minute)
- Group by kategori dan produk
- Real-time calculations

## 🚀 Proses Simulasi

### Langkah 1: Persiapan Data
- **Format data untuk streaming**: JSON dengan schema transaksi
- **Producer mengirim ke topik**: Automated data generation
- **Verifikasi**: Cek data di broker melalui tools

### Langkah 2: Data di Kafka
- **Tersimpan dalam topik**: Persistent storage dalam transactions topic
- **Konsumsi data dari Kafka**: Spark streaming consumer
- **Pemrosesan data streaming**: Real-time processing pipeline

### Langkah 3: Proses Data
- **Filter dan analisis**: Data transformation dan filtering
- **Penghitungan statistik**: Aggregations dan metrics
- **Pantau kinerja dan hasil**: Monitor melalui console output
- **Simpan atau visualisasikan hasil**: Output ke console dan logs

## 📊 Contoh: Analisis Transaksi

### Data Transaksi
- **ID Transaksi**: Unique identifier
- **Produk**: Product name dan category  
- **Jumlah**: Quantity dan price information
- **Harga**: Unit price dan total amount
- **Waktu**: Timestamp untuk windowing

### Analisis Real-time
- **Total penjualan per menit**: Windowed aggregation
- **Produk terlaris**: Top products by quantity
- **Deteksi anomali**: Statistical outliers (coming soon)

## 🏗️ Struktur Proyek

```
handson/
├── docker-compose.yml      # Docker orchestration
├── Dockerfile             # Custom image builds
├── run_simulation.sh       # Automation script
├── requirements.txt        # Python dependencies
├── README.md              # Dokumentasi lengkap
├── spark-apps/            # Aplikasi Spark
│   ├── kafka_producer.py     # Data generator
│   └── spark_streaming.py    # Stream processor
└── spark-data/            # Data storage directory
```

## 🚀 Quick Start

### Langkah 1: Persiapan Environment
```bash
# Jalankan script otomatis
./run_simulation.sh

# Pilih opsi 1: Start environment
```

### Langkah 2: Generate Data
```bash
# Dalam script, pilih opsi 2: Run Kafka producer
# Atau manual:
docker exec -it kafka-tools python /app/kafka_producer.py
```

### Langkah 3: Process Streaming
```bash
# Dalam script, pilih opsi 3: Run Spark Streaming
# Atau manual:
docker exec -it spark-master spark-submit --master spark://spark-master:7077 \
  --packages org.apache.spark:spark-sql-kafka-0-10_2.12:3.3.0 \
  /opt/spark-apps/spark_streaming.py
```

## 📱 Monitoring dan Observability

### Spark UI
- **URL**: http://localhost:8080
- **Features**: Job monitoring, stages, executors
- **Real-time metrics**: Processing rates, latencies

### Kafka Monitoring
- **Topic inspection**: Via Kafka tools container
- **Message verification**: Consumer group monitoring
- **Throughput metrics**: Producer/consumer rates

## 🔧 Advanced Configuration

### Skenario Simulasi Lanjutan

1. **Anomaly Detection**
   - Implement statistical anomaly detection
   - Alert system untuk unusual patterns
   - Machine learning integration

2. **Time Window Variations**
   - Hourly aggregations
   - Daily summaries  
   - Sliding vs tumbling windows

3. **Complex Transformations**
   - Multi-stream joins
   - Stateful processing
   - Custom aggregation functions

4. **Data Persistence**
   - Database integration
   - File system outputs
   - Kafka sink untuk results

## 🛠️ Troubleshooting

### Common Issues
- **Kafka connectivity**: Check container networking
- **Spark job failures**: Review Spark UI logs
- **Resource limitations**: Adjust memory/CPU allocation
- **Schema mismatches**: Verify JSON structure

### Health Checks
```bash
# Check container status
docker-compose ps

# View logs
docker-compose logs kafka
docker-compose logs spark-master

# Test Kafka connectivity
docker exec -it kafka-tools kafka-topics --bootstrap-server kafka:29092 --list
```

## 🔚 Cleanup

```bash
# Stop dan cleanup semua resources
./run_simulation.sh
# Pilih opsi 4: Stop environment

# Atau manual:
docker-compose down
docker system prune -f
```

## 📚 Learning Resources

- **Apache Kafka Documentation**: https://kafka.apache.org/documentation/
- **Spark Streaming Guide**: https://spark.apache.org/docs/latest/streaming-programming-guide.html
- **Docker Compose Reference**: https://docs.docker.com/compose/

---

**Note**: Simulasi ini dirancang untuk learning dan development. Untuk production, pertimbangkan security, scalability, dan monitoring yang lebih robust.