// MongoDB Initialization Script for Demo

// Switch to demo database
db = db.getSiblingDB('demo_db');

// Create collections and insert sample data

// Customer Collection
db.customers.insertMany([
  {
    _id: ObjectId(),
    customer_id: "CUST001",
    name: "Budi Santoso",
    email: "budi.santoso@email.com",
    age: 28,
    gender: "Male",
    location: {
      city: "Jakarta",
      province: "DKI Jakarta",
      country: "Indonesia",
      coordinates: [-6.2088, 106.8456]
    },
    preferences: {
      categories: ["Electronics", "Gaming"],
      brands: ["ASUS", "Logitech", "Samsung"],
      price_range: "Premium"
    },
    loyalty_program: {
      tier: "Gold",
      points: 1500,
      join_date: new Date("2023-01-15")
    },
    created_at: new Date("2023-01-15"),
    last_activity: new Date("2024-06-25")
  },
  {
    _id: ObjectId(),
    customer_id: "CUST002",
    name: "Sari Dewi",
    email: "sari.dewi@email.com",
    age: 32,
    gender: "Female",
    location: {
      city: "Surabaya",
      province: "Jawa Timur",
      country: "Indonesia",
      coordinates: [-7.2575, 112.7521]
    },
    preferences: {
      categories: ["Electronics", "Gadgets"],
      brands: ["Apple", "Samsung", "Canon"],
      price_range: "Premium"
    },
    loyalty_program: {
      tier: "Platinum",
      points: 2800,
      join_date: new Date("2022-08-10")
    },
    created_at: new Date("2022-08-10"),
    last_activity: new Date("2024-06-24")
  },
  {
    _id: ObjectId(),
    customer_id: "CUST003",
    name: "Ahmad Rizki",
    email: "ahmad.rizki@email.com",
    age: 25,
    gender: "Male",
    location: {
      city: "Bandung",
      province: "Jawa Barat",
      country: "Indonesia",
      coordinates: [-6.9175, 107.6191]
    },
    preferences: {
      categories: ["Electronics", "Audio"],
      brands: ["Logitech", "Sony", "JBL"],
      price_range: "Mid-range"
    },
    loyalty_program: {
      tier: "Silver",
      points: 850,
      join_date: new Date("2023-05-20")
    },
    created_at: new Date("2023-05-20"),
    last_activity: new Date("2024-06-20")
  },
  {
    _id: ObjectId(),
    customer_id: "CUST004",
    name: "Maya Sari",
    email: "maya.sari@email.com",
    age: 29,
    gender: "Female",
    location: {
      city: "Medan",
      province: "Sumatera Utara",
      country: "Indonesia",
      coordinates: [3.5952, 98.6722]
    },
    preferences: {
      categories: ["Electronics", "Photography"],
      brands: ["Canon", "Apple", "Samsung"],
      price_range: "Premium"
    },
    loyalty_program: {
      tier: "Gold",
      points: 1920,
      join_date: new Date("2022-12-05")
    },
    created_at: new Date("2022-12-05"),
    last_activity: new Date("2024-06-22")
  },
  {
    _id: ObjectId(),
    customer_id: "CUST005",
    name: "Indra Pratama",
    email: "indra.pratama@email.com",
    age: 35,
    gender: "Male",
    location: {
      city: "Yogyakarta",
      province: "DI Yogyakarta",
      country: "Indonesia",
      coordinates: [-7.7956, 110.3695]
    },
    preferences: {
      categories: ["Electronics", "Gaming", "Audio"],
      brands: ["ASUS", "Razer", "Logitech"],
      price_range: "Premium"
    },
    loyalty_program: {
      tier: "Platinum",
      points: 3200,
      join_date: new Date("2021-11-15")
    },
    created_at: new Date("2021-11-15"),
    last_activity: new Date("2024-06-26")
  }
]);

// Customer Interactions Collection
db.interactions.insertMany([
  {
    _id: ObjectId(),
    customer_id: "CUST001",
    type: "website_visit",
    action: "product_view",
    details: {
      product_name: "Laptop Gaming ASUS ROG",
      category: "Electronics",
      duration_seconds: 180,
      page_views: 3
    },
    timestamp: new Date("2024-06-25T10:30:00Z"),
    device: "desktop",
    location: "Jakarta"
  },
  {
    _id: ObjectId(),
    customer_id: "CUST001",
    type: "purchase",
    action: "completed",
    details: {
      order_id: "ORD001",
      product_name: "Mouse Gaming Logitech",
      amount: 500000,
      payment_method: "credit_card"
    },
    timestamp: new Date("2024-06-25T14:45:00Z"),
    device: "mobile",
    location: "Jakarta"
  },
  {
    _id: ObjectId(),
    customer_id: "CUST002",
    type: "email_campaign",
    action: "opened",
    details: {
      campaign_name: "Summer Sale 2024",
      subject: "Diskon Hingga 50% Elektronik",
      content_type: "promotional"
    },
    timestamp: new Date("2024-06-24T09:15:00Z"),
    device: "mobile",
    location: "Surabaya"
  },
  {
    _id: ObjectId(),
    customer_id: "CUST002",
    type: "support_ticket",
    action: "created",
    details: {
      ticket_id: "TKT001",
      category: "product_inquiry",
      priority: "medium",
      subject: "Pertanyaan tentang Tablet iPad"
    },
    timestamp: new Date("2024-06-24T11:20:00Z"),
    device: "desktop",
    location: "Surabaya"
  },
  {
    _id: ObjectId(),
    customer_id: "CUST003",
    type: "social_media",
    action: "engagement",
    details: {
      platform: "instagram",
      post_id: "POST123",
      engagement_type: "like",
      content_type: "product_showcase"
    },
    timestamp: new Date("2024-06-20T16:30:00Z"),
    device: "mobile",
    location: "Bandung"
  },
  {
    _id: ObjectId(),
    customer_id: "CUST003",
    type: "website_visit",
    action: "search",
    details: {
      search_term: "headset gaming murah",
      results_count: 15,
      clicked_result: "Headset Gaming"
    },
    timestamp: new Date("2024-06-20T17:45:00Z"),
    device: "mobile",
    location: "Bandung"
  },
  {
    _id: ObjectId(),
    customer_id: "CUST004",
    type: "newsletter",
    action: "subscribed",
    details: {
      newsletter_type: "weekly_deals",
      source: "website_popup",
      preferences: ["electronics", "cameras"]
    },
    timestamp: new Date("2024-06-22T13:10:00Z"),
    device: "desktop",
    location: "Medan"
  },
  {
    _id: ObjectId(),
    customer_id: "CUST004",
    type: "website_visit",
    action: "product_comparison",
    details: {
      products_compared: ["Camera DSLR Canon", "Camera Mirrorless Sony"],
      comparison_duration: 300,
      result_action: "add_to_wishlist"
    },
    timestamp: new Date("2024-06-22T15:25:00Z"),
    device: "desktop",
    location: "Medan"
  },
  {
    _id: ObjectId(),
    customer_id: "CUST005",
    type: "review",
    action: "submitted",
    details: {
      product_name: "Laptop Gaming ASUS ROG",
      rating: 5,
      review_text: "Sangat puas dengan performa laptop ini untuk gaming",
      verified_purchase: true
    },
    timestamp: new Date("2024-06-26T08:30:00Z"),
    device: "desktop",
    location: "Yogyakarta"
  },
  {
    _id: ObjectId(),
    customer_id: "CUST005",
    type: "loyalty_program",
    action: "points_redeemed",
    details: {
      points_used: 500,
      reward_type: "discount_voucher",
      voucher_code: "LOYAL500",
      discount_amount: 100000
    },
    timestamp: new Date("2024-06-26T12:15:00Z"),
    device: "mobile",
    location: "Yogyakarta"
  }
]);

// Product Reviews Collection
db.product_reviews.insertMany([
  {
    _id: ObjectId(),
    customer_id: "CUST001",
    product_name: "Mouse Gaming Logitech",
    rating: 4,
    review_text: "Mouse yang responsif dan nyaman digunakan untuk gaming",
    review_date: new Date("2024-06-26"),
    verified_purchase: true,
    helpful_votes: 3
  },
  {
    _id: ObjectId(),
    customer_id: "CUST005",
    product_name: "Laptop Gaming ASUS ROG",
    rating: 5,
    review_text: "Performa excellent untuk gaming dan editing video",
    review_date: new Date("2024-06-26"),
    verified_purchase: true,
    helpful_votes: 8
  },
  {
    _id: ObjectId(),
    customer_id: "CUST003",
    product_name: "Headset Gaming",
    rating: 4,
    review_text: "Audio quality bagus, tapi agak berat untuk penggunaan lama",
    review_date: new Date("2024-06-21"),
    verified_purchase: true,
    helpful_votes: 2
  }
]);

// Create indexes for better performance
db.customers.createIndex({ "customer_id": 1 }, { unique: true });
db.customers.createIndex({ "location.city": 1 });
db.customers.createIndex({ "loyalty_program.tier": 1 });

db.interactions.createIndex({ "customer_id": 1 });
db.interactions.createIndex({ "type": 1 });
db.interactions.createIndex({ "timestamp": -1 });

db.product_reviews.createIndex({ "customer_id": 1 });
db.product_reviews.createIndex({ "product_name": 1 });
db.product_reviews.createIndex({ "rating": 1 });

// Create user for application access
db.createUser({
  user: "demo_app",
  pwd: "demo_app_password",
  roles: [
    { role: "readWrite", db: "demo_db" }
  ]
});

print("✅ MongoDB demo database initialized successfully!");
print("📊 Collections created:");
print("- customers: " + db.customers.countDocuments());
print("- interactions: " + db.interactions.countDocuments());
print("- product_reviews: " + db.product_reviews.countDocuments()); 