const express = require('express');
const { Pool } = require('pg');
const { MongoClient } = require('mongodb');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// PostgreSQL connection
const pgPool = new Pool({
  host: process.env.POSTGRES_HOST || 'localhost',
  port: process.env.POSTGRES_PORT || 5434,
  database: process.env.POSTGRES_DB || 'demo_db',
  user: process.env.POSTGRES_USER || 'demo_user',
  password: process.env.POSTGRES_PASSWORD || 'demo_password',
});

// MongoDB connection
const MONGODB_URL = process.env.MONGODB_URL || 'mongodb://demo_app:demo_app_password@mongodb:27017/demo_db';
let mongoClient;
let mongoDB;

// Initialize MongoDB connection
async function connectMongoDB() {
  try {
    mongoClient = new MongoClient(MONGODB_URL);
    await mongoClient.connect();
    mongoDB = mongoClient.db('demo_db');
    console.log('✅ MongoDB terhubung');
  } catch (error) {
    console.error('❌ Error connecting to MongoDB:', error);
  }
}

// Test PostgreSQL connection
async function testPostgreSQL() {
  try {
    const client = await pgPool.connect();
    await client.query('SELECT NOW()');
    client.release();
    console.log('✅ PostgreSQL terhubung');
  } catch (error) {
    console.error('❌ Error connecting to PostgreSQL:', error);
  }
}

// Routes

// Root route - serve main page
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// PostgreSQL data endpoints
app.get('/api/postgres/sales', async (req, res) => {
  try {
    const result = await pgPool.query(`
      SELECT 
        p.name as product_name,
        SUM(s.quantity) as total_quantity,
        SUM(s.total_amount) as total_sales
      FROM sales s
      JOIN products p ON s.product_id = p.id
      GROUP BY p.id, p.name
      ORDER BY total_sales DESC
    `);
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching PostgreSQL sales data:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.get('/api/postgres/monthly-sales', async (req, res) => {
  try {
    const result = await pgPool.query(`
      SELECT 
        TO_CHAR(sale_date, 'YYYY-MM') as month,
        SUM(total_amount) as total_amount
      FROM sales
      GROUP BY TO_CHAR(sale_date, 'YYYY-MM')
      ORDER BY month
    `);
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching PostgreSQL monthly sales:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// MongoDB data endpoints
app.get('/api/mongodb/customers', async (req, res) => {
  try {
    const customers = await mongoDB.collection('customers').aggregate([
      {
        $group: {
          _id: '$location.city',
          total_customers: { $sum: 1 },
          avg_age: { $avg: '$age' }
        }
      },
      { $sort: { total_customers: -1 } }
    ]).toArray();
    res.json(customers);
  } catch (error) {
    console.error('Error fetching MongoDB customers data:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.get('/api/mongodb/interactions', async (req, res) => {
  try {
    const interactions = await mongoDB.collection('interactions').aggregate([
      {
        $group: {
          _id: '$type',
          count: { $sum: 1 }
        }
      },
      { $sort: { count: -1 } }
    ]).toArray();
    res.json(interactions);
  } catch (error) {
    console.error('Error fetching MongoDB interactions data:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Combined data endpoint
app.get('/api/combined/dashboard', async (req, res) => {
  try {
    // Get top products from PostgreSQL
    const salesResult = await pgPool.query(`
      SELECT 
        p.name as product_name,
        SUM(s.quantity) as total_quantity
      FROM sales s
      JOIN products p ON s.product_id = p.id
      GROUP BY p.id, p.name
      ORDER BY total_quantity DESC
      LIMIT 5
    `);

    // Get customer interactions from MongoDB
    const interactions = await mongoDB.collection('interactions').aggregate([
      {
        $group: {
          _id: '$type',
          count: { $sum: 1 }
        }
      }
    ]).toArray();

    res.json({
      topProducts: salesResult.rows,
      customerInteractions: interactions
    });
  } catch (error) {
    console.error('Error fetching combined dashboard data:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Health check endpoint
app.get('/api/health', async (req, res) => {
  const health = {
    status: 'OK',
    timestamp: new Date().toISOString(),
    services: {
      postgresql: 'unknown',
      mongodb: 'unknown'
    }
  };

  // Check PostgreSQL
  try {
    const client = await pgPool.connect();
    await client.query('SELECT 1');
    client.release();
    health.services.postgresql = 'healthy';
  } catch (error) {
    health.services.postgresql = 'unhealthy';
  }

  // Check MongoDB
  try {
    await mongoDB.admin().ping();
    health.services.mongodb = 'healthy';
  } catch (error) {
    health.services.mongodb = 'unhealthy';
  }

  res.json(health);
});

// Start server
async function startServer() {
  await connectMongoDB();
  await testPostgreSQL();
  
  app.listen(PORT, () => {
    console.log(`🚀 Server berjalan di http://localhost:${PORT}`);
    console.log(`📊 Dashboard tersedia di http://localhost:${PORT}`);
  });
}

// Graceful shutdown
process.on('SIGINT', async () => {
  console.log('\n🛑 Shutting down gracefully...');
  if (mongoClient) {
    await mongoClient.close();
  }
  await pgPool.end();
  process.exit(0);
});

startServer().catch(console.error); 