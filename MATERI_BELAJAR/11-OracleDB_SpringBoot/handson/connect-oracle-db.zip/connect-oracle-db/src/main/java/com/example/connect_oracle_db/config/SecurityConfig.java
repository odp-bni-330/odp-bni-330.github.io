/*
 * Written by : Bostang Palaguna
 * Date : 2025-05-28
 * File : SecurityConfig.java
 * Deskripsi : 
 *   Kelas konfigurasi untuk Spring Security.
 *   Mengatur otorisasi HTTP, mengizinkan akses tanpa autentikasi
 *   pada endpoint tertentu, serta mendefinisikan mekanisme autentikasi 
 *   berbasis HTTP Basic dan encoder untuk password.
 */

 package com.example.connect_oracle_db.config; // Mendefinisikan paket tempat kelas ini berada

 // Import library dari Spring Framework untuk konfigurasi keamanan
 import org.springframework.context.annotation.Bean;
 import org.springframework.context.annotation.Configuration;
 import org.springframework.security.config.Customizer;
 import org.springframework.security.config.annotation.web.builders.HttpSecurity;
 import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
 import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
 import org.springframework.security.crypto.password.PasswordEncoder;
 import org.springframework.security.web.SecurityFilterChain;
 
 @Configuration // Menandai bahwa ini adalah kelas konfigurasi Spring
 @EnableWebSecurity // Mengaktifkan fitur keamanan Spring Security
 public class SecurityConfig {
     
     /**
      * Konfigurasi filter keamanan untuk HTTP request.
      * - Menonaktifkan CSRF (tidak disarankan untuk aplikasi web yang menggunakan session/cookie).
      * - Mengizinkan semua akses ke endpoint /api/auth/** tanpa autentikasi.
      * - Endpoint lain membutuhkan autentikasi.
      * - Menggunakan HTTP Basic sebagai mekanisme autentikasi.
      */
     @Bean
     public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
         http
             .csrf(csrf -> csrf.disable()) // Menonaktifkan proteksi CSRF (untuk API berbasis token bisa di-disable)
             .authorizeHttpRequests(auth -> auth
                 .requestMatchers("/api/auth/**").permitAll() // Mengizinkan akses ke endpoint auth tanpa login
                 .anyRequest().authenticated() // Endpoint lain harus melalui autentikasi
             )
             .httpBasic(Customizer.withDefaults()); // Menggunakan HTTP Basic Authentication
 
         return http.build(); // Membangun dan mengembalikan SecurityFilterChain
     }
 
     /**
      * Mendefinisikan bean untuk password encoder menggunakan algoritma BCrypt.
      * BCrypt sangat direkomendasikan untuk hashing password karena aman dan adaptif.
      */
     @Bean
     public PasswordEncoder passwordEncoder(){
         return new BCryptPasswordEncoder();
     }
 }
 