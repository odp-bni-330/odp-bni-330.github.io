# Multi-Source Data Demo - Linux Edition

Demonstrasi pengambilan data dari PostgreSQL (Neon) dan MongoDB (Atlas) dengan visualisasi JavaScript yang dioptimalkan untuk Linux.

## 🐧 Quick Start for Linux

### Option 1: Automated Fix Script (Recommended)
```bash
./fix-database.sh
```

### Option 2: Manual Setup
```bash
npm install
node setup-postgres-auto.js
node setup-mongodb.js
./demo.sh start
```

### Option 3: systemd Service (Production)
```bash
./install-service.sh
systemctl --user start node-demo
```

## 🔧 Linux Requirements

- **Node.js** v16+ 
- **npm** (usually bundled with Node.js)
- **curl** or **wget** (for testing endpoints)
- **systemd** (for service management, optional)
- **Internet Connection** untuk akses cloud databases

### Installation by Distribution

#### Ubuntu/Debian
```bash
sudo apt update
sudo apt install nodejs npm curl
```

#### CentOS/RHEL
```bash
sudo yum install nodejs npm curl
# Or on newer versions:
sudo dnf install nodejs npm curl
```

#### Fedora
```bash
sudo dnf install nodejs npm curl
```

#### Arch Linux
```bash
sudo pacman -S nodejs npm curl
```

#### openSUSE
```bash
sudo zypper install nodejs npm curl
```

#### Alpine Linux
```bash
sudo apk add nodejs npm curl
```

## 🚀 Linux-Specific Features

### 1. **Advanced Terminal Support**
- Automatic color detection menggunakan `tput`
- Support untuk TERM environment variables
- Graceful fallback untuk terminal yang tidak support warna
- UTF-8 encoding detection

### 2. **System Integration**
- **systemd user services** untuk production deployment
- **journalctl** integration untuk logging
- **Process management** dengan proper signal handling
- **Resource limits** dan security constraints

### 3. **Distribution Detection**
- Automatic detection untuk Ubuntu, Debian, CentOS, Fedora, Arch, etc.
- Package manager specific installation commands
- Kernel version dan architecture detection
- Memory dan load average monitoring

### 4. **Network & Connectivity**
- Multiple HTTP client support (curl, wget, python3)
- DNS resolution testing
- Network connectivity validation
- Firewall detection dan troubleshooting

### 5. **Performance Monitoring**
- Real-time system information (/proc/meminfo, /proc/loadavg)
- Resource usage monitoring
- Process performance tracking
- Linux-specific optimization tips

## 📊 Database Architecture

### PostgreSQL (Neon Cloud)
```
Products Table:
- id (SERIAL PRIMARY KEY)
- name (VARCHAR)
- price (DECIMAL(12,2))  ← Fixed untuk IDR besar
- category (VARCHAR)

Sales Table:
- id (SERIAL PRIMARY KEY)
- product_id (INTEGER REFERENCES products)
- quantity (INTEGER)
- total_amount (DECIMAL(15,2))  ← Support sampai 999 Triliun IDR
- sale_date (DATE)
```

### MongoDB (Atlas Cloud)
```
Customers Collection:
{
  _id: ObjectId,
  name: String,
  email: String,
  location: { city: String, country: String },
  age: Number,
  loyaltyTier: String
}

Interactions Collection:
{
  _id: ObjectId,
  customerId: ObjectId,
  type: String,
  timestamp: Date,
  details: Object
}
```

## 🛠️ Linux Commands

### Basic Usage
```bash
# Fix semua database
./fix-database.sh

# Manual setup
npm install
node setup-postgres-auto.js
node setup-mongodb.js

# Jalankan demo
./demo.sh start
./demo.sh stop
./demo.sh restart
./demo.sh logs
```

### systemd Service Management
```bash
# Install sebagai service
./install-service.sh

# Service operations
systemctl --user start node-demo
systemctl --user stop node-demo
systemctl --user restart node-demo
systemctl --user status node-demo

# Enable autostart
systemctl --user enable node-demo

# View logs
journalctl --user -f -u node-demo

# Enable user lingering (persist after logout)
sudo loginctl enable-linger $USER
```

### System Monitoring
```bash
# Monitor system resources
htop
top

# Check memory usage
free -h
cat /proc/meminfo

# Check load average
uptime
cat /proc/loadavg

# Check network connectivity
ping -c 4 8.8.8.8
nslookup ep-falling-cake-a1j2rvpd-pooler.ap-southeast-1.aws.neon.tech

# Check firewall (Ubuntu/Debian)
sudo ufw status

# Check firewall (CentOS/RHEL)
sudo firewall-cmd --list-all
```

## 🌐 API Endpoints

| Endpoint | Method | Description | Linux Test |
|----------|--------|-------------|------------|
| `/api/health` | GET | Database health status | `curl http://localhost:3000/api/health` |
| `/api/postgres/sales` | GET | PostgreSQL sales data | `wget -qO- http://localhost:3000/api/postgres/sales` |
| `/api/postgres/monthly-sales` | GET | Monthly sales trend | `curl -s http://localhost:3000/api/postgres/monthly-sales \| jq` |
| `/api/mongodb/customers` | GET | MongoDB customer data | `curl http://localhost:3000/api/mongodb/customers` |
| `/api/mongodb/interactions` | GET | Customer interactions | `wget -qO- http://localhost:3000/api/mongodb/interactions` |
| `/api/combined/dashboard` | GET | Combined analytics | `curl http://localhost:3000/api/combined/dashboard` |

## 🐛 Linux Troubleshooting

### Common Issues & Solutions

#### 1. Node.js PATH Issues
```bash
# Check if Node.js is in PATH
which node
which npm

# Add to PATH if needed (add to ~/.bashrc or ~/.profile)
export PATH="$PATH:/usr/local/bin"

# Reload shell
source ~/.bashrc
```

#### 2. Permission Issues
```bash
# Fix npm permissions
npm config set prefix ~/.local
export PATH="$PATH:$HOME/.local/bin"

# Or use sudo for global installation
sudo npm install -g <package>
```

#### 3. Firewall Issues
```bash
# Ubuntu/Debian (ufw)
sudo ufw allow 3000/tcp
sudo ufw reload

# CentOS/RHEL (firewalld)
sudo firewall-cmd --permanent --add-port=3000/tcp
sudo firewall-cmd --reload

# Check if port is listening
netstat -tlnp | grep :3000
ss -tlnp | grep :3000
```

#### 4. DNS Resolution Issues
```bash
# Check DNS configuration
cat /etc/resolv.conf

# Test DNS resolution
nslookup ep-falling-cake-a1j2rvpd-pooler.ap-southeast-1.aws.neon.tech
dig ep-falling-cake-a1j2rvpd-pooler.ap-southeast-1.aws.neon.tech

# Restart NetworkManager (Ubuntu/Debian)
sudo systemctl restart NetworkManager

# Restart network (CentOS/RHEL)
sudo systemctl restart network
```

#### 5. Memory Issues
```bash
# Check memory usage
free -h
cat /proc/meminfo | grep -E "MemTotal|MemFree|MemAvailable"

# Kill processes if needed
pkill -f "node server.js"

# Clear cache
echo 3 | sudo tee /proc/sys/vm/drop_caches
```

#### 6. Service Issues
```bash
# Check service status
systemctl --user status node-demo

# View detailed logs
journalctl --user -u node-demo --no-pager

# Check systemd user directory
ls -la ~/.config/systemd/user/

# Reload systemd
systemctl --user daemon-reload
```

## 📈 Performance Optimization Linux

### 1. System Level
```bash
# Increase file descriptor limits
echo "* soft nofile 65536" | sudo tee -a /etc/security/limits.conf
echo "* hard nofile 65536" | sudo tee -a /etc/security/limits.conf

# Optimize TCP settings
echo "net.core.somaxconn = 65536" | sudo tee -a /etc/sysctl.conf
sudo sysctl -p
```

### 2. Node.js Specific
```bash
# Use production environment
export NODE_ENV=production

# Enable clustering (modify server.js)
# Use PM2 for process management
npm install -g pm2
pm2 start server.js --name "linux-dd-simple" -i max
```

### 3. Database Connections
```bash
# Monitor database connections
netstat -an | grep :5432  # PostgreSQL
netstat -an | grep :27017 # MongoDB (if local)

# Use connection pooling (already implemented in code)
```

## 🔐 Security Best Practices Linux

### 1. File Permissions
```bash
# Set proper permissions
chmod 755 *.sh
chmod 644 *.js *.json *.md
chmod 600 .env  # if you have environment files

# Check permissions
ls -la
```

### 2. User Security
```bash
# Run as non-root user (recommended)
# Never run Node.js applications as root

# Create dedicated user (optional)
sudo useradd -m -s /bin/bash nodeapp
sudo -u nodeapp ./fix-database.sh
```

### 3. Firewall Configuration
```bash
# Only allow necessary ports
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow ssh
sudo ufw allow 3000/tcp
sudo ufw enable
```

### 4. systemd Security
```bash
# The service file includes security hardening:
# - NoNewPrivileges=true
# - PrivateTmp=true
# - ProtectHome=true
# - ProtectSystem=strict
```

## 📦 Files Structure Linux

```
linux-dd-simple/
├── fix-database.sh          ← Linux optimized fix script
├── setup-postgres-auto.js   ← Enhanced PostgreSQL setup
├── install-service.sh       ← systemd service installer
├── node-demo.service        ← systemd service definition
├── setup-databases.sql      ← Fixed SQL schema
├── setup-mongodb.js         ← MongoDB Atlas setup
├── server.js                ← Express.js server
├── demo.sh                  ← Demo launcher script
├── docker-compose.yml       ← Docker configuration
├── package.json             ← Node.js dependencies
├── README-LINUX.md         ← This file
└── public/
    ├── index.html           ← Frontend dashboard
    ├── style.css            ← Styles
    └── script.js            ← JavaScript functionality
```

## 🎨 UI Features

- **Responsive Design** untuk berbagai resolusi Linux desktop
- **Real-time Charts** menggunakan Chart.js
- **Health Monitoring** untuk kedua database
- **Tab Navigation** untuk easy browsing
- **Linux-Native Icons** dengan Font Awesome
- **Dark Theme** compatible dengan Linux desktop themes

## 🔄 Sample Data

### PostgreSQL Sample
- 10 produk elektronik Indonesia (Laptop ASUS ROG, Samsung Galaxy, dll)
- 30 transaksi penjualan dari Januari-Juni 2024  
- Total penjualan: ~1.7 miliar IDR
- Format mata uang: Indonesian Rupiah (IDR)

### MongoDB Sample
- 5 customer dari kota besar Indonesia (Jakarta, Surabaya, Bandung, dll)
- 7 tipe interaksi customer (purchase, support, social media, dll)
- Customer loyalty tiers: Silver, Gold, Platinum
- Timestamp dalam format ISO 8601

## 🚀 Deployment Options Linux

### 1. Development Mode
```bash
# Direct execution
node server.js

# With auto-reload (install nodemon)
npm install -g nodemon
nodemon server.js
```

### 2. Production with systemd
```bash
# Install and enable service
./install-service.sh
systemctl --user enable node-demo
systemctl --user start node-demo

# Check status
systemctl --user status node-demo
```

### 3. Container Deployment
```bash
# Using Docker
docker-compose up -d

# Using Podman (rootless alternative)
podman-compose up -d
```

### 4. Process Manager (PM2)
```bash
# Install PM2
npm install -g pm2

# Start application
pm2 start server.js --name "linux-dd-simple"

# Enable startup script
pm2 startup
pm2 save
```

### 5. Reverse Proxy (nginx)
```bash
# Install nginx
sudo apt install nginx  # Ubuntu/Debian
sudo yum install nginx  # CentOS/RHEL

# Configure proxy (edit /etc/nginx/sites-available/default)
location / {
    proxy_pass http://localhost:3000;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection 'upgrade';
    proxy_set_header Host $host;
    proxy_cache_bypass $http_upgrade;
}
```

## 📞 Linux Support & Community

### Distribution Specific Help
- **Ubuntu**: https://askubuntu.com/
- **Debian**: https://forums.debian.net/
- **CentOS**: https://forums.centos.org/
- **Fedora**: https://ask.fedoraproject.org/
- **Arch**: https://bbs.archlinux.org/

### Commands for Getting Help
```bash
# Check distribution
lsb_release -a
cat /etc/os-release

# Check kernel version
uname -a

# Check hardware info
lscpu
lsmem
lsblk

# Check running services
systemctl --user list-units --type=service
```

---

🐧 **Happy Coding on Linux!** 

Akses dashboard di: **http://localhost:3000**

**Linux Power User Commands:**
- `./fix-database.sh` - Setup cepat dengan monitoring sistem
- `systemctl --user start node-demo` - Production service
- `journalctl --user -f -u node-demo` - Real-time logs
- `htop` - Monitor resource usage 