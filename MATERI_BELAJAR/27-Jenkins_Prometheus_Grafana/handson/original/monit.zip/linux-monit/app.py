#!/usr/bin/env python3
import time
import random
from prometheus_client import start_http_server, Counter, Gauge, Histogram
import threading

# Create metrics
REQUEST_COUNT = Counter('app_requests_total', 'Total app requests', ['method', 'endpoint'])
ACTIVE_USERS = Gauge('app_active_users', 'Number of active users')
RESPONSE_TIME = Histogram('app_response_time_seconds', 'Response time')
ERROR_RATE = Gauge('app_error_rate', 'Application error rate')
CPU_USAGE = Gauge('app_cpu_usage_percent', 'CPU usage percentage')
MEMORY_USAGE = Gauge('app_memory_usage_bytes', 'Memory usage in bytes')

def generate_dummy_data():
    """Generate dummy metrics data"""
    while True:
        # Simulate requests
        methods = ['GET', 'POST', 'PUT', 'DELETE']
        endpoints = ['/api/users', '/api/orders', '/api/products', '/api/auth']
        
        for _ in range(random.randint(1, 10)):
            method = random.choice(methods)
            endpoint = random.choice(endpoints)
            REQUEST_COUNT.labels(method=method, endpoint=endpoint).inc()
        
        # Simulate active users (between 10-100)
        ACTIVE_USERS.set(random.randint(10, 100))
        
        # Simulate response time
        RESPONSE_TIME.observe(random.uniform(0.1, 2.0))
        
        # Simulate error rate (0-5%)
        ERROR_RATE.set(random.uniform(0, 5))
        
        # Simulate CPU usage (20-80%)
        CPU_USAGE.set(random.uniform(20, 80))
        
        # Simulate memory usage (100MB - 1GB)
        MEMORY_USAGE.set(random.randint(100 * 1024 * 1024, 1024 * 1024 * 1024))
        
        # Wait before generating next batch
        time.sleep(random.uniform(5, 15))

if __name__ == '__main__':
    # Start up the server to expose the metrics
    start_http_server(8000)
    print("Metrics server started on port 8000")
    
    # Start generating dummy data in background thread
    data_thread = threading.Thread(target=generate_dummy_data, daemon=True)
    data_thread.start()
    
    # Keep the main thread alive
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("Shutting down...") 