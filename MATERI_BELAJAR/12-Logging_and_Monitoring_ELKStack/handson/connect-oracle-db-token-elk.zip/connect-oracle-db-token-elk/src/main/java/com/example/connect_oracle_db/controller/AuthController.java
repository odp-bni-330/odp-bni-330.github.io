/*
 * Written by : Bostang Palaguna
 * Date : 2025-06-02
 * File : AuthController.java
 * Deskripsi : 
 *   Controller untuk menangani endpoint autentikasi pengguna.
 *   Menyediakan endpoint untuk proses register dan login,
 *   serta berkomunikasi dengan lapisan service (`AuthService`)
 *   untuk menangani logika bisnis autentikasi.
*/

package com.example.connect_oracle_db.controller;

import com.example.connect_oracle_db.service.AuthService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * Controller untuk menangani operasi autentikasi pengguna.
 * Base URL: /api/auth
 */
/************************** Layer Controller **************************/
@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private AuthService authService;

        private static final Logger logger = LoggerFactory.getLogger(AuthController.class);

    /**
     * Endpoint untuk registrasi pengguna baru.
     * 
     * @param body Request body yang berisi username dan password
     * @return ResponseEntity dengan hasil registrasi atau pesan error
     * 
     *         HTTP Method: POST
     *         Path: /register
     * 
     *         Contoh Request Body:
     *         {
     *         "username": "user123",
     *         "password": "password123"
     *         }
     */
    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody Map<String, String> body) {
        // Ekstrak username dan password dari request body
        String username = body.get("username");
        String password = body.get("password");

        // Panggil service untuk melakukan registrasi
        Map<String, Object> result = authService.register(username, password);

        // Jika registrasi berhasil (result tidak null)
        if (result != null) {
            logger.info("REGISTER_ATTEMPT for user {}.", username);
            return ResponseEntity.ok(result);
        } else {
            // Jika username sudah ada
            logger.warn("Register failed - username already exists: {}", username);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("User already exists");
        }
    }

    /**
     * Endpoint untuk login pengguna.
     * 
     * @param body Request body yang berisi username dan password
     * @return ResponseEntity dengan token JWT dan user details jika berhasil,
     *         atau pesan error jika gagal
     * 
     *         HTTP Method: POST
     *         Path: /login
     */
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> body) {
        // Ekstrak username dan password dari request body
        String username = body.get("username");
        String password = body.get("password");

        // Panggil service untuk melakukan login
        Map<String, Object> result = authService.login(username, password);

        // Jika login berhasil (result tidak null)
        if (result != null) {
            logger.info("LOGIN_ATTEMPT for user {}", username);
            return ResponseEntity.ok(result);
        } else {
            // Jika kredensial tidak valid
            logger.warn("Login failed - invalid credentials for username: {}", username);
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body("Invalid credentials");
        }
    }

    /**
     * Endpoint untuk mendapatkan informasi pengguna yang sedang login.
     * 
     * @param authHeader Header Authorization yang berisi Bearer token
     * @return ResponseEntity dengan detail pengguna jika token valid,
     *         atau pesan error jika token tidak valid/tidak ada
     * 
     *         HTTP Method: GET
     *         Path: /me
     * 
     *         Contoh Header:
     *         Authorization: Bearer <JWT_TOKEN>
     */
    @GetMapping("/me")
    public ResponseEntity<?> getCurrentUser(@RequestHeader("Authorization") String authHeader) {
        // Validasi header Authorization
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body("Missing or invalid Authorization header");
        }

        // Ekstrak token dari header (menghilangkan "Bearer ")
        String token = authHeader.substring(7);

        // Dapatkan detail user dari token
        Map<String, Object> userDetails = authService.getUserDetailsFromToken(token);

        // Jika token valid dan user ditemukan
        if (userDetails != null) {
            return ResponseEntity.ok(userDetails);
        } else {
            // Jika token tidak valid
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body("Invalid token");
        }
    }
}
/************************** End of Layer Controller *******************/