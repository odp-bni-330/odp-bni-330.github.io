-- Membuat indeks awal
CREATE INDEX idx_region ON customers(region);
CREATE INDEX idx_customer_id ON orders(customer_id);
CREATE INDEX idx_order_id ON order_items(order_id);

-- Jalankan query pertama kali
SELECT 
    c.customer_name,  
    COUNT(o.order_id) AS total_orders,  
    SUM(oi.quantity * oi.unit_price) AS total_spent
FROM   
    customers c  
LEFT JOIN 
    orders o ON c.customer_id = o.customer_id  
LEFT JOIN 
    order_items oi ON o.order_id = oi.order_id
WHERE   
    c.region = 'Jakarta'
GROUP BY   
    c.customer_id, c.customer_name
ORDER BY   
    total_spent DESC;

-- Membuat indeks komposit
CREATE INDEX idx_customer_region ON customers(region, customer_id);
CREATE INDEX idx_order_customer ON orders(customer_id, order_id);

-- Jalankan query lagi setelah indeks komposit
SELECT 
    c.customer_name,  
    COUNT(o.order_id) AS total_orders,  
    SUM(oi.quantity * oi.unit_price) AS total_spent
FROM   
    customers c  
LEFT JOIN 
    orders o ON c.customer_id = o.customer_id  
LEFT JOIN 
    order_items oi ON o.order_id = oi.order_id
WHERE   
    c.region = 'Jakarta'
GROUP BY   
    c.customer_id, c.customer_name
ORDER BY   
    total_spent DESC;