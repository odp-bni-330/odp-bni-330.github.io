#!/bin/bash

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m' # No Color

# Helper functions
print_info() { echo -e "${BLUE}ℹ️  $1${NC}"; }
print_success() { echo -e "${GREEN}✅ $1${NC}"; }
print_warning() { echo -e "${YELLOW}⚠️  $1${NC}"; }
print_error() { echo -e "${RED}❌ $1${NC}"; }
print_header() { echo -e "${MAGENTA}🚀 $1${NC}"; }

print_header "Database Fix Script for Unix DD Simple"
echo ""

# Check if Node.js is available
if ! command -v node &> /dev/null; then
    print_error "Node.js is required to run this script."
    print_info "Please install Node.js from: https://nodejs.org/"
    exit 1
fi

# Check if npm dependencies are installed
if [ ! -d "node_modules" ]; then
    print_info "Installing npm dependencies..."
    npm install
    if [ $? -ne 0 ]; then
        print_error "Failed to install npm dependencies"
        exit 1
    fi
    print_success "Dependencies installed successfully"
fi

# Run PostgreSQL setup
print_header "Setting up PostgreSQL (Neon Database)"
if node setup-postgres-auto.js; then
    print_success "PostgreSQL setup completed successfully!"
else
    print_error "PostgreSQL setup failed"
    exit 1
fi

echo ""

# Run MongoDB setup
print_header "Setting up MongoDB (Atlas Database)"
if node setup-mongodb.js; then
    print_success "MongoDB setup completed successfully!"
else
    print_error "MongoDB setup failed"
    exit 1
fi

echo ""

# Test the application
print_header "Testing Database Connections"
print_info "Starting demo application for testing..."

# Start the demo in background
./demo.sh start > /dev/null 2>&1 &
DEMO_PID=$!

# Wait for services to start
sleep 8

# Test health endpoint
print_info "Testing health endpoint..."
HEALTH_RESPONSE=$(curl -s http://localhost:3000/api/health 2>/dev/null)
if [[ $? -eq 0 ]]; then
    if echo "$HEALTH_RESPONSE" | grep -q '"postgresql":"healthy"' && echo "$HEALTH_RESPONSE" | grep -q '"mongodb":"healthy"'; then
        print_success "Both databases are healthy!"
        
        # Test PostgreSQL data
        print_info "Testing PostgreSQL data..."
        PG_RESPONSE=$(curl -s http://localhost:3000/api/postgres/sales 2>/dev/null)
        if [[ $? -eq 0 ]] && [[ ${#PG_RESPONSE} -gt 10 ]]; then
            print_success "PostgreSQL data loading successfully!"
        else
            print_warning "PostgreSQL data test failed"
        fi
        
        # Test MongoDB data
        print_info "Testing MongoDB data..."
        MONGO_RESPONSE=$(curl -s http://localhost:3000/api/mongodb/customers 2>/dev/null)
        if [[ $? -eq 0 ]] && [[ ${#MONGO_RESPONSE} -gt 10 ]]; then
            print_success "MongoDB data loading successfully!"
        else
            print_warning "MongoDB data test failed"
        fi
        
    else
        print_warning "Some database connections are unhealthy"
        echo "Health response: $HEALTH_RESPONSE"
    fi
else
    print_error "Failed to connect to health endpoint"
fi

# Stop the demo
print_info "Stopping test application..."
./demo.sh stop > /dev/null 2>&1

print_header "Database Fix Complete!"
echo ""
print_success "🎉 All databases have been set up successfully!"
echo ""
print_info "You can now run the demo with:"
echo -e "${CYAN}  ./demo.sh start${NC}"
echo ""
print_info "Access the dashboard at:"
echo -e "${CYAN}  http://localhost:3000${NC}" 