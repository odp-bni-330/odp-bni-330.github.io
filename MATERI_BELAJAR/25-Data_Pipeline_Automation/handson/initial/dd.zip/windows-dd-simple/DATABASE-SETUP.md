# Database Setup Guide for Windows Demo

This guide will help you set up the required cloud databases (PostgreSQL and MongoDB) for the Windows demo.

## 🎯 Quick Setup

Run the automated setup script:

```powershell
.\setup-databases.ps1
```

This script will guide you through setting up both databases and test the connections.

## 📋 Manual Setup Instructions

### 1. PostgreSQL Setup (Neon Cloud)

#### Step 1: Access Neon Console
1. Go to [Neon Console](https://console.neon.tech/)
2. Log in to your account
3. Select your database: `neondb`

#### Step 2: Run SQL Setup
1. Open the **SQL Editor** in Neon Console
2. Copy the contents of `setup-databases.sql` file
3. Paste and execute the SQL commands

The SQL script will create:
- ✅ `products` table with 10 sample products
- ✅ `sales` table with 6 months of sample sales data
- ✅ Performance indexes
- ✅ Proper relationships between tables

#### Step 3: Verify Setup
After running the SQL, you should see:
```sql
Database initialized successfully!
total_products: 10
total_sales: 30
```

### 2. MongoDB Setup (Atlas Cloud)

#### Option A: Automated Setup (Recommended)
```powershell
node setup-mongodb.js
```

#### Option B: Manual Setup
1. Go to [MongoDB Atlas](https://cloud.mongodb.com/)
2. Log in to your account
3. Select your cluster: `Cluster0`
4. Go to **Collections** > **Create Database**
5. Create database: `demo_db`
6. Create collections: `customers` and `interactions`
7. Import the sample data manually

The MongoDB setup will create:
- ✅ `customers` collection with 5 sample customers
- ✅ `interactions` collection with customer interaction data
- ✅ Proper indexes for performance

## 🔧 Connection Details

### PostgreSQL (Neon)
- **Host**: `ep-falling-cake-a1j2rvpd-pooler.ap-southeast-1.aws.neon.tech`
- **Port**: `5432`
- **Database**: `neondb`
- **User**: `neondb_owner`
- **SSL**: Required

### MongoDB (Atlas)
- **Connection String**: `mongodb+srv://fauziweb19:MongoGoGo@cluster0.eorwj9n.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0`
- **Database**: `demo_db`
- **Collections**: `customers`, `interactions`

## 🧪 Testing Setup

### Test Database Connections
```powershell
# Start the demo
.\demo.ps1 start

# Check health endpoint
curl http://localhost:3000/api/health
```

Expected response:
```json
{
  "status": "OK",
  "timestamp": "2024-06-23T...",
  "services": {
    "postgresql": "healthy",
    "mongodb": "healthy"
  }
}
```

### Test API Endpoints

#### PostgreSQL Data
```powershell
# Test sales data
curl http://localhost:3000/api/postgres/sales

# Test monthly sales
curl http://localhost:3000/api/postgres/monthly-sales
```

#### MongoDB Data
```powershell
# Test customer data
curl http://localhost:3000/api/mongodb/customers

# Test interaction data
curl http://localhost:3000/api/mongodb/interactions
```

## 🐛 Troubleshooting

### Common Issues

#### 1. "relation 'sales' does not exist"
**Problem**: PostgreSQL tables not created
**Solution**: Run the SQL setup script in Neon Console

#### 2. "MongoNetworkError: connection refused"
**Problem**: MongoDB connection string incorrect
**Solution**: Verify Atlas connection string and whitelist IP

#### 3. "SSL connection required"
**Problem**: PostgreSQL SSL not configured
**Solution**: Ensure SSL is enabled in connection (already configured)

#### 4. "Authentication failed"
**Problem**: Database credentials incorrect
**Solution**: Verify username/password in connection strings

### Debug Steps

1. **Check Docker**:
   ```powershell
   docker info
   ```

2. **Check Node.js**:
   ```powershell
   node --version
   ```

3. **Check Application Logs**:
   ```powershell
   .\demo.ps1 logs webapp
   ```

4. **Test Individual Connections**:
   ```powershell
   # PostgreSQL only
   .\setup-databases.ps1 postgres
   
   # MongoDB only
   .\setup-databases.ps1 mongodb
   ```

## 📊 Sample Data Overview

### PostgreSQL Data
- **Products**: 10 electronic products (laptops, phones, accessories)
- **Sales**: 30 sales transactions across 6 months
- **Revenue**: ~1.5 billion IDR in total sales

### MongoDB Data
- **Customers**: 5 customers from different Indonesian cities
- **Interactions**: 7 different types of customer interactions
- **Loyalty Tiers**: Silver, Gold, Platinum customers

## 🔄 Resetting Data

### Reset PostgreSQL
Run the SQL setup script again - it uses `ON CONFLICT DO NOTHING` to prevent duplicates.

### Reset MongoDB
```powershell
node setup-mongodb.js
```
The script automatically clears existing data before inserting new data.

## 📞 Need Help?

If you encounter issues:

1. Check the main [README.md](README.md) for general troubleshooting
2. Run the health check: `.\demo.ps1 info`
3. Check application logs: `.\demo.ps1 logs`
4. Verify your cloud database access and credentials

---

🎉 **Once setup is complete, you can run the full demo with `.\demo.ps1 start`** 