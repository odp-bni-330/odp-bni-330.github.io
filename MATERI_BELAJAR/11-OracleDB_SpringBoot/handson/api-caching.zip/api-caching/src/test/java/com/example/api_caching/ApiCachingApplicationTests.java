package com.example.api_caching;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiCachingApplicationTests {

	@Test
	void contextLoads() {
	}

}
