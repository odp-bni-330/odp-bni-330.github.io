# 📊 Workflow Automation dengan Data dari Neon PostgreSQL

Panduan ini menjelaskan cara menjalankan workflow Airflow menggunakan **data real** dari database Neon PostgreSQL, bukan data yang di-generate.

## 🗄️ Setup Database Neon

### 1. Struktur Table yang Dibutuhkan

Buat table `employees` di database Neon Anda dengan struktur berikut:

```sql
-- Buat table employees
CREATE TABLE IF NOT EXISTS employees (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    age INTEGER NOT NULL,
    salary DECIMAL(10,2) NOT NULL,
    salary_category VARCHAR(20)
);

-- Buat index untuk performance
CREATE INDEX idx_employees_salary ON employees(salary);
CREATE INDEX idx_employees_age ON employees(age);
```

### 2. Insert Sample Data

```sql
-- Insert data sample untuk testing
INSERT INTO employees (name, age, salary, salary_category) VALUES
('John Doe', 28, 75000.00, 'Mid-Level'),
('Jane Smith', 32, 85000.00, 'Senior'),
('Bob Johnson', 24, 55000.00, 'Junior'),
('Alice Brown', 35, 95000.00, 'Senior'),
('Charlie Davis', 29, 70000.00, 'Mid-Level'),
('Diana Wilson', 26, 60000.00, 'Junior'),
('Frank Miller', 40, 120000.00, 'Senior'),
('Grace Lee', 31, 80000.00, 'Mid-Level'),
('Henry Garcia', 27, 65000.00, 'Junior'),
('Ivy Martinez', 38, 110000.00, 'Senior'),
('Jack Anderson', 25, 58000.00, 'Junior'),
('Kelly Taylor', 33, 88000.00, 'Mid-Level'),
('Larry Clark', 45, 135000.00, 'Senior'),
('Monica Rodriguez', 30, 77000.00, 'Mid-Level'),
('Nathan Lewis', 26, 62000.00, 'Junior'),
('Olivia Walker', 36, 92000.00, 'Senior'),
('Paul Hall', 28, 72000.00, 'Mid-Level'),
('Quinn Young', 41, 125000.00, 'Senior'),
('Rachel King', 29, 75000.00, 'Mid-Level'),
('Steve Wright', 34, 90000.00, 'Senior');

-- Update salary_category berdasarkan salary (jika belum diset)
UPDATE employees SET salary_category = 
    CASE 
        WHEN salary < 65000 THEN 'Junior'
        WHEN salary BETWEEN 65000 AND 89999 THEN 'Mid-Level'
        WHEN salary >= 90000 THEN 'Senior'
        ELSE 'Unknown'
    END
WHERE salary_category IS NULL;
```

### 3. Verifikasi Data

```sql
-- Cek total records
SELECT COUNT(*) as total_employees FROM employees;

-- Cek distribusi salary category
SELECT salary_category, COUNT(*) as count, 
       ROUND(AVG(salary), 2) as avg_salary,
       MIN(salary) as min_salary,
       MAX(salary) as max_salary
FROM employees 
GROUP BY salary_category 
ORDER BY avg_salary;

-- Preview data
SELECT * FROM employees ORDER BY id LIMIT 10;
```

## 🔧 Konfigurasi Airflow Connection

### 1. Setup Neon Connection di Airflow UI

1. Akses Airflow UI: **http://localhost:8080**
2. Login dengan: `admin` / `admin`
3. Navigasi: **Admin** → **Connections**
4. Klik **+** untuk create connection baru

**Connection Details:**
```
Connection Id: neon_postgres
Connection Type: Postgres
Host: ep-falling-cake-a1j2rvpd-pooler.ap-southeast-1.aws.neon.tech
Schema: airflow
Login: neondb_owner
Password: npg_G47bTrUPvdfo
Port: 5432
Extra: {"sslmode": "require"}
```

### 2. Test Connection

```sql
-- Test dengan SQL query di Airflow
SELECT version();
SELECT current_database(), current_user;
SELECT COUNT(*) FROM employees;
```

## 🚀 Cara Menjalankan

### 1. Setup Database
```bash
# Test koneksi ke Neon
./test-neon-connection.sh

# Buat table dan insert data menggunakan psql
docker run --rm -it postgres:13 psql "postgresql://neondb_owner:npg_G47bTrUPvdfo@ep-falling-cake-a1j2rvpd-pooler.ap-southeast-1.aws.neon.tech/airflow?sslmode=require"
```

### 2. Setup Airflow Connection
1. Start Airflow: `docker-compose up -d`
2. Akses UI: http://localhost:8080
3. Buat connection `neon_postgres` seperti dijelaskan di atas

### 3. Buat DAG untuk Data Neon
Buat file `dags/neon_data_processing_dag.py` dengan kode berikut:

```python
from datetime import datetime, timedelta
import pandas as pd
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
import logging

default_args = {
    'owner': 'data-team',
    'depends_on_past': False,
    'start_date': datetime(2024, 1, 1),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5)
}

dag = DAG(
    'neon_data_processing_workflow',
    default_args=default_args,
    description='Data processing workflow using Neon PostgreSQL data',
    schedule_interval=timedelta(hours=6),
    catchup=False,
    tags=['neon', 'database', 'etl']
)

def extract_data_from_neon(**context):
    """Extract data from Neon PostgreSQL"""
    postgres_hook = PostgresHook(postgres_conn_id='neon_postgres')
    
    sql_query = """
    SELECT id, name, age, salary, salary_category,
           CURRENT_TIMESTAMP as extracted_at
    FROM employees 
    ORDER BY id;
    """
    
    df = postgres_hook.get_pandas_df(sql_query)
    csv_path = '/opt/airflow/data/neon_employees_data.csv'
    df.to_csv(csv_path, index=False)
    
    logging.info(f"Extracted {len(df)} records from Neon PostgreSQL")
    return csv_path

def process_and_analyze_data(**context):
    """Process the extracted data and create analytics"""
    df = pd.read_csv('/opt/airflow/data/neon_employees_data.csv')
    
    # Add processed columns
    df['age_group'] = pd.cut(df['age'], bins=[20, 30, 40, 50, 60], 
                           labels=['20-29', '30-39', '40-49', '50-59'])
    df['salary_percentile'] = pd.qcut(df['salary'], q=4, 
                                    labels=['Q1', 'Q2', 'Q3', 'Q4'])
    
    # Calculate statistics
    stats = {
        'total_employees': len(df),
        'avg_age': df['age'].mean(),
        'avg_salary': df['salary'].mean(),
        'min_salary': df['salary'].min(),
        'max_salary': df['salary'].max()
    }
    
    # Save processed data
    df.to_csv('/opt/airflow/data/processed_neon_data.csv', index=False)
    
    # Save statistics
    stats_df = pd.DataFrame([stats])
    stats_df.to_csv('/opt/airflow/data/neon_statistics.csv', index=False)
    
    logging.info(f"Processed data: {stats}")
    return stats

def generate_report(**context):
    """Generate HTML report"""
    df = pd.read_csv('/opt/airflow/data/processed_neon_data.csv')
    stats = pd.read_csv('/opt/airflow/data/neon_statistics.csv')
    
    html_content = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Neon PostgreSQL Data Analysis Report</title>
        <style>
            body {{ font-family: Arial, sans-serif; margin: 40px; background: #f5f7fa; }}
            .container {{ max-width: 1000px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; }}
            h1 {{ color: #2c3e50; text-align: center; }}
            .stats {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin: 20px 0; }}
            .stat-card {{ background: #3498db; color: white; padding: 20px; border-radius: 8px; text-align: center; }}
            table {{ width: 100%; border-collapse: collapse; margin: 20px 0; }}
            th, td {{ padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }}
            th {{ background: #3498db; color: white; }}
        </style>
    </head>
    <body>
        <div class="container">
            <h1>📊 Neon PostgreSQL Employee Data Analysis</h1>
            
            <div class="stats">
                <div class="stat-card">
                    <h3>{int(stats['total_employees'].iloc[0])}</h3>
                    <p>Total Employees</p>
                </div>
                <div class="stat-card">
                    <h3>{stats['avg_age'].iloc[0]:.1f}</h3>
                    <p>Average Age</p>
                </div>
                <div class="stat-card">
                    <h3>${stats['avg_salary'].iloc[0]:,.0f}</h3>
                    <p>Average Salary</p>
                </div>
            </div>
            
            <h2>Employee Distribution by Category</h2>
            <table>
                <tr><th>Category</th><th>Count</th><th>Avg Salary</th></tr>
    """
    
    category_stats = df.groupby('salary_category').agg({
        'id': 'count',
        'salary': 'mean'
    }).round(2)
    
    for category, row in category_stats.iterrows():
        html_content += f"<tr><td>{category}</td><td>{int(row['id'])}</td><td>${row['salary']:,.0f}</td></tr>"
    
    html_content += f"""
            </table>
            <p><strong>Report Generated:</strong> {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}</p>
            <p><strong>Data Source:</strong> Neon PostgreSQL Database</p>
        </div>
    </body>
    </html>
    """
    
    with open('/opt/airflow/data/neon_data_report.html', 'w') as f:
        f.write(html_content)
    
    logging.info("HTML report generated successfully")

# Task definitions
extract_task = PythonOperator(
    task_id='extract_from_neon',
    python_callable=extract_data_from_neon,
    dag=dag
)

process_task = PythonOperator(
    task_id='process_data',
    python_callable=process_and_analyze_data,
    dag=dag
)

report_task = PythonOperator(
    task_id='generate_report',
    python_callable=generate_report,
    dag=dag
)

# Task dependencies
extract_task >> process_task >> report_task
```

### 4. Run Workflow
1. Copy DAG file ke folder `dags/`
2. Akses Airflow UI: http://localhost:8080
3. Enable DAG `neon_data_processing_workflow`
4. Trigger manual run

## 📊 Output Files

Workflow akan menghasilkan:

1. **`data/neon_employees_data.csv`** - Data mentah dari Neon
2. **`data/processed_neon_data.csv`** - Data yang sudah diproses
3. **`data/neon_statistics.csv`** - Statistik summary
4. **`data/neon_data_report.html`** - Laporan HTML

## 🔍 Monitoring & Troubleshooting

### Test Koneksi Database
```bash
# Test manual menggunakan psql
docker run --rm postgres:13 psql "postgresql://neondb_owner:npg_G47bTrUPvdfo@ep-falling-cake-a1j2rvpd-pooler.ap-southeast-1.aws.neon.tech/airflow?sslmode=require" -c "SELECT COUNT(*) FROM employees;"
```

### View Logs
```bash
# Lihat logs Airflow
docker-compose logs airflow-worker
docker-compose logs airflow-scheduler

# Logs bisa juga dilihat di Airflow UI → DAGs → [DAG Name] → Graph → [Task] → Logs
```

### Validasi Data
```sql
-- Query untuk validasi di Neon console
SELECT 
    salary_category, 
    COUNT(*) as count,
    AVG(age) as avg_age,
    AVG(salary) as avg_salary
FROM employees 
GROUP BY salary_category;
```

## 🎯 Perbedaan dengan Generated Data

| Aspek | Generated Data | Neon Database Data |
|-------|---------------|-------------------|
| **Source** | Python random generator | Real database records |
| **Consistency** | Berbeda setiap run | Konsisten dari database |
| **Scalability** | Limited by memory | Limited by database |
| **Real-time** | Static generation | Dynamic dari DB |
| **Data Quality** | Artificial patterns | Real business data |

## 💡 Best Practices

1. **Index Database**: Pastikan ada index pada kolom yang sering di-query
2. **Connection Pooling**: Gunakan connection pooling untuk performance
3. **Error Handling**: Tambahkan retry logic untuk database connectivity
4. **Data Validation**: Validasi data sebelum processing
5. **Monitoring**: Setup alerts untuk task failures

## 🔧 Advanced Features

### Custom Queries
Modify SQL query sesuai kebutuhan:
```sql
-- Filter data berdasarkan kriteria tertentu
SELECT * FROM employees 
WHERE age BETWEEN 25 AND 35 
AND salary > 70000;

-- Aggregate data by department (jika ada kolom department)
SELECT department, COUNT(*), AVG(salary)
FROM employees 
GROUP BY department;
```

### Incremental Loading
Untuk data yang besar, gunakan incremental loading:
```python
# Hanya ambil data yang baru/berubah
sql_query = """
SELECT * FROM employees 
WHERE updated_at > %(last_update)s
ORDER BY id;
"""
```

---

**🎉 Happy Data Processing dengan Real Neon Data! 🎉** 