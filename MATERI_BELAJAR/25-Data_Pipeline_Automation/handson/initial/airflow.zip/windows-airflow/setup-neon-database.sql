-- Setup Neon Database for Airflow Data Processing
-- Execute this script in your Neon Console or via psql

-- 1. Create employees table
CREATE TABLE IF NOT EXISTS employees (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    age INTEGER NOT NULL CHECK (age >= 18 AND age <= 65),
    salary DECIMAL(10,2) NOT NULL CHECK (salary > 0),
    salary_category VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_employees_salary ON employees(salary);
CREATE INDEX IF NOT EXISTS idx_employees_age ON employees(age);
CREATE INDEX IF NOT EXISTS idx_employees_category ON employees(salary_category);

-- 3. Insert sample data
INSERT INTO employees (name, age, salary, salary_category) VALUES
('John Doe', 28, 75000.00, 'Mid-Level'),
('Jane Smith', 32, 85000.00, 'Senior'),
('Bob Johnson', 24, 55000.00, 'Junior'),
('Alice Brown', 35, 95000.00, 'Senior'),
('Charlie Davis', 29, 70000.00, 'Mid-Level'),
('Diana Wilson', 26, 60000.00, 'Junior'),
('Frank Miller', 40, 120000.00, 'Senior'),
('Grace Lee', 31, 80000.00, 'Mid-Level'),
('Henry Garcia', 27, 65000.00, 'Junior'),
('Ivy Martinez', 38, 110000.00, 'Senior'),
('Jack Anderson', 25, 58000.00, 'Junior'),
('Kelly Taylor', 33, 88000.00, 'Mid-Level'),
('Larry Clark', 45, 135000.00, 'Senior'),
('Monica Rodriguez', 30, 77000.00, 'Mid-Level'),
('Nathan Lewis', 26, 62000.00, 'Junior'),
('Olivia Walker', 36, 92000.00, 'Senior'),
('Paul Hall', 28, 72000.00, 'Mid-Level'),
('Quinn Young', 41, 125000.00, 'Senior'),
('Rachel King', 29, 75000.00, 'Mid-Level'),
('Steve Wright', 34, 90000.00, 'Senior'),
('Sarah Johnson', 27, 68000.00, 'Mid-Level'),
('Michael Brown', 33, 82000.00, 'Mid-Level'),
('Emily Davis', 24, 52000.00, 'Junior'),
('David Wilson', 39, 105000.00, 'Senior'),
('Jennifer Miller', 31, 78000.00, 'Mid-Level'),
('James Garcia', 26, 59000.00, 'Junior'),
('Mary Martinez', 37, 98000.00, 'Senior'),
('Robert Anderson', 25, 56000.00, 'Junior'),
('Linda Taylor', 32, 84000.00, 'Mid-Level'),
('William Clark', 43, 128000.00, 'Senior'),
('Barbara Rodriguez', 29, 73000.00, 'Mid-Level'),
('Richard Lewis', 28, 67000.00, 'Mid-Level'),
('Susan Walker', 35, 91000.00, 'Senior'),
('Joseph Hall', 30, 76000.00, 'Mid-Level'),
('Jessica Young', 40, 115000.00, 'Senior'),
('Christopher King', 27, 64000.00, 'Junior'),
('Karen Wright', 36, 94000.00, 'Senior'),
('Daniel Lee', 25, 54000.00, 'Junior'),
('Nancy Adams', 38, 102000.00, 'Senior'),
('Matthew Baker', 31, 79000.00, 'Mid-Level');

-- 4. Update salary_category berdasarkan salary untuk konsistensi
UPDATE employees SET salary_category = 
    CASE 
        WHEN salary < 65000 THEN 'Junior'
        WHEN salary BETWEEN 65000 AND 89999 THEN 'Mid-Level'
        WHEN salary >= 90000 THEN 'Senior'
        ELSE 'Unknown'
    END;

-- 5. Create trigger function to auto-update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
   NEW.updated_at = CURRENT_TIMESTAMP;
   RETURN NEW;
END;
$$ language 'plpgsql';

-- 6. Create trigger to automatically update timestamp
DROP TRIGGER IF EXISTS update_employees_updated_at ON employees;
CREATE TRIGGER update_employees_updated_at 
    BEFORE UPDATE ON employees 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- 7. Create stats table for tracking analytics
CREATE TABLE IF NOT EXISTS employee_stats (
    id SERIAL PRIMARY KEY,
    report_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    total_employees INTEGER,
    avg_age DECIMAL(5,2),
    avg_salary DECIMAL(10,2),
    min_salary DECIMAL(10,2),
    max_salary DECIMAL(10,2),
    junior_count INTEGER,
    midlevel_count INTEGER,
    senior_count INTEGER
);

-- 8. Insert initial stats
INSERT INTO employee_stats 
(total_employees, avg_age, avg_salary, min_salary, max_salary, 
 junior_count, midlevel_count, senior_count)
SELECT 
    COUNT(*) as total,
    ROUND(AVG(age), 2) as avg_age,
    ROUND(AVG(salary), 2) as avg_salary,
    MIN(salary) as min_sal,
    MAX(salary) as max_sal,
    SUM(CASE WHEN salary_category = 'Junior' THEN 1 ELSE 0 END) as junior,
    SUM(CASE WHEN salary_category = 'Mid-Level' THEN 1 ELSE 0 END) as midlevel,
    SUM(CASE WHEN salary_category = 'Senior' THEN 1 ELSE 0 END) as senior
FROM employees;

-- 9. Verification queries
\echo '=== DATABASE SETUP COMPLETE ==='
\echo '=== Verification Results ==='

-- Show total records
SELECT COUNT(*) as "Total Employees" FROM employees;

-- Show category distribution
SELECT 
    salary_category as "Category",
    COUNT(*) as "Count",
    ROUND(AVG(age), 1) as "Avg Age",
    ROUND(AVG(salary), 0) as "Avg Salary",
    MIN(salary) as "Min Salary",
    MAX(salary) as "Max Salary"
FROM employees 
GROUP BY salary_category 
ORDER BY AVG(salary);

-- Show sample data
SELECT id, name, age, salary, salary_category 
FROM employees 
ORDER BY id 
LIMIT 5;

\echo '=== Setup complete! You can now run your Airflow DAG ===' 