package com.bni.itops;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

// @xxx -> anotasi
//Spring Boot Annotations are a form of metadata that provides data about a spring application

@SpringBootTest
class SpringDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
