/*
 * Written by : Bostang Palaguna
 * Date : 2025-05-28
 * File : Product.java
 * Deskripsi : mendefinisikan kelas Produk (DTO)
 */

// src/main/java/com/example/api_caching/model/Product.java
package com.example.api_caching.model;      // package declaration

// library import
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;
import lombok.NoArgsConstructor;

/************************** Layer Model/DTO **************************/
@Data               // generasi otomatis getter & setter
@Entity             // Menandakan kelas ini sebagai entitas database : dipetakan ke tabel 'product' by default
@NoArgsConstructor  // buat constructor tanpa parameter (default constructor)
public class Product {
    @Id     // Menentukan primary key tabel
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Strategi auto-increment database
    // deklarasi field entitas
    private Long id;
    private String name;
    private double price;
    private String category;

    // Tambahkan constructor dengan parameter
    // dapat digantikan dengan anotasi @AllArgsConstructor
    public Product(Long id, String name, double price, String category) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.category = category;
    }
}
/************************** End of Layer Model/DTO *******************/
