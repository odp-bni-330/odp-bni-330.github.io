/*
 * Written by : Bostang Palaguna
 * Date : 2025-05-28
 * File : ConnectionOracleDbApplication.java
 * Deskripsi : Main class dari aplikasi
 */

package com.example.connect_oracle_db; // package declaration

// library import
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
// anotasi yang terdiri:
	// @Configuration → class sumber definisi bean Spring
	// @EnableAutoConfiguration → tambahkan bean bdskan aturan classpath
	// @ComponentScan → pindai komponen, config, services dalam paket

public class ConnectOracleDbApplication { // // deklarasi kelas utama aplikasi

	// metode utama yang akan dijalankan pertama kali ketika aplikasi dimulai
	public static void main(String[] args) {
		// Meluncurkan app
		SpringApplication.run(ConnectOracleDbApplication.class, args);
	}

}
