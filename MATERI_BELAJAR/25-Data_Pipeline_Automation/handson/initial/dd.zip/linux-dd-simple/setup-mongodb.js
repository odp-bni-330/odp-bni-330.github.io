// MongoDB Atlas Setup Script
// Run this script using: node setup-mongodb.js

const { MongoClient } = require('mongodb');

// MongoDB Atlas connection string
const MONGODB_URL = 'mongodb+srv://fauziweb19:MongoGoGo@cluster0.eorwj9n.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0';

async function setupMongoDB() {
    let client;
    
    try {
        console.log('🔄 Connecting to MongoDB Atlas...');
        client = new MongoClient(MONGODB_URL);
        await client.connect();
        
        const db = client.db('demo_db');
        console.log('✅ Connected to MongoDB Atlas');
        
        // Setup customers collection
        console.log('🔄 Setting up customers collection...');
        const customers = db.collection('customers');
        
        // Clear existing data (optional)
        await customers.deleteMany({});
        
        // Insert customer data
        await customers.insertMany([
            {
                customer_id: "CUST001",
                name: "Budi Santoso",
                email: "budi.santoso@email.com",
                age: 28,
                gender: "Male",
                location: {
                    city: "Jakarta",
                    province: "DKI Jakarta",
                    country: "Indonesia",
                    coordinates: [-6.2088, 106.8456]
                },
                preferences: {
                    categories: ["Electronics", "Gaming"],
                    brands: ["ASUS", "Logitech", "Samsung"],
                    price_range: "Premium"
                },
                loyalty_program: {
                    tier: "Gold",
                    points: 1500,
                    join_date: new Date("2023-01-15")
                },
                created_at: new Date("2023-01-15"),
                last_activity: new Date("2024-06-25")
            },
            {
                customer_id: "CUST002",
                name: "Sari Dewi",
                email: "sari.dewi@email.com",
                age: 32,
                gender: "Female",
                location: {
                    city: "Surabaya",
                    province: "Jawa Timur",
                    country: "Indonesia",
                    coordinates: [-7.2575, 112.7521]
                },
                preferences: {
                    categories: ["Electronics", "Gadgets"],
                    brands: ["Apple", "Samsung", "Canon"],
                    price_range: "Premium"
                },
                loyalty_program: {
                    tier: "Platinum",
                    points: 2800,
                    join_date: new Date("2022-08-10")
                },
                created_at: new Date("2022-08-10"),
                last_activity: new Date("2024-06-24")
            },
            {
                customer_id: "CUST003",
                name: "Ahmad Rizki",
                email: "ahmad.rizki@email.com",
                age: 25,
                gender: "Male",
                location: {
                    city: "Bandung",
                    province: "Jawa Barat",
                    country: "Indonesia",
                    coordinates: [-6.9175, 107.6191]
                },
                preferences: {
                    categories: ["Electronics", "Audio"],
                    brands: ["Logitech", "Sony", "JBL"],
                    price_range: "Mid-range"
                },
                loyalty_program: {
                    tier: "Silver",
                    points: 850,
                    join_date: new Date("2023-05-20")
                },
                created_at: new Date("2023-05-20"),
                last_activity: new Date("2024-06-20")
            },
            {
                customer_id: "CUST004",
                name: "Maya Sari",
                email: "maya.sari@email.com",
                age: 29,
                gender: "Female",
                location: {
                    city: "Medan",
                    province: "Sumatera Utara",
                    country: "Indonesia",
                    coordinates: [3.5952, 98.6722]
                },
                preferences: {
                    categories: ["Electronics", "Photography"],
                    brands: ["Canon", "Apple", "Samsung"],
                    price_range: "Premium"
                },
                loyalty_program: {
                    tier: "Gold",
                    points: 1920,
                    join_date: new Date("2022-12-05")
                },
                created_at: new Date("2022-12-05"),
                last_activity: new Date("2024-06-22")
            },
            {
                customer_id: "CUST005",
                name: "Indra Pratama",
                email: "indra.pratama@email.com",
                age: 35,
                gender: "Male",
                location: {
                    city: "Yogyakarta",
                    province: "DI Yogyakarta",
                    country: "Indonesia",
                    coordinates: [-7.7956, 110.3695]
                },
                preferences: {
                    categories: ["Electronics", "Gaming", "Audio"],
                    brands: ["ASUS", "Razer", "Logitech"],
                    price_range: "Premium"
                },
                loyalty_program: {
                    tier: "Platinum",
                    points: 3200,
                    join_date: new Date("2021-11-15")
                },
                created_at: new Date("2021-11-15"),
                last_activity: new Date("2024-06-26")
            }
        ]);
        
        console.log('✅ Customers collection setup complete');
        
        // Setup interactions collection
        console.log('🔄 Setting up interactions collection...');
        const interactions = db.collection('interactions');
        
        // Clear existing data (optional)
        await interactions.deleteMany({});
        
        // Insert interaction data
        await interactions.insertMany([
            {
                customer_id: "CUST001",
                type: "website_visit",
                action: "product_view",
                details: {
                    product_name: "Laptop Gaming ASUS ROG",
                    category: "Electronics",
                    duration_seconds: 180,
                    page_views: 3
                },
                timestamp: new Date("2024-06-25T10:30:00Z"),
                device: "desktop",
                location: "Jakarta"
            },
            {
                customer_id: "CUST001",
                type: "purchase",
                action: "completed",
                details: {
                    order_id: "ORD001",
                    product_name: "Mouse Gaming Logitech",
                    amount: 500000,
                    payment_method: "credit_card"
                },
                timestamp: new Date("2024-06-25T14:45:00Z"),
                device: "mobile",
                location: "Jakarta"
            },
            {
                customer_id: "CUST002",
                type: "email_campaign",
                action: "opened",
                details: {
                    campaign_name: "Summer Sale 2024",
                    subject: "Diskon Hingga 50% Elektronik",
                    content_type: "promotional"
                },
                timestamp: new Date("2024-06-24T09:15:00Z"),
                device: "mobile",
                location: "Surabaya"
            },
            {
                customer_id: "CUST002",
                type: "support_ticket",
                action: "created",
                details: {
                    ticket_id: "TKT001",
                    category: "product_inquiry",
                    priority: "medium",
                    subject: "Pertanyaan tentang Tablet iPad"
                },
                timestamp: new Date("2024-06-24T11:20:00Z"),
                device: "desktop",
                location: "Surabaya"
            },
            {
                customer_id: "CUST003",
                type: "social_media",
                action: "shared",
                details: {
                    platform: "Instagram",
                    content_type: "product_review",
                    product_name: "Headset Gaming",
                    engagement: "positive"
                },
                timestamp: new Date("2024-06-20T16:30:00Z"),
                device: "mobile",
                location: "Bandung"
            },
            {
                customer_id: "CUST004",
                type: "website_visit",
                action: "search",
                details: {
                    search_term: "camera DSLR",
                    results_count: 15,
                    clicked_results: 3
                },
                timestamp: new Date("2024-06-22T13:45:00Z"),
                device: "desktop",
                location: "Medan"
            },
            {
                customer_id: "CUST005",
                type: "newsletter",
                action: "subscribed",
                details: {
                    newsletter_type: "weekly_deals",
                    preferences: ["Electronics", "Gaming"]
                },
                timestamp: new Date("2024-06-26T08:00:00Z"),
                device: "desktop",
                location: "Yogyakarta"
            }
        ]);
        
        console.log('✅ Interactions collection setup complete');
        
        // Create indexes for better performance
        console.log('🔄 Creating indexes...');
        await customers.createIndex({ customer_id: 1 });
        await customers.createIndex({ "location.city": 1 });
        await interactions.createIndex({ customer_id: 1 });
        await interactions.createIndex({ type: 1 });
        await interactions.createIndex({ timestamp: -1 });
        
        console.log('✅ Indexes created');
        
        // Display summary
        const customerCount = await customers.countDocuments();
        const interactionCount = await interactions.countDocuments();
        
        console.log('\n📊 Database Setup Summary:');
        console.log(`✅ Customers: ${customerCount} documents`);
        console.log(`✅ Interactions: ${interactionCount} documents`);
        console.log('🎉 MongoDB Atlas setup completed successfully!');
        
    } catch (error) {
        console.error('❌ Error setting up MongoDB:', error);
        process.exit(1);
    } finally {
        if (client) {
            await client.close();
            console.log('🔌 Connection closed');
        }
    }
}

// Run the setup
if (require.main === module) {
    setupMongoDB();
}

module.exports = { setupMongoDB }; 