# Panduan Penggunaan Docker untuk Hands-on

## Prasyarat
- Docker dan Docker Compose terinstal di komputer Anda
- Minimal 4GB RAM tersedia untuk menjalankan container

## Menjalankan Database dengan Docker Compose

1. Buka terminal dan arahkan ke direktori proyek:
   ```bash
   cd /path/to/multisource
   ```

2. Jalankan Docker Compose:
   ```bash
   docker-compose up -d
   ```

3. Tunggu hingga semua container berjalan (biasanya membutuhkan waktu 1-2 menit):
   ```bash
   docker-compose ps
   ```

## Koneksi ke Database

### PostgreSQL Database
- Host: localhost
- Port: 5432
- Database: ecommerce
- Username: ecommerce
- Password: ecommerce

Untuk terhubung menggunakan pgAdmin:
1. Buka pgAdmin
2. Buat koneksi baru dengan informasi di atas
3. Tes koneksi dan klik "Connect"

Untuk terhubung menggunakan command line:
```bash
psql -h localhost -p 5432 -U ecommerce -d ecommerce
```

### MongoDB
- Host: localhost
- Port: 27017
- Database: ecommerce
- Username: ecommerce_user
- Password: ecommerce_pass

Untuk terhubung menggunakan MongoDB Compass:
1. Buka MongoDB Compass
2. Masukkan connection string: `mongodb://ecommerce_user:ecommerce_pass@localhost:27017/ecommerce`
3. Klik "Connect"

### MongoDB Express (Web UI)
- URL: http://localhost:8081
- Username: admin
- Password: admin

## Mematikan dan Membersihkan

1. Untuk menghentikan container tanpa menghapus data:
   ```bash
   docker-compose stop
   ```

2. Untuk menghentikan dan menghapus container (data tetap tersimpan dalam volume):
   ```bash
   docker-compose down
   ```

3. Untuk menghentikan dan menghapus container beserta volume data:
   ```bash
   docker-compose down -v
   ```

## Troubleshooting

### Masalah Koneksi PostgreSQL
Jika Anda mengalami masalah koneksi ke PostgreSQL, pastikan container sudah sepenuhnya siap:
```bash
docker logs postgresql
```
Tunggu hingga Anda melihat pesan "database system is ready to accept connections".

### Masalah Koneksi MongoDB
Jika Anda mengalami masalah koneksi ke MongoDB, periksa log:
```bash
docker logs mongodb
```

### Masalah Port yang Sudah Digunakan
Jika port 5432 atau 27017 sudah digunakan, ubah port mapping di file docker-compose.yml.