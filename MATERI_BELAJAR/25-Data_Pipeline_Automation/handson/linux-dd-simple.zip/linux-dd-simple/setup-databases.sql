-- Setup script for Neon PostgreSQL Database
-- Run this script in your Neon database console or using psql

-- Create demo database tables
CREATE TABLE IF NOT EXISTS products (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    category VARCHAR(50),
    price DECIMAL(12,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS sales (
    id SERIAL PRIMARY KEY,
    product_id INTEGER REFERENCES products(id),
    quantity INTEGER NOT NULL,
    unit_price DECIMAL(12,2),
    total_amount DECIMAL(15,2),
    sale_date DATE DEFAULT CURRENT_DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert sample products
INSERT INTO products (name, category, price) VALUES
('Laptop Gaming ASUS ROG', 'Electronics', 15000000.00),
('Mouse Gaming Logitech', 'Electronics', 500000.00),
('Keyboard Mechanical', 'Electronics', 1200000.00),
('Monitor 24 inch', 'Electronics', 3000000.00),
('Headset Gaming', 'Electronics', 800000.00),
('Smartphone Samsung', 'Electronics', 8000000.00),
('Tablet iPad', 'Electronics', 12000000.00),
('Smartwatch Apple', 'Electronics', 6000000.00),
('Camera DSLR Canon', 'Electronics', 10000000.00),
('Speaker Bluetooth', 'Electronics', 400000.00)
ON CONFLICT DO NOTHING;

-- Insert sample sales data for the last 6 months
INSERT INTO sales (product_id, quantity, unit_price, total_amount, sale_date) VALUES
-- January 2024
(1, 5, 15000000.00, 75000000.00, '2024-01-15'),
(2, 20, 500000.00, 10000000.00, '2024-01-16'),
(3, 15, 1200000.00, 18000000.00, '2024-01-20'),
(4, 8, 3000000.00, 24000000.00, '2024-01-25'),
(5, 12, 800000.00, 9600000.00, '2024-01-28'),

-- February 2024
(6, 10, 8000000.00, 80000000.00, '2024-02-05'),
(7, 6, 12000000.00, 72000000.00, '2024-02-08'),
(8, 8, 6000000.00, 48000000.00, '2024-02-12'),
(9, 3, 10000000.00, 30000000.00, '2024-02-18'),
(10, 25, 400000.00, 10000000.00, '2024-02-22'),

-- March 2024
(1, 8, 15000000.00, 120000000.00, '2024-03-05'),
(2, 30, 500000.00, 15000000.00, '2024-03-10'),
(3, 20, 1200000.00, 24000000.00, '2024-03-15'),
(4, 12, 3000000.00, 36000000.00, '2024-03-20'),
(5, 18, 800000.00, 14400000.00, '2024-03-25'),

-- April 2024
(6, 15, 8000000.00, 120000000.00, '2024-04-02'),
(7, 9, 12000000.00, 108000000.00, '2024-04-08'),
(8, 12, 6000000.00, 72000000.00, '2024-04-15'),
(9, 5, 10000000.00, 50000000.00, '2024-04-20'),
(10, 35, 400000.00, 14000000.00, '2024-04-25'),

-- May 2024
(1, 12, 15000000.00, 180000000.00, '2024-05-03'),
(2, 45, 500000.00, 22500000.00, '2024-05-08'),
(3, 28, 1200000.00, 33600000.00, '2024-05-12'),
(4, 18, 3000000.00, 54000000.00, '2024-05-18'),
(5, 22, 800000.00, 17600000.00, '2024-05-22'),

-- June 2024
(6, 20, 8000000.00, 160000000.00, '2024-06-05'),
(7, 12, 12000000.00, 144000000.00, '2024-06-10'),
(8, 15, 6000000.00, 90000000.00, '2024-06-15'),
(9, 7, 10000000.00, 70000000.00, '2024-06-20'),
(10, 40, 400000.00, 16000000.00, '2024-06-25')
ON CONFLICT DO NOTHING;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_sales_product_id ON sales(product_id);
CREATE INDEX IF NOT EXISTS idx_sales_date ON sales(sale_date);
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category);

-- Display summary
SELECT 'Database initialized successfully!' as status;
SELECT COUNT(*) as total_products FROM products;
SELECT COUNT(*) as total_sales FROM sales; 