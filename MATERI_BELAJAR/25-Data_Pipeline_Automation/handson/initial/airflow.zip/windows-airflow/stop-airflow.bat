@echo off
echo ========================================
echo   Stopping Apache Airflow on Windows
echo ========================================
echo.

echo [INFO] Stopping Airflow services...
docker-compose down

echo.
echo [INFO] Checking if containers are stopped...
docker-compose ps

echo.
echo ========================================
echo     Airflow services stopped!
echo ========================================
echo.
echo All containers have been stopped.
echo Data and volumes are preserved.
echo.
echo To restart: run start-airflow.bat
echo To completely reset: run reset-airflow.bat
echo.
pause 