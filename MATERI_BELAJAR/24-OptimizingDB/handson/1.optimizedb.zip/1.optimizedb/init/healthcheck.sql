-- Healthcheck script
SELECT 1 FROM DUAL;
EXIT;