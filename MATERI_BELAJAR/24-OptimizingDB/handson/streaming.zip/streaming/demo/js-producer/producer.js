const { Kafka } = require('kafkajs');
const { faker } = require('@faker-js/faker');

// Kafka client configuration
const kafka = new Kafka({
  clientId: 'demo-producer',
  // brokers: [process.env.KAFKA_BROKERS || 'localhost:9092']
  brokers: [process.env.KAFKA_BROKERS || 'localhost:9093']
});

const producer = kafka.producer();
const TOPIC = 'user-events';

// Product categories for realistic data
const categories = [
  'Electronics', 'Clothing', 'Books', 'Home & Garden', 
  'Sports', 'Toys', 'Food & Beverages', 'Health & Beauty'
];

const locations = [
  'Jakarta', 'Surabaya', 'Bandung', 'Medan', 'Semarang',
  'Makassar', 'Palembang', 'Tangerang', 'Depok', 'Bekasi'
];

const customerSegments = ['Premium', 'Standard', 'Basic'];
const paymentMethods = ['Credit Card', 'Debit Card', 'E-Wallet', 'Bank Transfer', 'Cash'];

// Generate realistic user event data
const generateUserEvent = () => {
  const eventTypes = ['VIEW', 'ADD_TO_CART', 'PURCHASE', 'SEARCH', 'LOGIN', 'LOGOUT'];
  const eventType = faker.helpers.arrayElement(eventTypes);
  const category = faker.helpers.arrayElement(categories);
  
  const baseEvent = {
    event_id: faker.string.uuid(),
    user_id: faker.string.uuid(),
    session_id: faker.string.uuid(),
    event_type: eventType,
    timestamp: new Date().toISOString(),
    user_agent: faker.internet.userAgent(),
    ip_address: faker.internet.ip(),
    location: faker.helpers.arrayElement(locations),
    customer_segment: faker.helpers.arrayElement(customerSegments)
  };

  // Add event-specific data
  if (eventType === 'PURCHASE' || eventType === 'VIEW' || eventType === 'ADD_TO_CART') {
    const quantity = faker.number.int({ min: 1, max: 5 });
    const pricePerUnit = parseFloat(faker.commerce.price({ min: 10, max: 2000 }));
    
    baseEvent.product = {
      product_id: faker.number.int({ min: 1, max: 1000 }),
      product_name: faker.commerce.productName(),
      category: category,
      price_per_unit: pricePerUnit,
      quantity: quantity,
      total_amount: pricePerUnit * quantity
    };

    if (eventType === 'PURCHASE') {
      baseEvent.transaction = {
        transaction_id: faker.string.uuid(),
        payment_method: faker.helpers.arrayElement(paymentMethods),
        discount_applied: faker.datatype.boolean(),
        discount_amount: faker.number.float({ min: 0, max: 100, fractionDigits: 2 })
      };
    }
  }

  if (eventType === 'SEARCH') {
    baseEvent.search = {
      query: faker.commerce.productName(),
      category_filter: faker.helpers.arrayElement(categories),
      results_count: faker.number.int({ min: 0, max: 100 })
    };
  }

  return baseEvent;
};

// Send message to Kafka
const sendMessage = async () => {
  const event = generateUserEvent();
  
  try {
    await producer.send({
      topic: TOPIC,
      messages: [
        { 
          key: event.user_id, 
          value: JSON.stringify(event),
          timestamp: Date.now().toString()
        },
      ],
    });
    
    console.log(`[${new Date().toISOString()}] Event sent: ${event.event_type} - ${event.user_id.substring(0, 8)}...`);
    
    if (event.product) {
      console.log(`  Product: ${event.product.product_name} (${event.product.category}) - $${event.product.total_amount}`);
    }
    
  } catch (error) {
    console.error('Error sending message:', error);
  }
};

// Main function
const run = async () => {
  try {
    await producer.connect();
    console.log('🚀 Producer connected to Kafka');
    console.log(`📡 Sending events to topic: ${TOPIC}`);
    
    // Send messages at different intervals to simulate realistic traffic
    const intervals = [500, 1000, 1500, 2000]; // milliseconds
    
    const sendRandomInterval = () => {
      sendMessage();
      const nextInterval = faker.helpers.arrayElement(intervals);
      setTimeout(sendRandomInterval, nextInterval);
    };
    
    // Start sending messages
    sendRandomInterval();
    
  } catch (error) {
    console.error('Failed to start producer:', error);
  }
};

// Graceful shutdown
const shutdown = async () => {
  console.log('\n🛑 Shutting down producer...');
  try {
    await producer.disconnect();
    console.log('✅ Producer disconnected successfully');
    process.exit(0);
  } catch (error) {
    console.error('Error during shutdown:', error);
    process.exit(1);
  }
};

process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

run().catch(console.error); 