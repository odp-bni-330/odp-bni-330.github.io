# Hands-on: Query Elasticsearch with Kibana (Linux)

Panduan lengkap untuk setup Elasticsearch dan Kibana menggunakan Docker di Linux, serta melakukan query dasar.

## Prerequisites
- Docker dan Docker Compose terinstall
- OS Linux (Ubuntu/Debian/CentOS/RHEL/Arch)
- Minimal 4GB RAM
- curl dan jq (opsional untuk formatting JSON)
- Pemahaman dasar REST API

## System Optimization untuk Linux

### 1. Konfigurasi Memory dan Swap
```bash
# Check current vm.max_map_count
sysctl vm.max_map_count

# Set vm.max_map_count untuk Elasticsearch (temporary)
sudo sysctl -w vm.max_map_count=262144

# Set permanent (tambahkan ke /etc/sysctl.conf)
echo 'vm.max_map_count=262144' | sudo tee -a /etc/sysctl.conf

# Disable swap untuk performa yang lebih baik
sudo swapoff -a

# Edit /etc/fstab untuk disable swap permanent (comment swap line)
sudo sed -i '/ swap / s/^\(.*\)$/#\1/g' /etc/fstab
```

### 2. Install Dependencies
```bash
# Ubuntu/Debian
sudo apt update
sudo apt install docker.io docker-compose curl jq

# CentOS/RHEL
sudo yum install docker docker-compose curl jq
# atau untuk CentOS 8+
sudo dnf install docker docker-compose curl jq

# Arch Linux
sudo pacman -S docker docker-compose curl jq

# Start Docker service
sudo systemctl start docker
sudo systemctl enable docker

# Add user to docker group
sudo usermod -aG docker $USER
newgrp docker
```

## Setup

1. Clone dan masuk ke directory:
```bash
cd linux-elasticsearch
```

2. Set proper permissions untuk script:
```bash
chmod +x sample-data-script.sh
```

3. Start Elasticsearch dan Kibana containers:
```bash
docker-compose up -d
```

4. Monitor logs:
```bash
# Monitor semua logs
docker-compose logs -f

# Monitor hanya Elasticsearch
docker-compose logs -f elasticsearch

# Monitor hanya Kibana
docker-compose logs -f kibana
```

5. Verify Elasticsearch running:
```bash
curl http://localhost:9200
curl http://localhost:9200/_cluster/health?pretty
```

6. Access Kibana di http://localhost:5601

## Exercise 1: Index Sample Data

### Option A: Using Enhanced Script
Script ini sudah dioptimalkan untuk Linux dengan error handling dan logging yang lebih baik:
```bash
./sample-data-script.sh
```

### Option B: Manual Commands
```bash
# Create index dengan mapping yang optimal
curl -X PUT "localhost:9200/products" -H "Content-Type: application/json" -d'
{
  "settings": {
    "number_of_shards": 1,
    "number_of_replicas": 0,
    "refresh_interval": "1s"
  },
  "mappings": {
    "properties": {
      "name": {"type": "text", "analyzer": "standard"},
      "price": {"type": "float"},
      "in_stock": {"type": "integer"},
      "category": {"type": "keyword"},
      "tags": {"type": "keyword"},
      "created_at": {"type": "date"}
    }
  }
}'

# Add documents dengan timestamp
curl -X POST "localhost:9200/products/_doc" -H "Content-Type: application/json" -d'
{
  "name": "Laptop",
  "price": 999.99,
  "in_stock": 10,
  "category": "electronics",
  "tags": ["computer", "work", "portable"],
  "created_at": "'$(date -u +"%Y-%m-%dT%H:%M:%S.%3NZ")'"
}'

# Check index stats
curl "localhost:9200/products/_stats?pretty"
```

## Exercise 2: Advanced Linux-specific Queries

### Performance Monitoring
```bash
# Check cluster health
curl "localhost:9200/_cluster/health?pretty"

# Check node stats
curl "localhost:9200/_nodes/stats?pretty"

# Check index statistics
curl "localhost:9200/_cat/indices?v&s=store.size:desc"

# Check memory usage
curl "localhost:9200/_cat/nodes?v&h=name,heap.percent,ram.percent,cpu,load_1m,load_5m,load_15m"
```

### Bulk Operations untuk Performa Tinggi
```bash
# Bulk insert menggunakan file
cat > bulk_data.json << 'EOF'
{"index": {"_index": "products"}}
{"name": "Gaming Chair", "price": 299.99, "in_stock": 5, "category": "furniture", "tags": ["gaming", "comfort"], "created_at": "2024-01-01T10:00:00Z"}
{"index": {"_index": "products"}}
{"name": "Standing Desk", "price": 599.99, "in_stock": 3, "category": "furniture", "tags": ["office", "health"], "created_at": "2024-01-01T11:00:00Z"}
{"index": {"_index": "products"}}
{"name": "Webcam", "price": 89.99, "in_stock": 15, "category": "electronics", "tags": ["streaming", "video"], "created_at": "2024-01-01T12:00:00Z"}
EOF

curl -X POST "localhost:9200/_bulk" -H "Content-Type: application/json" --data-binary @bulk_data.json
```

### Advanced Search dengan jq formatting
```bash
# Search dengan pretty formatting
search_products() {
    curl -s -X GET "localhost:9200/products/_search" -H "Content-Type: application/json" -d"$1" | jq '
        {
            total: .hits.total.value,
            products: [.hits.hits[] | {
                id: ._id,
                score: ._score,
                name: ._source.name,
                price: ._source.price,
                category: ._source.category,
                in_stock: ._source.in_stock
            }]
        }'
}

# Usage examples
search_products '{
  "query": {"match_all": {}},
  "sort": [{"price": {"order": "desc"}}]
}'

search_products '{
  "query": {
    "bool": {
      "must": [
        {"match": {"category": "electronics"}},
        {"range": {"price": {"gte": 100, "lte": 800}}}
      ]
    }
  }
}'
```

## Exercise 3: Performance Tuning

### 1. Index Templates untuk Auto-optimization
```bash
curl -X PUT "localhost:9200/_index_template/products_template" -H "Content-Type: application/json" -d'
{
  "index_patterns": ["products*"],
  "template": {
    "settings": {
      "number_of_shards": 1,
      "number_of_replicas": 0,
      "refresh_interval": "30s",
      "index.max_result_window": 50000
    },
    "mappings": {
      "properties": {
        "name": {"type": "text", "analyzer": "standard"},
        "price": {"type": "float"},
        "category": {"type": "keyword"},
        "created_at": {"type": "date"}
      }
    }
  }
}'
```

### 2. Custom Analyzers
```bash
curl -X PUT "localhost:9200/products_advanced" -H "Content-Type: application/json" -d'
{
  "settings": {
    "analysis": {
      "analyzer": {
        "product_analyzer": {
          "type": "custom",
          "tokenizer": "standard",
          "filter": ["lowercase", "stop", "stemmer"]
        }
      },
      "filter": {
        "stemmer": {
          "type": "stemmer",
          "language": "english"
        }
      }
    }
  },
  "mappings": {
    "properties": {
      "name": {
        "type": "text",
        "analyzer": "product_analyzer"
      },
      "description": {
        "type": "text",
        "analyzer": "product_analyzer"
      }
    }
  }
}'
```

## Exercise 4: Monitoring dan Logging

### 1. Setup Monitoring Script
```bash
cat > monitor_elasticsearch.sh << 'EOF'
#!/bin/bash

while true; do
    echo "=== $(date) ==="
    echo "Cluster Health:"
    curl -s "localhost:9200/_cluster/health" | jq '{status, active_shards, number_of_nodes}'
    
    echo "Memory Usage:"
    curl -s "localhost:9200/_cat/nodes?h=heap.percent,ram.percent&format=json" | jq '.[0]'
    
    echo "Index Size:"
    curl -s "localhost:9200/_cat/indices/products?h=store.size&format=json" | jq '.[0]'
    
    echo "========================"
    sleep 30
done
EOF

chmod +x monitor_elasticsearch.sh
./monitor_elasticsearch.sh
```

### 2. Log Analysis
```bash
# Check Docker logs dengan filter
docker logs elasticsearch 2>&1 | grep -E "(ERROR|WARN)"

# Monitor real-time logs
docker logs -f elasticsearch | grep -E --color=always "(ERROR|WARN|started)"

# Export logs untuk analysis
docker logs elasticsearch > elasticsearch.log 2>&1
```

## Exercise 5: Kibana Advanced Setup

### 1. Import Dashboard Configuration
```bash
# Create index pattern via API
curl -X POST "localhost:5601/api/saved_objects/index-pattern/products-pattern" \
  -H "Content-Type: application/json" \
  -H "kbn-xsrf: true" \
  -d'{
    "attributes": {
      "title": "products*",
      "timeFieldName": "created_at"
    }
  }'
```

### 2. Kibana Dev Tools Queries
Buka Kibana Dev Tools dan jalankan:

```
# Complex aggregation
GET products/_search
{
  "size": 0,
  "aggs": {
    "category_stats": {
      "terms": {"field": "category"},
      "aggs": {
        "avg_price": {"avg": {"field": "price"}},
        "max_price": {"max": {"field": "price"}},
        "total_stock": {"sum": {"field": "in_stock"}},
        "price_ranges": {
          "range": {
            "field": "price",
            "ranges": [
              {"to": 100},
              {"from": 100, "to": 500},
              {"from": 500}
            ]
          }
        }
      }
    }
  }
}

# Time-based aggregation
GET products/_search
{
  "size": 0,
  "aggs": {
    "sales_over_time": {
      "date_histogram": {
        "field": "created_at",
        "calendar_interval": "1d"
      },
      "aggs": {
        "total_value": {
          "sum": {
            "script": {
              "source": "doc['price'].value * doc['in_stock'].value"
            }
          }
        }
      }
    }
  }
}
```

## Troubleshooting Linux-specific

### Memory Issues
```bash
# Check memory limit
cat /sys/fs/cgroup/memory/memory.limit_in_bytes

# Check swap usage
free -h
swapon --show

# Increase virtual memory
sudo sysctl -w vm.max_map_count=262144
```

### Permission Issues
```bash
# Fix Docker permissions
sudo chown -R $USER:$USER /var/lib/docker
sudo chmod -R 755 /var/lib/docker

# Fix data directory permissions
sudo chown -R 1000:1000 ./data
```

### Network Issues
```bash
# Check ports
sudo netstat -tlnp | grep -E ":(9200|5601)"
sudo ss -tlnp | grep -E ":(9200|5601)"

# Check firewall
sudo ufw status
sudo iptables -L

# Test connectivity
telnet localhost 9200
nc -zv localhost 9200
```

### Performance Issues
```bash
# Check disk I/O
iostat -x 1

# Check CPU usage
htop
sar -u 1

# Check Docker stats
docker stats elasticsearch kibana
```

## Backup dan Recovery

### 1. Create Snapshot Repository
```bash
curl -X PUT "localhost:9200/_snapshot/backup_repo" -H "Content-Type: application/json" -d'
{
  "type": "fs",
  "settings": {
    "location": "/usr/share/elasticsearch/backup"
  }
}'
```

### 2. Create Backup
```bash
curl -X PUT "localhost:9200/_snapshot/backup_repo/snapshot_1" -H "Content-Type: application/json" -d'
{
  "indices": "products",
  "ignore_unavailable": true,
  "include_global_state": false
}'
```

## Cleanup

```bash
# Stop containers
docker-compose down

# Remove volumes
docker-compose down -v

# Remove all related images
docker rmi $(docker images | grep elastic | awk '{print $3}')

# Reset vm.max_map_count (if needed)
sudo sysctl -w vm.max_map_count=65530
```

## Production Tips

1. **Resource Allocation**: Minimal 4GB RAM, rekomendasikan 8GB+
2. **Storage**: Gunakan SSD untuk performa optimal
3. **Monitoring**: Setup Metricbeat dan Filebeat untuk monitoring production
4. **Security**: Enable X-Pack security untuk production
5. **Clustering**: Setup multi-node cluster untuk high availability
6. **Backup**: Automated snapshot scheduling
7. **Log Rotation**: Configure logrotate untuk Docker logs

## Useful Commands Reference

```bash
# Quick health check
curl -s localhost:9200/_cat/health?v

# List all indices
curl -s localhost:9200/_cat/indices?v

# Check cluster settings
curl -s localhost:9200/_cluster/settings?pretty

# Force merge untuk optimasi
curl -X POST "localhost:9200/products/_forcemerge?max_num_segments=1"

# Clear cache
curl -X POST "localhost:9200/products/_cache/clear"

# Refresh index
curl -X POST "localhost:9200/products/_refresh"
``` 