from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator
import pandas as pd
import os
import platform
import psutil
import logging

# Default arguments for the DAG
default_args = {
    'owner': 'ubuntu-user',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 2,  # Increased for Linux stability
    'retry_delay': timedelta(minutes=3),
    'execution_timeout': timedelta(hours=1),  # Linux resource management
}

# Define the DAG with Linux optimizations
dag = DAG(
    'linux_data_processing_workflow',
    default_args=default_args,
    description='Data processing workflow optimized for Ubuntu Linux',
    schedule_interval=timedelta(hours=6),  # More frequent for Linux systems
    start_date=datetime(2024, 1, 1),
    catchup=False,
    tags=['linux', 'ubuntu', 'data', 'processing'],
    max_active_runs=2,  # Linux can handle multiple runs
    max_active_tasks=8,  # Optimized for multi-core Linux
)

# Task 1: System Information Check (Linux-specific)
def check_system_info():
    """Check Linux system information and resources"""
    
    system_info = {
        'platform': platform.platform(),
        'system': platform.system(),
        'release': platform.release(),
        'machine': platform.machine(),
        'processor': platform.processor(),
        'cpu_count': psutil.cpu_count(),
        'cpu_percent': psutil.cpu_percent(interval=1),
        'memory_total': psutil.virtual_memory().total / (1024**3),  # GB
        'memory_available': psutil.virtual_memory().available / (1024**3),  # GB
        'memory_percent': psutil.virtual_memory().percent,
        'disk_usage': psutil.disk_usage('/').percent,
    }
    
    # Create data directory with proper Linux permissions
    os.makedirs('/opt/airflow/data', exist_ok=True)
    os.chmod('/opt/airflow/data', 0o755)
    
    # Save system info
    system_df = pd.DataFrame([system_info])
    system_df.to_csv('/opt/airflow/data/system_info.csv', index=False)
    
    logging.info(f"Linux System Info: {system_info}")
    
    # Warn if resources are low
    if system_info['memory_percent'] > 80:
        logging.warning(f"High memory usage: {system_info['memory_percent']:.1f}%")
    if system_info['disk_usage'] > 85:
        logging.warning(f"High disk usage: {system_info['disk_usage']:.1f}%")
    
    return f"System check completed on {system_info['platform']}"

t0 = PythonOperator(
    task_id='check_system_info',
    python_callable=check_system_info,
    dag=dag,
    pool='linux_pool',  # Linux resource pool
)

# Task 1: Create a sample CSV file with Linux optimizations
def create_sample_data():
    """Create sample data with Linux-specific optimizations"""
    
    # Use multiple CPU cores for data generation (Linux advantage)
    import numpy as np
    
    # Create larger dataset for Linux systems
    size = 1000  # Larger dataset for Linux performance testing
    
    # Generate data using numpy for better Linux performance
    np.random.seed(42)
    
    data = {
        'id': range(1, size + 1),
        'name': [f'LinuxUser_{i}' for i in range(1, size + 1)],
        'age': np.random.randint(20, 80, size),
        'salary': np.random.randint(30000, 150000, size),
        'department': np.random.choice(['Engineering', 'Marketing', 'Sales', 'HR', 'Finance'], size),
        'experience': np.random.randint(0, 25, size),
        'city': np.random.choice(['Ubuntu City', 'Linux Town', 'Open Source Village', 'Debian District'], size),
        'timestamp': [datetime.now() - timedelta(days=np.random.randint(0, 365)) for _ in range(size)]
    }
    
    df = pd.DataFrame(data)
    
    # Linux optimization: Use efficient file format
    csv_path = '/opt/airflow/data/sample_data.csv'
    df.to_csv(csv_path, index=False)
    
    # Set proper Linux file permissions
    os.chmod(csv_path, 0o644)
    
    logging.info(f"Created sample data with {len(df)} records on Linux system")
    return f"Sample data created successfully: {len(df)} records"

t1 = PythonOperator(
    task_id='create_sample_data',
    python_callable=create_sample_data,
    dag=dag,
    pool='linux_pool',
)

# Task 2: Process the data with Linux optimizations
def process_data():
    """Process data with Linux-specific optimizations"""
    
    # Read the CSV file with Linux optimizations
    df = pd.read_csv('/opt/airflow/data/sample_data.csv')
    
    # Linux-specific data processing optimizations
    df['salary_category'] = pd.cut(df['salary'], 
                                 bins=[0, 50000, 80000, 120000, float('inf')], 
                                 labels=['Entry', 'Mid', 'Senior', 'Executive'])
    
    df['experience_level'] = pd.cut(df['experience'], 
                                   bins=[0, 2, 5, 10, float('inf')], 
                                   labels=['Junior', 'Mid-level', 'Senior', 'Expert'])
    
    # Calculate comprehensive statistics
    stats = {
        'total_records': len(df),
        'avg_age': df['age'].mean(),
        'avg_salary': df['salary'].mean(),
        'avg_experience': df['experience'].mean(),
        'max_salary': df['salary'].max(),
        'min_salary': df['salary'].min(),
        'departments': df['department'].nunique(),
        'cities': df['city'].nunique(),
        'processing_time': datetime.now().isoformat(),
        'cpu_count': psutil.cpu_count(),
        'memory_usage_mb': psutil.Process().memory_info().rss / 1024 / 1024
    }
    
    # Linux optimization: Use efficient storage
    processed_path = '/opt/airflow/data/processed_data.csv'
    df.to_csv(processed_path, index=False)
    os.chmod(processed_path, 0o644)
    
    # Save comprehensive statistics
    stats_path = '/opt/airflow/data/statistics.csv'
    pd.DataFrame([stats]).to_csv(stats_path, index=False)
    os.chmod(stats_path, 0o644)
    
    logging.info(f"Processed {len(df)} records using {stats['cpu_count']} CPU cores")
    return f"Data processed successfully. Average salary: {stats['avg_salary']:.2f}"

t2 = PythonOperator(
    task_id='process_data',
    python_callable=process_data,
    dag=dag,
    pool='linux_pool',
)

# Task 3: Generate comprehensive Linux report
def generate_report():
    """Generate comprehensive report with Linux system information"""
    
    # Read processed data and stats
    df = pd.read_csv('/opt/airflow/data/processed_data.csv')
    stats = pd.read_csv('/opt/airflow/data/statistics.csv')
    system_info = pd.read_csv('/opt/airflow/data/system_info.csv')
    
    # Get current system status
    current_memory = psutil.virtual_memory().percent
    current_cpu = psutil.cpu_percent(interval=1)
    
    # Create comprehensive HTML report
    html_content = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Ubuntu Linux Data Processing Report</title>
        <style>
            body {{ 
                font-family: 'Ubuntu', Arial, sans-serif; 
                margin: 20px; 
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: #333;
            }}
            .container {{
                background: white;
                padding: 30px;
                border-radius: 15px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.2);
                max-width: 1200px;
                margin: 0 auto;
            }}
            h1 {{ 
                color: #E95420; 
                text-align: center; 
                font-size: 2.5em;
                margin-bottom: 10px;
            }}
            .subtitle {{
                text-align: center;
                color: #666;
                font-size: 1.2em;
                margin-bottom: 30px;
            }}
            .system-info {{
                background: #f8f9fa;
                padding: 20px;
                border-radius: 10px;
                margin: 20px 0;
                border-left: 5px solid #E95420;
            }}
            table {{ 
                border-collapse: collapse; 
                width: 100%; 
                margin: 20px 0;
                background: white;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }}
            th, td {{ 
                border: 1px solid #ddd; 
                padding: 12px; 
                text-align: left; 
            }}
            th {{ 
                background: linear-gradient(135deg, #E95420, #ff6b35);
                color: white;
                font-weight: bold;
            }}
            tr:nth-child(even) {{ background-color: #f9f9f9; }}
            tr:hover {{ background-color: #f5f5f5; }}
            .metric-card {{
                display: inline-block;
                background: linear-gradient(135deg, #667eea, #764ba2);
                color: white;
                padding: 20px;
                margin: 10px;
                border-radius: 10px;
                text-align: center;
                min-width: 150px;
                box-shadow: 0 4px 15px rgba(0,0,0,0.2);
            }}
            .metric-value {{
                font-size: 2em;
                font-weight: bold;
                display: block;
            }}
            .footer {{
                margin-top: 30px;
                padding: 20px;
                background: #f8f9fa;
                border-radius: 10px;
                text-align: center;
                color: #666;
            }}
            .linux-badge {{
                background: #E95420;
                color: white;
                padding: 5px 10px;
                border-radius: 15px;
                font-size: 0.8em;
                display: inline-block;
                margin: 5px;
            }}
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🐧 Ubuntu Linux Data Processing Report</h1>
            <div class="subtitle">Generated on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</div>
            
            <div class="system-info">
                <h2>🖥️ System Information</h2>
                <p><strong>Platform:</strong> {system_info['platform'].iloc[0]}</p>
                <p><strong>System:</strong> {system_info['system'].iloc[0]} {system_info['release'].iloc[0]}</p>
                <p><strong>Machine:</strong> {system_info['machine'].iloc[0]}</p>
                <p><strong>CPU Cores:</strong> {int(system_info['cpu_count'].iloc[0])}</p>
                <p><strong>Total Memory:</strong> {system_info['memory_total'].iloc[0]:.1f} GB</p>
                <p><strong>Current Memory Usage:</strong> {current_memory:.1f}%</p>
                <p><strong>Current CPU Usage:</strong> {current_cpu:.1f}%</p>
            </div>
            
            <h2>📊 Processing Metrics</h2>
            <div style="text-align: center;">
                <div class="metric-card">
                    <span class="metric-value">{int(stats['total_records'].iloc[0])}</span>
                    <div>Total Records</div>
                </div>
                <div class="metric-card">
                    <span class="metric-value">{stats['avg_age'].iloc[0]:.1f}</span>
                    <div>Avg Age</div>
                </div>
                <div class="metric-card">
                    <span class="metric-value">${stats['avg_salary'].iloc[0]:,.0f}</span>
                    <div>Avg Salary</div>
                </div>
                <div class="metric-card">
                    <span class="metric-value">{stats['avg_experience'].iloc[0]:.1f}</span>
                    <div>Avg Experience</div>
                </div>
            </div>
            
            <h2>💰 Salary Distribution</h2>
            <table>
                <tr>
                    <th>Category</th>
                    <th>Count</th>
                    <th>Percentage</th>
                    <th>Avg Salary</th>
                </tr>
    """
    
    # Calculate salary category statistics
    salary_stats = df.groupby('salary_category').agg({
        'id': 'count',
        'salary': 'mean'
    }).round(2)
    
    total = len(df)
    for category, row in salary_stats.iterrows():
        count = int(row['id'])
        percentage = (count / total) * 100
        avg_salary = row['salary']
        
        html_content += f"""
            <tr>
                <td><span class="linux-badge">{category}</span></td>
                <td>{count}</td>
                <td>{percentage:.1f}%</td>
                <td>${avg_salary:,.0f}</td>
            </tr>
        """
    
    # Department distribution
    html_content += f"""
            </table>
            
            <h2>🏢 Department Distribution</h2>
            <table>
                <tr>
                    <th>Department</th>
                    <th>Count</th>
                    <th>Avg Salary</th>
                    <th>Avg Experience</th>
                </tr>
    """
    
    dept_stats = df.groupby('department').agg({
        'id': 'count',
        'salary': 'mean',
        'experience': 'mean'
    }).round(2)
    
    for dept, row in dept_stats.iterrows():
        html_content += f"""
            <tr>
                <td>{dept}</td>
                <td>{int(row['id'])}</td>
                <td>${row['salary']:,.0f}</td>
                <td>{row['experience']:.1f} years</td>
            </tr>
        """
    
    html_content += f"""
            </table>
            
            <div class="footer">
                <p><strong>🐧 Powered by Ubuntu Linux & Apache Airflow</strong></p>
                <p>Processing completed in optimized Linux environment</p>
                <p><strong>Memory Usage:</strong> {stats['memory_usage_mb'].iloc[0]:.1f} MB | 
                   <strong>CPU Cores Used:</strong> {int(stats['cpu_count'].iloc[0])}</p>
                <p>Report generated at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
            </div>
        </div>
    </body>
    </html>
    """
    
    # Save the comprehensive report
    report_path = '/opt/airflow/data/report.html'
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write(html_content)
    
    # Set proper Linux permissions
    os.chmod(report_path, 0o644)
    
    logging.info(f"Generated comprehensive Linux report: {report_path}")
    return f"Comprehensive Linux report generated with {len(df)} records"

t3 = PythonOperator(
    task_id='generate_report',
    python_callable=generate_report,
    dag=dag,
    pool='linux_pool',
)

# Task 4: Linux system monitoring and cleanup
def system_cleanup_and_notify():
    """Perform Linux system cleanup and notification"""
    
    # Get final system stats
    final_memory = psutil.virtual_memory().percent
    final_cpu = psutil.cpu_percent(interval=1)
    disk_usage = psutil.disk_usage('/opt/airflow/data').percent
    
    # Log system status
    logging.info(f"Final system status - Memory: {final_memory:.1f}%, CPU: {final_cpu:.1f}%, Disk: {disk_usage:.1f}%")
    
    # Clean up temporary files (Linux best practice)
    temp_files = [f for f in os.listdir('/opt/airflow/data') if f.startswith('temp_')]
    for temp_file in temp_files:
        os.remove(os.path.join('/opt/airflow/data', temp_file))
    
    return f"Linux workflow completed successfully! Memory: {final_memory:.1f}%, CPU: {final_cpu:.1f}%"

t4 = PythonOperator(
    task_id='system_cleanup_notify',
    python_callable=system_cleanup_and_notify,
    dag=dag,
)

# Linux-specific bash task for system information
t5 = BashOperator(
    task_id='linux_system_check',
    bash_command='''
    echo "=== Ubuntu Linux System Information ==="
    echo "Hostname: $(hostname)"
    echo "Kernel: $(uname -r)"
    echo "Ubuntu Version: $(lsb_release -d | cut -f2)"
    echo "Uptime: $(uptime)"
    echo "Load Average: $(cat /proc/loadavg)"
    echo "Memory Info: $(free -h | grep Mem)"
    echo "Disk Usage: $(df -h /opt/airflow/data | tail -1)"
    echo "Docker Info: $(docker --version 2>/dev/null || echo 'Docker not accessible')"
    echo "=== End System Check ==="
    ''',
    dag=dag,
)

# Set task dependencies with Linux optimization
t0 >> [t1, t5]  # Parallel execution (Linux advantage)
t1 >> t2 >> t3 >> t4