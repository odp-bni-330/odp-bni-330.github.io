# Python REST API to Telegram Bot

## Cara Menjalankan

```bash
# atur environment variable

# apabila belum ada folder :
python -m venv venv

# aktifkan virtual environment
source venv/bin/activate

# install dependency
# pip install python-telegram-bot --upgrade
pip install python-dotenv
pip install requests

# jalankan main program
python bot.py
```

## Output

![output-test-python](image.png)
