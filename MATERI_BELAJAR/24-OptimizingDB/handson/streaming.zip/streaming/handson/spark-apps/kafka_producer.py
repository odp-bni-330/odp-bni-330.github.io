from kafka import KafkaProducer
import json
import time
import random
from datetime import datetime

# Configure Kafka producer
producer = KafkaProducer(
    bootstrap_servers=['kafka:29092'],
    value_serializer=lambda v: json.dumps(v).encode('utf-8')
)

# Sample product data
products = [
    {"product_id": 1, "name": "Laptop", "category": "Electronics", "price": 1200},
    {"product_id": 2, "name": "Smartphone", "category": "Electronics", "price": 800},
    {"product_id": 3, "name": "Headphones", "category": "Electronics", "price": 150},
    {"product_id": 4, "name": "T-shirt", "category": "Clothing", "price": 25},
    {"product_id": 5, "name": "Jeans", "category": "Clothing", "price": 50},
    {"product_id": 6, "name": "Sneakers", "category": "Footwear", "price": 80},
    {"product_id": 7, "name": "Book", "category": "Books", "price": 15},
    {"product_id": 8, "name": "Watch", "category": "Accessories", "price": 120},
]

# Generate transaction data
def generate_transaction():
    product = random.choice(products)
    quantity = random.randint(1, 5)
    
    transaction = {
        "transaction_id": f"tx-{int(time.time() * 1000)}",
        "product_id": product["product_id"],
        "product_name": product["name"],
        "category": product["category"],
        "quantity": quantity,
        "price_per_unit": product["price"],
        "total_amount": product["price"] * quantity,
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    
    return transaction

# Send transactions to Kafka
def send_transactions(topic_name="transactions", transactions_count=100, delay=1):
    for i in range(transactions_count):
        transaction = generate_transaction()
        producer.send(topic_name, transaction)
        print(f"Sent transaction {i+1}/{transactions_count}: {transaction}")
        time.sleep(delay)
    
    producer.flush()

if __name__ == "__main__":
    print("Starting to generate transaction data...")
    try:
        send_transactions(transactions_count=100, delay=0.5)
        print("Data generation completed.")
    except Exception as e:
        print(f"Error generating data: {e}")
        import traceback
        traceback.print_exc()