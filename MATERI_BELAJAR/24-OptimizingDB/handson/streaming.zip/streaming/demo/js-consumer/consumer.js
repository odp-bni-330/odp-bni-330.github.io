const { Kafka } = require('kafkajs');
const fs = require('fs-extra');
const path = require('path');

// Kafka client configuration
const kafka = new Kafka({
  clientId: 'demo-consumer',
  // brokers: [process.env.KAFKA_BROKERS || 'localhost:9092']
  brokers: [process.env.KAFKA_BROKERS || 'localhost:9093']
});

const consumer = kafka.consumer({ groupId: 'demo-consumer-group' });
const TOPICS = ['user-events', 'processed-events', 'alerts'];

// Statistics tracking
let stats = {
  totalEvents: 0,
  eventsByType: {},
  eventsByCategory: {},
  totalRevenue: 0,
  startTime: new Date()
};

// Process incoming message
const processMessage = async (topic, message) => {
  try {
    const event = JSON.parse(message.value.toString());
    
    // Update statistics
    stats.totalEvents++;
    stats.eventsByType[event.event_type] = (stats.eventsByType[event.event_type] || 0) + 1;
    
    if (event.product) {
      const category = event.product.category;
      stats.eventsByCategory[category] = (stats.eventsByCategory[category] || 0) + 1;
      
      if (event.event_type === 'PURCHASE') {
        stats.totalRevenue += event.product.total_amount;
      }
    }
    
    // Log event based on topic
    if (topic === 'user-events') {
      console.log(`📥 [${event.event_type}] User: ${event.user_id.substring(0, 8)}... Location: ${event.location}`);
      
      if (event.product) {
        console.log(`   Product: ${event.product.product_name} ($${event.product.total_amount})`);
      }
      
      if (event.search) {
        console.log(`   Search: "${event.search.query}" in ${event.search.category_filter}`);
      }
    } else if (topic === 'processed-events') {
      console.log(`🔄 [PROCESSED] ${JSON.stringify(event)}`);
    } else if (topic === 'alerts') {
      console.log(`🚨 [ALERT] ${event.message || JSON.stringify(event)}`);
    }
    
    // Save statistics to file every 10 events
    if (stats.totalEvents % 10 === 0) {
      await saveStatistics();
    }
    
  } catch (error) {
    console.error('Error processing message:', error);
  }
};

// Save statistics to file
const saveStatistics = async () => {
  try {
    const dataDir = '/app/data';
    await fs.ensureDir(dataDir);
    
    const runtimeMinutes = (new Date() - stats.startTime) / (1000 * 60);
    const eventsPerMinute = stats.totalEvents / runtimeMinutes;
    
    const statsWithMetrics = {
      ...stats,
      runtimeMinutes: runtimeMinutes.toFixed(2),
      eventsPerMinute: eventsPerMinute.toFixed(2),
      lastUpdated: new Date().toISOString()
    };
    
    await fs.writeFile(
      path.join(dataDir, 'consumer_stats.json'), 
      JSON.stringify(statsWithMetrics, null, 2)
    );
    
    console.log(`📊 Statistics saved: ${stats.totalEvents} events processed, $${stats.totalRevenue.toFixed(2)} revenue`);
  } catch (error) {
    console.error('Error saving statistics:', error);
  }
};

// Display periodic statistics
const displayStats = () => {
  console.log('\n📈 === CONSUMER STATISTICS ===');
  console.log(`Total Events: ${stats.totalEvents}`);
  console.log(`Total Revenue: $${stats.totalRevenue.toFixed(2)}`);
  console.log('Events by Type:', stats.eventsByType);
  console.log('Events by Category:', stats.eventsByCategory);
  console.log('================================\n');
};

// Main function
const run = async () => {
  try {
    await consumer.connect();
    console.log('🚀 Consumer connected to Kafka');
    
    await consumer.subscribe({ topics: TOPICS, fromBeginning: false });
    console.log(`📡 Subscribed to topics: ${TOPICS.join(', ')}`);
    
    // Display stats every 30 seconds
    setInterval(displayStats, 30000);
    
    await consumer.run({
      eachMessage: async ({ topic, partition, message }) => {
        await processMessage(topic, message);
      },
    });
    
  } catch (error) {
    console.error('Failed to start consumer:', error);
  }
};

// Graceful shutdown
const shutdown = async () => {
  console.log('\n🛑 Shutting down consumer...');
  try {
    await saveStatistics();
    await consumer.disconnect();
    console.log('✅ Consumer disconnected successfully');
    process.exit(0);
  } catch (error) {
    console.error('Error during shutdown:', error);
    process.exit(1);
  }
};

process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

run().catch(console.error); 