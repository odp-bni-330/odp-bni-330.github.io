from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
import json
from datetime import datetime

def create_spark_session():
    """Create and configure Spark session"""
    return (SparkSession.builder
            .appName("KafkaSparkStreamingDemo")
            .config("spark.jars.packages", "org.apache.spark:spark-sql-kafka-0-10_2.12:3.3.0")
            .config("spark.sql.adaptive.enabled", "true")
            .config("spark.sql.adaptive.coalescePartitions.enabled", "true")
            .getOrCreate())

def define_event_schema():
    """Define schema for user events"""
    return StructType([
        StructField("event_id", StringType(), True),
        StructField("user_id", StringType(), True),
        StructField("session_id", StringType(), True),
        StructField("event_type", StringType(), True),
        StructField("timestamp", StringType(), True),
        StructField("user_agent", StringType(), True),
        StructField("ip_address", StringType(), True),
        StructField("location", StringType(), True),
        StructField("customer_segment", StringType(), True),
        StructField("product", StructType([
            StructField("product_id", IntegerType(), True),
            StructField("product_name", StringType(), True),
            StructField("category", StringType(), True),
            StructField("price_per_unit", DoubleType(), True),
            StructField("quantity", IntegerType(), True),
            StructField("total_amount", DoubleType(), True)
        ]), True),
        StructField("transaction", StructType([
            StructField("transaction_id", StringType(), True),
            StructField("payment_method", StringType(), True),
            StructField("discount_applied", BooleanType(), True),
            StructField("discount_amount", DoubleType(), True)
        ]), True),
        StructField("search", StructType([
            StructField("query", StringType(), True),
            StructField("category_filter", StringType(), True),
            StructField("results_count", IntegerType(), True)
        ]), True)
    ])

def read_kafka_stream(spark):
    """Read streaming data from Kafka"""
    return (spark
            .readStream
            .format("kafka")
            .option("kafka.bootstrap.servers", "kafka:29092")
            .option("subscribe", "user-events")
            .option("startingOffsets", "latest")
            .option("maxOffsetsPerTrigger", "1000")
            .load())

def process_stream(df, schema):
    """Process streaming data"""
    # Parse JSON data
    parsed_df = df.selectExpr("CAST(value AS STRING) as json_value") \
        .select(from_json(col("json_value"), schema).alias("data")) \
        .select("data.*") \
        .withColumn("processing_time", current_timestamp()) \
        .withColumn("timestamp_parsed", to_timestamp("timestamp", "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"))
    
    return parsed_df

def analyze_real_time_metrics(df):
    """Analyze real-time metrics with windowing"""
    # Add watermark to handle late data
    df_with_watermark = df.withWatermark("timestamp_parsed", "2 minutes")
    
    return df_with_watermark \
        .groupBy(
            window(col("timestamp_parsed"), "1 minute"),
            "event_type",
            "location",
            "customer_segment"
        ) \
        .agg(
            count("event_id").alias("event_count"),
            approx_count_distinct("user_id").alias("unique_users"),
            approx_count_distinct("session_id").alias("unique_sessions"),
            sum(when(col("product.total_amount").isNotNull(), col("product.total_amount")).otherwise(0)).alias("total_revenue"),
            avg(when(col("product.total_amount").isNotNull(), col("product.total_amount"))).alias("avg_transaction_value"),
            max(col("product.total_amount")).alias("max_transaction_value")
        ) \
        .withColumn("revenue_per_user", col("total_revenue") / col("unique_users"))

def analyze_product_performance(df):
    """Analyze product performance"""
    # Filter only events with product data
    product_events = df.filter(col("product").isNotNull()) \
        .withWatermark("timestamp_parsed", "2 minutes")
    
    return product_events \
        .groupBy(
            window(col("timestamp_parsed"), "2 minutes"),
            "product.category",
            "product.product_name"
        ) \
        .agg(
            count("event_id").alias("interaction_count"),
            sum(when(col("event_type") == "PURCHASE", col("product.quantity")).otherwise(0)).alias("units_sold"),
            sum(when(col("event_type") == "PURCHASE", col("product.total_amount")).otherwise(0)).alias("revenue"),
            approx_count_distinct("user_id").alias("unique_customers"),
            approx_count_distinct("location").alias("locations_active")
        ) \
        .filter(col("interaction_count") > 0)

def detect_anomalies(df):
    """Detect anomalies and generate alerts"""
    # High-value transactions
    high_value_purchases = df.filter(
        (col("event_type") == "PURCHASE") & (col("product.total_amount") > 1000)
    ).select(
        col("event_id"),
        col("user_id"),
        col("product.product_name"),
        col("product.total_amount"),
        col("location"),
        lit("HIGH_VALUE_PURCHASE").alias("alert_type"),
        concat(lit("High value purchase: $"), col("product.total_amount"), 
               lit(" for "), col("product.product_name")).alias("alert_message"),
        current_timestamp().alias("alert_timestamp")
    )
    
    return high_value_purchases

def write_to_kafka(df, topic, checkpoint_location):
    """Write processed data back to Kafka"""
    return df.selectExpr("to_json(struct(*)) AS value") \
        .writeStream \
        .format("kafka") \
        .option("kafka.bootstrap.servers", "kafka:29092") \
        .option("topic", topic) \
        .option("checkpointLocation", checkpoint_location) \
        .outputMode("append")

def write_to_console(df, query_name):
    """Write data to console for monitoring"""
    return df.writeStream \
        .outputMode("update") \
        .format("console") \
        .option("truncate", "false") \
        .option("numRows", 20) \
        .queryName(query_name)

def main():
    # Create Spark session
    spark = create_spark_session()
    spark.sparkContext.setLogLevel("WARN")
    
    print("🚀 Starting Kafka Spark Streaming Demo...")
    
    # Define schema and read stream
    schema = define_event_schema()
    raw_stream = read_kafka_stream(spark)
    processed_stream = process_stream(raw_stream, schema)
    
    # Create different analysis streams
    metrics_stream = analyze_real_time_metrics(processed_stream)
    product_stream = analyze_product_performance(processed_stream)
    anomaly_stream = detect_anomalies(processed_stream)
    
    try:
        # Start console outputs for monitoring
        query1 = write_to_console(metrics_stream, "real_time_metrics") \
            .trigger(processingTime='30 seconds') \
            .start()
        
        query2 = write_to_console(product_stream, "product_performance") \
            .trigger(processingTime='60 seconds') \
            .start()
        
        # Write alerts to Kafka
        query3 = write_to_kafka(anomaly_stream, "alerts", "/opt/spark-data/checkpoints/alerts") \
            .trigger(processingTime='10 seconds') \
            .start()
        
        # Write processed metrics to Kafka
        query4 = write_to_kafka(metrics_stream, "processed-events", "/opt/spark-data/checkpoints/processed") \
            .trigger(processingTime='30 seconds') \
            .start()
        
        print("✅ All streaming queries started successfully!")
        print("📊 Monitor the output in the console...")
        print("🔍 Check Kafka topics: processed-events, alerts")
        print("🌐 Spark UI available at: http://localhost:4040")
        
        # Wait for termination
        query1.awaitTermination()
        
    except Exception as e:
        print(f"❌ Error in streaming: {e}")
    finally:
        spark.stop()

if __name__ == "__main__":
    main() 