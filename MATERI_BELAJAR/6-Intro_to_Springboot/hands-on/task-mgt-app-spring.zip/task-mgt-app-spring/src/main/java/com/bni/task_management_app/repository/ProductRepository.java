package com.bni.task_management_app.repository;

import com.bni.task_management_app.model.*;
import org.springframework.stereotype.Repository;

import java.util.*;
import java.util.concurrent.atomic.AtomicLong;

/********************** REPOSITORY LAYER ***********************/
// tidak boleh ada algoritma / proses kompleks
// hanya boleh ada proses CRUD ke DB

@Repository         // => menandakan bahwa merupakan repository layer
public class ProductRepository {
    private final Map<Long, Product> products = new HashMap<>();
    private final AtomicLong counter = new AtomicLong(1);

    
    public Product save(Product product) {
        Long id = counter.getAndIncrement();
        product.setId(id);
        products.put(id, product);
        return product;
    }

    public Optional<Product> findById(Long id) {
        return Optional.ofNullable(products.get(id));
    }

    public Collection<Product> findAll() {
        return products.values();
    }

    public boolean update(Product product) {
        if (products.containsKey(product.getId())) {
            products.put(product.getId(), product);
            return true;
        }
        return false;
    }

    public boolean deleteById(Long id) {
        return products.remove(id) != null;
    }
}
/********************** END OF REPOSITORY LAYER ***********************/