const { SparkSession } = require('node-spark');

async function startStreaming() {
  try {
    // Create a Spark session
    const spark = new SparkSession()
      .appName('KafkaSparkStreamingJS')
      .master('local[*]')
      .getOrCreate();

    // Set log level
    spark.sparkContext().setLogLevel('WARN');

    console.log('Spark session created');

    // Read from Kafka
    const kafkaDF = spark
      .readStream()
      .format('kafka')
      .option('kafka.bootstrap.servers', 'kafka:29092')
      .option('subscribe', 'user-events')
      .option('startingOffsets', 'earliest')
      .load();

    // Convert the binary value to string
    const valueDF = kafkaDF.selectExpr('CAST(value AS STRING) as json_value');

    // Parse JSON data
    const parsedDF = valueDF
      .select(spark.functions.from_json(
        valueDF.col('json_value'),
        {
          userId: 'string',
          name: 'string',
          email: 'string',
          eventType: 'string',
          timestamp: 'string',
          product: {
            id: 'string',
            name: 'string',
            price: 'string'
          }
        }
      ).as('data'))
      .select('data.*');

    // Process the data - count events by type
    const eventCountsDF = parsedDF
      .groupBy(
        spark.functions.window(
          spark.functions.to_timestamp(parsedDF.col('timestamp')),
          '1 minute'
        ),
        parsedDF.col('eventType')
      )
      .count()
      .orderBy('window', 'eventType');

    // Calculate average product price for purchase events
    const purchaseAnalysisDF = parsedDF
      .filter(parsedDF.col('eventType').equalTo('PURCHASE'))
      .select(
        spark.functions.to_timestamp(parsedDF.col('timestamp')).as('event_time'),
        parsedDF.col('product.price').cast('double').as('price')
      )
      .groupBy(spark.functions.window(spark.col('event_time'), '1 minute'))
      .agg(
        spark.functions.avg('price').as('avg_price'),
        spark.functions.count('*').as('purchase_count')
      )
      .orderBy('window');

    // Output to console
    const consoleQuery = eventCountsDF
      .writeStream()
      .outputMode('complete')
      .format('console')
      .option('truncate', false)
      .start();

    // Save event counts to CSV files in spark-data directory
    const fileQuery = eventCountsDF
      .writeStream()
      .outputMode('append')
      .format('csv')
      .option('path', '/opt/spark-data/event-counts')
      .option('checkpointLocation', '/opt/spark-data/checkpoints/event-counts')
      .start();

    // Save purchase analysis to JSON files in spark-data directory
    const purchaseQuery = purchaseAnalysisDF
      .writeStream()
      .outputMode('append')
      .format('json')
      .option('path', '/opt/spark-data/purchase-analysis')
      .option('checkpointLocation', '/opt/spark-data/checkpoints/purchase-analysis')
      .start();

    // Wait for the queries to terminate
    await Promise.all([
      consoleQuery.awaitTermination(),
      fileQuery.awaitTermination(),
      purchaseQuery.awaitTermination()
    ]);
  } catch (error) {
    console.error('Error in Spark streaming:', error);
  }
}

// Start the streaming application
startStreaming().catch(console.error);