# Hands-on: Analisis Data dari Sumber yang Berbeda

## Menarik Data dari Berbagai Sumber

Mengambil data penjualan dari PostgreSQL menggunakan pgAdmin dan data pelanggan dari MongoDB untuk mendapatkan gambaran lengkap tentang bisnis.

## Menggabungkan Data

Menggabungkan data dari kedua sumber menggunakan Tableau untuk membuat dataset terintegrasi yang dapat dianalisis secara komprehensif.

## Membuat Visualisasi

Membuat visualisasi data di Tableau untuk memahami tren penjualan dan preferensi pelanggan, mengungkap insight yang mungkin tidak terlihat ketika menganalisis data secara terpisah.

## Demo Langsung: Menarik Data dari PostgreSQL

### Menulis Query SQL

Menyusun query untuk mengambil data penjualan yang relevan

### Menjalankan Query

Mengeksekusi query di pgAdmin atau menggunakan command line psql

### Mengekspor Hasil

Menyimpan hasil query untuk diimpor ke Tableau dalam format CSV atau Excel

### Mengimpor ke Tableau

Memuat data ke dalam Tableau untuk visualisasi

Dalam demo ini, kita akan melihat langsung bagaimana menjalankan query SQL untuk mendapatkan data penjualan dari database PostgreSQL dan kemudian menampilkan hasilnya di Tableau untuk analisis visual.

### Contoh Query PostgreSQL untuk Data Penjualan

```sql
-- Mengambil data penjualan dengan informasi produk
SELECT 
    s.sale_id,
    s.sale_date,
    s.customer_id,
    p.product_name,
    p.category,
    s.quantity,
    s.unit_price,
    s.total_amount
FROM sales s
JOIN products p ON s.product_id = p.product_id
WHERE s.sale_date >= '2024-01-01'
ORDER BY s.sale_date DESC;

-- Mengambil ringkasan penjualan per kategori
SELECT 
    p.category,
    COUNT(s.sale_id) as total_transactions,
    SUM(s.total_amount) as total_revenue,
    AVG(s.total_amount) as avg_transaction_value
FROM sales s
JOIN products p ON s.product_id = p.product_id
GROUP BY p.category
ORDER BY total_revenue DESC;
```

## Demo Langsung: Menarik Data dari MongoDB

### Mengakses MongoDB

Membuka shell MongoDB atau MongoDB Compass untuk mengakses database pelanggan.

### Menulis Query Aggregation

Menyusun pipeline aggregation untuk mendapatkan data pelanggan yang relevan.

### Mengekspor Data

Menyimpan hasil query dalam format JSON atau CSV untuk diimpor ke Tableau.

### Membuat Hubungan Data

Menghubungkan data pelanggan dengan data penjualan di Tableau berdasarkan field kunci yang sama (customer_id).

### Contoh Query MongoDB untuk Data Pelanggan

```javascript
// Mengambil data pelanggan dengan informasi demografis
db.customers.find({
    "status": "active"
}, {
    "customer_id": 1,
    "name": 1,
    "email": 1,
    "age": 1,
    "gender": 1,
    "location.city": 1,
    "location.country": 1,
    "registration_date": 1
});

// Agregasi data pelanggan berdasarkan lokasi
db.customers.aggregate([
    {
        $match: { "status": "active" }
    },
    {
        $group: {
            _id: "$location.city",
            total_customers: { $sum: 1 },
            avg_age: { $avg: "$age" },
            customers: { $push: "$customer_id" }
        }
    },
    {
        $sort: { total_customers: -1 }
    }
]);
```

## Analisis Data Gabungan

Setelah menggabungkan data dari PostgreSQL dan MongoDB, kita dapat membuat berbagai visualisasi yang menunjukkan hubungan antara produk yang terjual dan demografi pelanggan. Visualisasi ini membantu kita memahami pola pembelian berdasarkan lokasi geografis, kategori produk, dan karakteristik pelanggan lainnya.

### Langkah-langkah Analisis di Tableau

1. **Import Data PostgreSQL**
   - Buat koneksi ke PostgreSQL (localhost:5432)
   - Import hasil query penjualan

2. **Import Data MongoDB**
   - Export data pelanggan dari MongoDB ke CSV
   - Import file CSV ke Tableau

3. **Menggabungkan Data**
   - Buat relationship berdasarkan customer_id
   - Validasi hubungan data

4. **Membuat Visualisasi**
   - Dashboard penjualan per kategori dan lokasi
   - Analisis demografis pelanggan
   - Tren penjualan berdasarkan waktu

### Insight yang Dapat Diperoleh

- Produk terpopuler di setiap kota
- Profil demografis pelanggan dengan nilai transaksi tertinggi
- Korelasi antara usia pelanggan dan preferensi produk
- Tren penjualan berdasarkan waktu dan lokasi
- Segmentasi pelanggan berdasarkan perilaku pembelian 