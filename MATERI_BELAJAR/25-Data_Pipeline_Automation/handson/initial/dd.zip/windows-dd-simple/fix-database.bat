@echo off
setlocal EnableDelayedExpansion

:: Set UTF-8 encoding for proper emoji display
chcp 65001 >nul

echo.
echo 🚀 Database Fix Script for Windows DD Simple
echo.

:: Check if Node.js is available
node --version >nul 2>&1
if errorlevel 1 (
    echo ❌ Node.js is required to run this script.
    echo ℹ️  Please install Node.js from: https://nodejs.org/
    pause
    exit /b 1
)

:: Check if npm dependencies are installed
if not exist "node_modules" (
    echo ℹ️  Installing npm dependencies...
    call npm install
    if errorlevel 1 (
        echo ❌ Failed to install npm dependencies
        pause
        exit /b 1
    )
    echo ✅ Dependencies installed successfully
)

echo.
echo 🚀 Setting up PostgreSQL ^(Neon Database^)
call node setup-postgres-auto.js
if errorlevel 1 (
    echo ❌ PostgreSQL setup failed
    pause
    exit /b 1
)
echo ✅ PostgreSQL setup completed successfully!

echo.
echo 🚀 Setting up MongoDB ^(Atlas Database^)
call node setup-mongodb.js
if errorlevel 1 (
    echo ❌ MongoDB setup failed
    pause
    exit /b 1
)
echo ✅ MongoDB setup completed successfully!

echo.
echo 🚀 Testing Database Connections
echo ℹ️  Starting demo application for testing...

:: Start the demo in background
start /B call demo.bat start >nul 2>&1

:: Wait for services to start
echo ℹ️  Waiting for services to initialize...
timeout /t 8 /nobreak >nul

:: Test health endpoint
echo ℹ️  Testing health endpoint...
curl -s http://localhost:3000/api/health >temp_health.json 2>nul
if errorlevel 1 (
    echo ❌ Failed to connect to health endpoint
    goto cleanup
)

:: Check if both databases are healthy
findstr /C:"postgresql.*healthy" temp_health.json >nul && findstr /C:"mongodb.*healthy" temp_health.json >nul
if errorlevel 1 (
    echo ⚠️  Some database connections are unhealthy
    echo Health response:
    type temp_health.json
    goto cleanup
) else (
    echo ✅ Both databases are healthy!
)

:: Test PostgreSQL data
echo ℹ️  Testing PostgreSQL data...
curl -s http://localhost:3000/api/postgres/sales >temp_pg.json 2>nul
if errorlevel 1 (
    echo ⚠️  PostgreSQL data test failed
) else (
    for %%A in (temp_pg.json) do if %%~zA gtr 10 (
        echo ✅ PostgreSQL data loading successfully!
    ) else (
        echo ⚠️  PostgreSQL data test failed
    )
)

:: Test MongoDB data
echo ℹ️  Testing MongoDB data...
curl -s http://localhost:3000/api/mongodb/customers >temp_mongo.json 2>nul
if errorlevel 1 (
    echo ⚠️  MongoDB data test failed
) else (
    for %%A in (temp_mongo.json) do if %%~zA gtr 10 (
        echo ✅ MongoDB data loading successfully!
    ) else (
        echo ⚠️  MongoDB data test failed
    )
)

:cleanup
:: Clean up temp files
if exist temp_health.json del temp_health.json
if exist temp_pg.json del temp_pg.json
if exist temp_mongo.json del temp_mongo.json

:: Stop the demo
echo ℹ️  Stopping test application...
call demo.bat stop >nul 2>&1

echo.
echo 🚀 Database Fix Complete!
echo.
echo ✅ 🎉 All databases have been set up successfully!
echo.
echo ℹ️  You can now run the demo with:
echo    demo.bat start
echo.
echo ℹ️  Access the dashboard at:
echo    http://localhost:3000
echo.
pause 