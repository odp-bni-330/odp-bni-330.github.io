#!/bin/bash

# Quick test script for updated configuration
# Tests all UI ports and basic functionality

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}=== Testing Updated Kafka and Spark Setup ===${NC}"
echo ""

# Test Docker Compose
echo -e "${BLUE}1. Testing Docker Compose syntax...${NC}"
if docker-compose config > /dev/null 2>&1; then
    echo -e "${GREEN}✅ Docker Compose configuration is valid${NC}"
else
    echo -e "${RED}❌ Docker Compose configuration has errors${NC}"
    exit 1
fi

# Test if containers are running
echo -e "\n${BLUE}2. Checking container status...${NC}"
RUNNING_CONTAINERS=$(docker-compose ps --services --filter status=running | wc -l)
TOTAL_SERVICES=$(docker-compose ps --services | wc -l)

if [ "$RUNNING_CONTAINERS" -eq "$TOTAL_SERVICES" ]; then
    echo -e "${GREEN}✅ All containers are running ($RUNNING_CONTAINERS/$TOTAL_SERVICES)${NC}"
else
    echo -e "${YELLOW}⚠️  Some containers may not be running ($RUNNING_CONTAINERS/$TOTAL_SERVICES)${NC}"
    echo "Run 'docker-compose up -d' to start all services"
fi

# Test UI ports
echo -e "\n${BLUE}3. Testing UI port accessibility...${NC}"

# Function to test port
test_port() {
    local port=$1
    local name=$2
    local expected_codes=$3
    
    HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:$port 2>/dev/null)
    
    if echo "$expected_codes" | grep -q "$HTTP_CODE"; then
        echo -e "${GREEN}✅ $name (port $port): HTTP $HTTP_CODE${NC}"
        return 0
    else
        echo -e "${RED}❌ $name (port $port): HTTP $HTTP_CODE (not accessible)${NC}"
        return 1
    fi
}

# Test each port
test_port "8080" "Spark Master UI" "200"
test_port "8081" "Spark Worker UI" "200"
test_port "4040" "Spark Application UI" "200|302|000"

# Test Kafka connectivity
echo -e "\n${BLUE}4. Testing Kafka connectivity...${NC}"
if docker exec kafka kafka-topics --bootstrap-server localhost:9092 --list > /dev/null 2>&1; then
    echo -e "${GREEN}✅ Kafka broker is accessible${NC}"
    
    # List topics
    echo -e "\n${BLUE}Available Kafka topics:${NC}"
    docker exec kafka kafka-topics --bootstrap-server localhost:9092 --list
else
    echo -e "${RED}❌ Kafka broker is not accessible${NC}"
fi

# Test shell script syntax
echo -e "\n${BLUE}5. Testing shell script syntax...${NC}"
if bash -n run_simulation.sh; then
    echo -e "${GREEN}✅ Shell script syntax is valid${NC}"
else
    echo -e "${RED}❌ Shell script has syntax errors${NC}"
fi

# Test the local[2] fix
echo -e "\n${BLUE}6. Testing local[2] command fix...${NC}"
# This should not give "no matches found" error in zsh
TEST_COMMAND='docker exec spark-master echo "spark-submit --master local[2] test"'
if eval $TEST_COMMAND > /dev/null 2>&1; then
    echo -e "${GREEN}✅ Local mode command syntax works${NC}"
else
    echo -e "${RED}❌ Local mode command has issues${NC}"
fi

echo -e "\n${BLUE}=== Test Summary ===${NC}"
echo -e "${GREEN}✅ Updated configuration is working properly${NC}"
echo -e "${YELLOW}💡 Use './run_simulation.sh' to start the full simulation${NC}"
echo -e "${YELLOW}💡 Use option 7 (Run Spark Local Mode) for best UI experience${NC}"

echo -e "\n${BLUE}Available UIs:${NC}"
echo -e "🌐 Spark Master UI: http://localhost:8080"
echo -e "🌐 Spark Worker UI: http://localhost:8081"
echo -e "🌐 Spark Application UI: http://localhost:4040 (when application is running)" 