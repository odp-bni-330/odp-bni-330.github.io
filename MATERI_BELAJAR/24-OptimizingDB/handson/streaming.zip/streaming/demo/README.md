# Demo Kafka Spark Streaming dengan JavaScript

Demo ini menunjukkan implementasi data streaming menggunakan Apache Kafka, Spark Streaming, dan JavaScript. Demo ini menggunakan Docker Compose untuk menjalankan semua komponen dalam container yang terpisah.

## 🏗️ Arsitektur

```
┌─────────────────┐    ┌──────────────┐    ┌─────────────────┐    ┌──────────────┐
│   JS Producer   │───▶│    Kafka     │───▶│ Spark Streaming │───▶│ JS Consumer  │
│  (Data Maker)   │    │   Broker     │    │   (Processor)   │    │ (Analytics)  │
└─────────────────┘    └──────────────┘    └─────────────────┘    └──────────────┘
                              │                      │
                              ▼                      ▼
                       ┌──────────────┐    ┌─────────────────┐
                       │   Topics:    │    │   Output:       │
                       │ • user-events│    │ • processed-data│
                       │ • alerts     │    │ • alerts        │
                       │ • processed  │    │ • statistics    │
                       └──────────────┘    └─────────────────┘
```

## 🚀 Cara Menjalankan Demo

### Prasyarat
- Docker & Docker Compose terinstall
- Port 8080, 8081, 9092, 2181, 4040 tersedia
- Minimal 4GB RAM untuk menjalankan semua container

### 1. Memulai Demo
```bash
# Berikan permission execute pada script
chmod +x *.sh

# Jalankan demo
./start.sh
```

### 2. Menjalankan Spark Streaming
```bash
# Di terminal terpisah, jalankan Spark streaming job
./run_spark.sh
```

### 3. Monitoring
```bash
# Monitor logs dan statistik
./monitor.sh
```

### 4. Menghentikan Demo
```bash
# Stop semua container
./stop.sh
```

## 📊 Komponen Demo

### 1. JavaScript Producer (`js-producer/`)
- **Technology**: Node.js + KafkaJS + Faker
- **Function**: Generate realistic e-commerce events
- **Output**: JSON events ke Kafka topic `user-events`
- **Events**: VIEW, PURCHASE, ADD_TO_CART, SEARCH, LOGIN, LOGOUT

**Sample Event**:
```json
{
  "event_id": "uuid",
  "user_id": "uuid",
  "event_type": "PURCHASE",
  "timestamp": "2024-01-01T10:00:00.000Z",
  "location": "Jakarta",
  "customer_segment": "Premium",
  "product": {
    "product_id": 123,
    "product_name": "Smart Phone",
    "category": "Electronics",
    "price_per_unit": 799.99,
    "quantity": 1,
    "total_amount": 799.99
  }
}
```

### 2. Kafka Cluster
- **Zookeeper**: Koordinasi cluster
- **Kafka Broker**: Message broker untuk streaming
- **Topics**:
  - `user-events`: Input events dari producer
  - `processed-events`: Processed data dari Spark
  - `alerts`: Alert dan anomali detection

### 3. Spark Streaming (`spark-apps/`)
- **Technology**: PySpark + Structured Streaming
- **Function**: Real-time processing dan analytics
- **Features**:
  - Real-time metrics aggregation
  - Product performance analysis
  - Anomaly detection (high-value purchases)
  - Windowed analytics (1-2 minute windows)

### 4. JavaScript Consumer (`js-consumer/`)
- **Technology**: Node.js + KafkaJS
- **Function**: Consume dan analyze processed events
- **Output**: Statistics file dan console logs
- **File**: `./data/consumer_stats.json`

## 🌐 Web Interfaces

Setelah menjalankan demo, akses interface berikut:

- **Spark Master UI**: http://localhost:8080
- **Spark Worker UI**: http://localhost:8081  
- **Spark Application UI**: http://localhost:4040 (saat streaming job berjalan)

## 📈 Monitoring dan Analytics

### Real-time Metrics
Demo menghasilkan metrics berikut:
- Event count per minute
- Revenue analytics
- Product performance
- User behavior patterns
- Geographic distribution
- Customer segment analysis

### Anomaly Detection
- High-value transactions (>$1000)
- Unusual purchase patterns
- Geographic anomalies

### Statistics Output
File `./data/consumer_stats.json` berisi:
```json
{
  "totalEvents": 1250,
  "eventsByType": {
    "VIEW": 450,
    "PURCHASE": 300,
    "ADD_TO_CART": 250,
    "SEARCH": 200,
    "LOGIN": 50
  },
  "eventsByCategory": {
    "Electronics": 400,
    "Clothing": 350,
    "Books": 200
  },
  "totalRevenue": 50250.75,
  "runtimeMinutes": "15.5",
  "eventsPerMinute": "80.6"
}
```

## 🛠️ Troubleshooting

### Container Issues
```bash
# Check container status
docker-compose ps

# View logs
docker-compose logs [service-name]

# Restart specific service
docker-compose restart [service-name]
```

### Kafka Issues
```bash
# Check Kafka topics
docker exec demo_kafka kafka-topics --bootstrap-server localhost:9092 --list

# Check recent messages
docker exec demo_kafka kafka-console-consumer \
  --bootstrap-server localhost:9092 \
  --topic user-events \
  --from-beginning --max-messages 10
```

### Spark Issues
```bash
# Check Spark UI
# http://localhost:8080

# View Spark logs
docker-compose logs spark-master
docker-compose logs spark-worker
```

## 📁 Struktur Direktori

```
demo/
├── docker-compose.yml          # Docker services configuration
├── start.sh                   # Startup script
├── run_spark.sh              # Spark job runner
├── monitor.sh                # Monitoring script
├── stop.sh                   # Stop script
├── README.md                 # Documentation
├── data/                     # Generated data
│   ├── consumer_stats.json   # Consumer statistics
│   └── checkpoints/          # Spark checkpoints
├── js-producer/              # JavaScript producer
│   ├── Dockerfile
│   ├── package.json
│   └── producer.js
├── js-consumer/              # JavaScript consumer  
│   ├── Dockerfile
│   ├── package.json
│   └── consumer.js
└── spark-apps/               # Spark applications
    └── spark_streaming_demo.py
```

## 💡 Use Cases

Demo ini cocok untuk:
- Learning Apache Kafka dan Spark Streaming
- Prototyping real-time analytics pipeline
- Understanding event-driven architecture
- Testing streaming data processing
- E-commerce analytics simulation

## 🔧 Customization

### Menambah Event Types
Edit `js-producer/producer.js`:
```javascript
const eventTypes = ['VIEW', 'PURCHASE', 'NEW_EVENT_TYPE'];
```

### Mengubah Analytics
Edit `spark-apps/spark_streaming_demo.py` untuk menambah:
- Custom aggregations
- New alert conditions
- Different time windows
- Additional metrics

### Scaling
Untuk production-like setup:
- Increase Kafka partitions
- Add more Spark workers
- Implement persistent storage
- Add monitoring tools (Prometheus/Grafana)

## 📚 Learning Resources

- [Apache Kafka Documentation](https://kafka.apache.org/documentation/)
- [Spark Structured Streaming Guide](https://spark.apache.org/docs/latest/structured-streaming-programming-guide.html)
- [KafkaJS Documentation](https://kafka.js.org/)

## 🤝 Contributing

Feel free to extend demo dengan:
- Additional data sources
- More complex analytics
- Dashboard visualization
- Machine learning integration
- Performance optimizations 