#!/usr/bin/env python3

from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *

def create_spark_session():
    """Create Spark session with Kafka support"""
    return SparkSession.builder \
        .appName("SimpleStreamingTest") \
        .config("spark.sql.streaming.schemaInference", "true") \
        .getOrCreate()

def main():
    print("🧪 Simple Streaming Test Started...")
    
    # Create Spark session
    spark = create_spark_session()
    spark.sparkContext.setLogLevel("WARN")
    
    print("📡 Connecting to Kafka...")
    
    # Read from Kafka
    kafka_df = spark \
        .readStream \
        .format("kafka") \
        .option("kafka.bootstrap.servers", "kafka:29092") \
        .option("subscribe", "sales_transactions") \
        .option("startingOffsets", "latest") \
        .option("maxOffsetsPerTrigger", 100) \
        .load()
    
    print("⚡ Starting simple query...")
    
    # Simple query - just show raw data
    query = kafka_df \
        .select(col("key").cast("string"), col("value").cast("string"), col("timestamp")) \
        .writeStream \
        .outputMode("append") \
        .format("console") \
        .option("truncate", "false") \
        .option("numRows", 5) \
        .trigger(processingTime="10 seconds") \
        .start()
    
    print("✅ Simple streaming query started successfully!")
    print("🔍 Monitoring Kafka messages...")
    
    # Wait for termination
    try:
        query.awaitTermination()
    except KeyboardInterrupt:
        print("\n🛑 Stopping streaming...")
        query.stop()
        print("✅ Query stopped successfully")

if __name__ == "__main__":
    main() 