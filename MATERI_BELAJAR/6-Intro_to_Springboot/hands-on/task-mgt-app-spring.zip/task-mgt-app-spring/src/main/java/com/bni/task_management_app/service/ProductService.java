package com.bni.task_management_app.service;

// src/main/java/com/example/demo/service/ProductService.java
import com.bni.task_management_app.model.Product;
import com.bni.task_management_app.repository.ProductRepository;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/********************** SERVICE LAYER ***********************/
// berisi semua logic
@Service            // => menandakan bahwa merupakan service layer 
public class ProductService {
    private final ProductRepository productRepository;

    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    public Product createProduct(Product product) {
        return productRepository.save(product);
    }

    public Optional<Product> getProductById(Long id) {
        return productRepository.findById(id);
    }

    public List<Product> getAllProducts() {
        return productRepository.findAll()
                .stream()
                .collect(Collectors.toList());
    }

    public boolean updateProduct(Product product) {
        return productRepository.update(product);
    }

    public boolean deleteProduct(Long id) {
        return productRepository.deleteById(id);
    }
}
/********************** END OF SERVICE LAYER ***********************/
