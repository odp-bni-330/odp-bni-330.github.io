# Log Generator Script for ELK Stack Demo - Windows Version
# Script ini akan menggenerate log secara kontinyu

Write-Host "🚀 Starting log generator..." -ForegroundColor Green
Write-Host "📁 Log directory: .\logs" -ForegroundColor Cyan
Write-Host "⏹️  Press Ctrl+C to stop" -ForegroundColor Yellow

# Arrays for sample data
$IPs = @("192.168.1.100", "10.0.0.50", "203.0.113.45", "172.16.0.25", "198.51.100.33", "127.0.0.1")

# Sample paths
$ApachePaths = @("/index.html", "/products.html", "/about.html", "/contact.html", "/search", "/api/login", "/dashboard", "/images/logo.png")
$NginxPaths = @("/api/v1/users", "/api/v1/orders", "/health", "/metrics", "/api/v1/products", "/webhook", "/api/v1/logs")

# HTTP methods and status codes
$Methods = @("GET", "POST", "PUT", "DELETE", "PATCH")
$StatusCodes = @("200", "201", "204", "302", "400", "404", "500")

# User agents
$UserAgents = @(
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
    "curl/7.68.0",
    "PostmanRuntime/7.28.4",
    "Prometheus/2.30.3"
)

# Log levels and messages
$LogLevels = @("INFO", "DEBUG", "WARN", "ERROR")
$LogMessages = @(
    "User authentication successful for user john.doe@example.com",
    "Database connection established successfully",
    "Cache hit for user profile data",
    "API request processed successfully in 125ms",
    "Background job email_notifications completed",
    "High memory usage detected: 85% of heap used",
    "Slow query detected: execution time 2.3s",
    "Rate limit approaching for endpoint /api/data",
    "Database deadlock detected, retrying transaction",
    "Payment processing completed for order #12345",
    "Session expired for user session_abc123",
    "File upload completed: document.pdf (2.3MB)",
    "Configuration reloaded successfully",
    "Health check passed: all systems operational",
    "Backup process started for database main_db"
)

# Functions to generate different types of logs
function Add-ApacheLog {
    $ip = $IPs | Get-Random
    $path = $ApachePaths | Get-Random
    $method = $Methods | Get-Random
    $status = $StatusCodes | Get-Random
    $size = Get-Random -Minimum 100 -Maximum 10000
    $userAgent = $UserAgents | Get-Random
    $timestamp = Get-Date -Format "dd/MMM/yyyy:HH:mm:ss zzz"
    
    $logEntry = "$ip - - [$timestamp] `"$method $path HTTP/1.1`" $status $size `"http://example.com/`" `"$userAgent`""
    
    try {
        Add-Content -Path "logs\apache\access.log" -Value $logEntry -Encoding UTF8
    } catch {
        Write-Warning "Failed to write Apache log: $_"
    }
}

function Add-NginxLog {
    $ip = $IPs | Get-Random
    $path = $NginxPaths | Get-Random
    $method = $Methods | Get-Random
    $status = $StatusCodes | Get-Random
    $size = Get-Random -Minimum 50 -Maximum 5000
    $userAgent = $UserAgents | Get-Random
    $timestamp = Get-Date -Format "dd/MMM/yyyy:HH:mm:ss zzz"
    
    $logEntry = "$ip - - [$timestamp] `"$method $path HTTP/1.1`" $status $size `"http://api.example.com/`" `"$userAgent`""
    
    try {
        Add-Content -Path "logs\nginx\access.log" -Value $logEntry -Encoding UTF8
    } catch {
        Write-Warning "Failed to write Nginx log: $_"
    }
}

function Add-ApplicationLog {
    $level = $LogLevels | Get-Random
    $message = $LogMessages | Get-Random
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss,fff"
    
    $logEntry = "[$timestamp] $level`: $message"
    
    try {
        Add-Content -Path "logs\application\app.log" -Value $logEntry -Encoding UTF8
    } catch {
        Write-Warning "Failed to write Application log: $_"
    }
}

# Ensure log directories exist
$logDirs = @("logs\apache", "logs\nginx", "logs\application")
foreach ($dir in $logDirs) {
    if (-not (Test-Path $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
        Write-Host "Created directory: $dir" -ForegroundColor Green
    }
}

# Ensure log files exist
$logFiles = @("logs\apache\access.log", "logs\nginx\access.log", "logs\application\app.log")
foreach ($file in $logFiles) {
    if (-not (Test-Path $file)) {
        New-Item -ItemType File -Path $file -Force | Out-Null
        Write-Host "Created file: $file" -ForegroundColor Green
    }
}

# Main generation loop
$counter = 0
Write-Host "Starting log generation..." -ForegroundColor Green

try {
    while ($true) {
        $counter++
        
        # Generate Apache log (33% chance)
        if ((Get-Random -Maximum 3) -eq 0) {
            Add-ApacheLog
            Write-Host "✅ Apache log generated (#$counter)" -ForegroundColor Green
        }
        
        # Generate Nginx log (25% chance)
        if ((Get-Random -Maximum 4) -eq 0) {
            Add-NginxLog
            Write-Host "✅ Nginx log generated (#$counter)" -ForegroundColor Blue
        }
        
        # Generate Application log (20% chance)
        if ((Get-Random -Maximum 5) -eq 0) {
            Add-ApplicationLog
            Write-Host "✅ Application log generated (#$counter)" -ForegroundColor Magenta
        }
        
        # Show status every 50 iterations
        if ($counter % 50 -eq 0) {
            Write-Host "📊 Generated $counter log entries so far..." -ForegroundColor Cyan
        }
        
        # Sleep between 2-5 seconds
        Start-Sleep -Seconds (Get-Random -Minimum 2 -Maximum 6)
    }
} catch [System.Management.Automation.PipelineStoppedException] {
    Write-Host "`n⏹️  Log generator stopped by user" -ForegroundColor Yellow
} catch {
    Write-Host "`n❌ Error in log generator: $_" -ForegroundColor Red
} finally {
    Write-Host "📊 Total log entries generated: $counter" -ForegroundColor Cyan
    Write-Host "👋 Log generator finished" -ForegroundColor Green
} 