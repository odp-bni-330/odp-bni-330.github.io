/*
 * Written by : Bostang Palaguna
 * Date : 2025-05-28
 * File : UserRepository.java
 * Deskripsi : 
 *   Interface repository untuk entitas User.
 *   Memanfaatkan Spring Data JPA untuk operasi CRUD otomatis
 *   serta menyediakan method kustom untuk mencari pengguna berdasarkan username.
 */

 package com.example.connect_oracle_db.repository; // Mendefinisikan paket untuk kelas ini

 // Import entitas User dan kelas pendukung dari Spring Data JPA
 import com.example.connect_oracle_db.entity.User;
 import org.springframework.data.jpa.repository.JpaRepository;
 
 import java.util.Optional;
 
 /**
  * Interface repository untuk entitas User.
  * JpaRepository memberikan implementasi otomatis untuk operasi CRUD (Create, Read, Update, Delete)
  * dan juga memungkinkan penambahan query-method kustom.
  */
 public interface UserRepository extends JpaRepository<User, String> {
 
     /**
      * Method kustom untuk mencari user berdasarkan username.
      * Spring Data JPA akan mengimplementasikan method ini secara otomatis
      * berdasarkan nama method.
      *
      * @param username nama pengguna
      * @return Optional<User> jika ditemukan, atau kosong jika tidak ada
      */
     Optional<User> findByUsername(String username);
 }
 