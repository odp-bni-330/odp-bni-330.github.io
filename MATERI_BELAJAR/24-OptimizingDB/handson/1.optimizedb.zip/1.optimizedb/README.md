# PostgreSQL Database dengan Docker Compose untuk Mac M2

Konfigurasi Docker Compose untuk menjalankan PostgreSQL pada Mac dengan chip Apple Silicon (M1/M2).

## Cara Menjalankan

1. Pastikan Docker Desktop untuk Mac sudah terinstal
2. Jalankan perintah berikut di terminal:

```bash
docker-compose up -d
```

3. Database akan langsung siap digunakan

## Informasi Koneksi

- **Hostname**: localhost
- **Port**: 5432
- **Database**: testdb
- **Username**: postgres
- **Password**: postgres

## Menghubungkan dengan SQL Client

```bash
docker exec -it postgres-db psql -U postgres -d testdb
```

## Keuntungan PostgreSQL pada Mac M2

- Dukungan native untuk arsitektur ARM64
- Performa optimal tanpa emulasi
- Standar SQL yang sangat ketat dan fitur advanced
- Open source dengan ekosistem yang kuat
- Mendukung JSON, arrays, dan tipe data advanced lainnya