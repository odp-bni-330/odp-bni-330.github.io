/*
 * Written by : Bostang Palaguna
 * Date : 2025-05-28
 * File : AuthController.java
 * Deskripsi : 
 *   Controller untuk menangani endpoint autentikasi pengguna.
 *   Menyediakan endpoint untuk proses register dan login,
 *   serta berkomunikasi dengan lapisan service (`AuthService`)
 *   untuk menangani logika bisnis autentikasi.
 */

 package com.example.connect_oracle_db.controller; // Menentukan lokasi paket

 // Import kelas-kelas yang diperlukan
 import com.example.connect_oracle_db.service.AuthService;
 import org.springframework.beans.factory.annotation.Autowired;
 import org.springframework.http.ResponseEntity;
 import org.springframework.web.bind.annotation.PostMapping;
 import org.springframework.web.bind.annotation.RequestBody;
 import org.springframework.web.bind.annotation.RequestMapping;
 import org.springframework.web.bind.annotation.RestController;
 
 import java.util.Map;
 
 @RestController // Menandai bahwa kelas ini adalah REST controller
 @RequestMapping("/api/auth") // Prefix URL untuk semua endpoint di controller ini
 public class AuthController {
 
     @Autowired // Menyisipkan dependensi dari AuthService secara otomatis
     private AuthService authService;
 
     /**
      * Endpoint untuk mendaftarkan pengguna baru.
      * Menerima JSON body dengan kunci "username" dan "password",
      * lalu meneruskan data tersebut ke AuthService untuk diproses.
      *
      * @param body Map berisi data permintaan (username dan password)
      * @return ResponseEntity dengan pesan hasil registrasi
      */
     @PostMapping("/register")
     public ResponseEntity<String> register(@RequestBody Map<String, String> body) {
         String username = body.get("username");
         String password = body.get("password");
 
         String message = authService.register(username, password); // Panggil service untuk proses registrasi
 
         return ResponseEntity.ok(message); // Kembalikan response sukses dengan pesan dari service
     }
 
     /**
      * Endpoint untuk login pengguna.
      * Menerima JSON body dengan kunci "username" dan "password",
      * lalu memverifikasi kredensial dengan AuthService.
      *
      * @param body Map berisi data permintaan (username dan password)
      * @return ResponseEntity dengan hasil login (sukses/gagal)
      */
     @PostMapping("/login")
     public ResponseEntity<String> login(@RequestBody Map<String, String> body) {
         String username = body.get("username");
         String password = body.get("password");
 
         boolean success = authService.login(username, password); // Verifikasi login melalui service
 
         // Response tergantung hasil login
         return ResponseEntity.ok(success ? "Login successful" : "Invalid credentials");
     }
 }
 