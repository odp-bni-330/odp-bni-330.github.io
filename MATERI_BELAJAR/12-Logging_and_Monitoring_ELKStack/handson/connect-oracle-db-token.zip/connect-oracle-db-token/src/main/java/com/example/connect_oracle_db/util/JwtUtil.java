/*
 * Written by : Bostang Palaguna
 * Date : 2025-06-02
 * File : JwtUtil.java
 * Deskripsi :
 *      Utility class untuk menangani operasi terkait JSON Web Token (JWT).
 *      Meliputi pembuatan token, ekstraksi klaim, dan validasi token.
 */
package com.example.connect_oracle_db.util;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Component;

import java.security.Key;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Komponen utility untuk operasi JWT.
 * Menggunakan algoritma HS256 untuk signing dan memiliki masa berlaku 1 jam.
 */
@Component
public class JwtUtil {
    // Secret key untuk signing JWT, di-generate secara otomatis
    private final Key key = Keys.secretKeyFor(SignatureAlgorithm.HS256);

    // Masa berlaku token dalam milidetik (1 jam)
    private final long expirationMs = 3600000;

    /**
     * Membuat JWT token untuk user tertentu.
     * 
     * @param username Username yang akan dimasukkan sebagai subject
     * @param role     Role user yang akan dimasukkan sebagai claim
     * @return String JWT token yang sudah di-sign
     */
    public String generateToken(String username, String role) {
        // Menyiapkan claims tambahan (role)
        Map<String, Object> claims = new HashMap<>();
        claims.put("role", role);

        // Membangun token JWT dengan:
        // - Claims (role)
        // - Subject (username)
        // - Waktu pembuatan
        // - Waktu kadaluarsa
        // - Signature menggunakan secret key
        return Jwts.builder()
                .setClaims(claims)
                .setSubject(username)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + expirationMs))
                .signWith(key)
                .compact();
    }

    /**
     * Mengekstrak username dari JWT token.
     * 
     * @param token JWT token
     * @return Username yang ada dalam subject token
     * @throws io.jsonwebtoken.JwtException Jika token tidak valid
     */
    public String getUsernameFromToken(String token) {
        return Jwts.parserBuilder()
                .setSigningKey(key)
                .build()
                .parseClaimsJws(token)
                .getBody()
                .getSubject();
    }

    /**
     * Mengekstrak role dari JWT token.
     * 
     * @param token JWT token
     * @return Role user yang ada dalam claims token
     * @throws io.jsonwebtoken.JwtException Jika token tidak valid
     */
    public String getRoleFromToken(String token) {
        return (String) Jwts.parserBuilder()
                .setSigningKey(key)
                .build()
                .parseClaimsJws(token)
                .getBody()
                .get("role");
    }

    /**
     * Memvalidasi JWT token.
     * 
     * @param token JWT token yang akan divalidasi
     * @return true jika token valid (signature benar dan belum kadaluarsa),
     *         false jika token tidak valid
     */
    public boolean validateToken(String token) {
        try {
            // Mencoba parse token, jika berhasil maka token valid
            Jwts.parserBuilder()
                    .setSigningKey(key)
                    .build()
                    .parseClaimsJws(token);
            return true;
        } catch (Exception e) {
            // Jika terjadi exception, token tidak valid
            return false;
        }
    }
}