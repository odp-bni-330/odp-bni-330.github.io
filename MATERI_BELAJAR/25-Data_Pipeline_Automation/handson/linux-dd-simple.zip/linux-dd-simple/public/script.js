// Global variables
let charts = {};
let currentTab = 'overview';

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    checkHealth();
    loadOverviewData();
    setInterval(checkHealth, 30000); // Check health every 30 seconds
});

// Tab switching functionality
function showTab(tabName) {
    // Hide all tabs
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Remove active class from all buttons
    document.querySelectorAll('.tab-button').forEach(btn => {
        btn.classList.remove('active');
    });
    
    // Show selected tab
    document.getElementById(tabName).classList.add('active');
    event.target.classList.add('active');
    
    currentTab = tabName;
    
    // Load data for the selected tab
    switch(tabName) {
        case 'postgresql':
            loadPostgreSQLData();
            break;
        case 'mongodb':
            loadMongoDBData();
            break;
        case 'combined':
            loadCombinedData();
            break;
        case 'overview':
            loadOverviewData();
            break;
    }
}

// Health check function
async function checkHealth() {
    try {
        const response = await fetch('/api/health');
        const health = await response.json();
        
        const pgStatus = document.getElementById('pgStatus');
        const mongoStatus = document.getElementById('mongoStatus');
        
        // Update PostgreSQL status
        pgStatus.textContent = health.services.postgresql;
        pgStatus.className = `status-${health.services.postgresql}`;
        
        // Update MongoDB status
        mongoStatus.textContent = health.services.mongodb;
        mongoStatus.className = `status-${health.services.mongodb}`;
        
    } catch (error) {
        console.error('Health check failed:', error);
        document.getElementById('pgStatus').textContent = 'Error';
        document.getElementById('mongoStatus').textContent = 'Error';
    }
}

// Overview data loading
async function loadOverviewData() {
    try {
        // Create a simple overview chart showing system status
        const ctx = document.getElementById('overviewChart').getContext('2d');
        
        if (charts.overview) {
            charts.overview.destroy();
        }
        
        charts.overview = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['PostgreSQL Active', 'MongoDB Active', 'Data Sources'],
                datasets: [{
                    data: [1, 1, 2],
                    backgroundColor: [
                        '#667eea',
                        '#764ba2',
                        '#38a169'
                    ],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            font: {
                                size: 14
                            }
                        }
                    },
                    title: {
                        display: true,
                        text: 'System Overview',
                        font: {
                            size: 16,
                            weight: 'bold'
                        }
                    }
                }
            }
        });
    } catch (error) {
        console.error('Error loading overview data:', error);
    }
}

// PostgreSQL data loading
async function loadPostgreSQLData() {
    try {
        // Load sales data
        const salesResponse = await fetch('/api/postgres/sales');
        const salesData = await salesResponse.json();
        
        // Load monthly sales data
        const monthlyResponse = await fetch('/api/postgres/monthly-sales');
        const monthlyData = await monthlyResponse.json();
        
        // Create sales chart
        createSalesChart(salesData);
        createMonthlySalesChart(monthlyData);
        
        // Display data table
        displayPostgreSQLTable(salesData);
        
    } catch (error) {
        console.error('Error loading PostgreSQL data:', error);
        showError('postgresql', 'Failed to load PostgreSQL data');
    }
}

// MongoDB data loading
async function loadMongoDBData() {
    try {
        // Load customers data
        const customersResponse = await fetch('/api/mongodb/customers');
        const customersData = await customersResponse.json();
        
        // Load interactions data
        const interactionsResponse = await fetch('/api/mongodb/interactions');
        const interactionsData = await interactionsResponse.json();
        
        // Create charts
        createCustomersChart(customersData);
        createInteractionsChart(interactionsData);
        
        // Display data table
        displayMongoDBTable(customersData, interactionsData);
        
    } catch (error) {
        console.error('Error loading MongoDB data:', error);
        showError('mongodb', 'Failed to load MongoDB data');
    }
}

// Combined data loading
async function loadCombinedData() {
    try {
        const response = await fetch('/api/combined/dashboard');
        const data = await response.json();
        
        // Create combined charts
        createCombinedProductsChart(data.topProducts);
        createCombinedInteractionsChart(data.customerInteractions);
        
        // Generate insights
        generateInsights(data);
        
    } catch (error) {
        console.error('Error loading combined data:', error);
        showError('combined', 'Failed to load combined data');
    }
}

// Chart creation functions
function createSalesChart(data) {
    const ctx = document.getElementById('salesChart').getContext('2d');
    
    if (charts.sales) {
        charts.sales.destroy();
    }
    
    charts.sales = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: data.map(item => item.product_name.substring(0, 20) + '...'),
            datasets: [{
                label: 'Total Sales (Rp)',
                data: data.map(item => parseFloat(item.total_sales)),
                backgroundColor: 'rgba(102, 126, 234, 0.8)',
                borderColor: 'rgba(102, 126, 234, 1)',
                borderWidth: 2,
                borderRadius: 8
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return 'Rp ' + (value / 1000000).toFixed(1) + 'M';
                        }
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return 'Total Sales: Rp ' + context.parsed.y.toLocaleString('id-ID');
                        }
                    }
                }
            }
        }
    });
}

function createMonthlySalesChart(data) {
    const ctx = document.getElementById('monthlySalesChart').getContext('2d');
    
    if (charts.monthly) {
        charts.monthly.destroy();
    }
    
    charts.monthly = new Chart(ctx, {
        type: 'line',
        data: {
            labels: data.map(item => item.month),
            datasets: [{
                label: 'Monthly Sales',
                data: data.map(item => parseFloat(item.total_amount)),
                borderColor: 'rgba(118, 75, 162, 1)',
                backgroundColor: 'rgba(118, 75, 162, 0.1)',
                borderWidth: 3,
                fill: true,
                tension: 0.4,
                pointBackgroundColor: 'rgba(118, 75, 162, 1)',
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return 'Rp ' + (value / 1000000).toFixed(0) + 'M';
                        }
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return 'Sales: Rp ' + context.parsed.y.toLocaleString('id-ID');
                        }
                    }
                }
            }
        }
    });
}

function createCustomersChart(data) {
    const ctx = document.getElementById('customersChart').getContext('2d');
    
    if (charts.customers) {
        charts.customers.destroy();
    }
    
    charts.customers = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: data.map(item => item._id),
            datasets: [{
                data: data.map(item => item.total_customers),
                backgroundColor: [
                    '#667eea',
                    '#764ba2',
                    '#38a169',
                    '#e53e3e',
                    '#dd6b20'
                ],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        padding: 20
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = ((context.parsed / total) * 100).toFixed(1);
                            return context.label + ': ' + context.parsed + ' (' + percentage + '%)';
                        }
                    }
                }
            }
        }
    });
}

function createInteractionsChart(data) {
    const ctx = document.getElementById('interactionsChart').getContext('2d');
    
    if (charts.interactions) {
        charts.interactions.destroy();
    }
    
    charts.interactions = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: data.map(item => item._id.replace('_', ' ').toUpperCase()),
            datasets: [{
                data: data.map(item => item.count),
                backgroundColor: [
                    '#667eea',
                    '#764ba2',
                    '#38a169',
                    '#e53e3e',
                    '#dd6b20',
                    '#3182ce'
                ],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        padding: 15
                    }
                }
            }
        }
    });
}

function createCombinedProductsChart(data) {
    const ctx = document.getElementById('combinedProductsChart').getContext('2d');
    
    if (charts.combinedProducts) {
        charts.combinedProducts.destroy();
    }
    
    charts.combinedProducts = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: data.map(item => item.product_name.substring(0, 15) + '...'),
            datasets: [{
                label: 'Quantity Sold',
                data: data.map(item => parseInt(item.total_quantity)),
                backgroundColor: 'rgba(102, 126, 234, 0.8)',
                borderColor: 'rgba(102, 126, 234, 1)',
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            indexAxis: 'y',
            scales: {
                x: {
                    beginAtZero: true
                }
            },
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });
}

function createCombinedInteractionsChart(data) {
    const ctx = document.getElementById('combinedInteractionsChart').getContext('2d');
    
    if (charts.combinedInteractions) {
        charts.combinedInteractions.destroy();
    }
    
    charts.combinedInteractions = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: data.map(item => item._id.replace('_', ' ')),
            datasets: [{
                label: 'Interactions',
                data: data.map(item => item.count),
                backgroundColor: 'rgba(118, 75, 162, 0.8)',
                borderColor: 'rgba(118, 75, 162, 1)',
                borderWidth: 2,
                borderRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true
                }
            },
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });
}

// Table display functions
function displayPostgreSQLTable(data) {
    const container = document.getElementById('postgresqlData');
    
    if (data.length === 0) {
        container.innerHTML = '<div class="message info">No data available</div>';
        return;
    }
    
    let html = `
        <table>
            <thead>
                <tr>
                    <th>Product Name</th>
                    <th>Total Quantity</th>
                    <th>Total Sales</th>
                </tr>
            </thead>
            <tbody>
    `;
    
    data.forEach(item => {
        html += `
            <tr>
                <td>${item.product_name}</td>
                <td>${item.total_quantity}</td>
                <td>Rp ${parseFloat(item.total_sales).toLocaleString('id-ID')}</td>
            </tr>
        `;
    });
    
    html += '</tbody></table>';
    container.innerHTML = html;
}

function displayMongoDBTable(customers, interactions) {
    const container = document.getElementById('mongodbData');
    
    let html = `
        <h4>Customer Distribution by City</h4>
        <table>
            <thead>
                <tr>
                    <th>City</th>
                    <th>Total Customers</th>
                    <th>Average Age</th>
                </tr>
            </thead>
            <tbody>
    `;
    
    customers.forEach(item => {
        html += `
            <tr>
                <td>${item._id}</td>
                <td>${item.total_customers}</td>
                <td>${item.avg_age ? item.avg_age.toFixed(1) : 'N/A'}</td>
            </tr>
        `;
    });
    
    html += '</tbody></table>';
    
    html += `
        <h4 style="margin-top: 30px;">Customer Interactions</h4>
        <table>
            <thead>
                <tr>
                    <th>Interaction Type</th>
                    <th>Count</th>
                </tr>
            </thead>
            <tbody>
    `;
    
    interactions.forEach(item => {
        html += `
            <tr>
                <td>${item._id.replace('_', ' ').toUpperCase()}</td>
                <td>${item.count}</td>
            </tr>
        `;
    });
    
    html += '</tbody></table>';
    container.innerHTML = html;
}

// Insights generation
function generateInsights(data) {
    const container = document.getElementById('insights');
    
    let insights = [];
    
    // Analyze top products
    if (data.topProducts && data.topProducts.length > 0) {
        const topProduct = data.topProducts[0];
        insights.push({
            icon: 'fas fa-star',
            title: 'Best Selling Product',
            description: `${topProduct.product_name} is the top-selling product with ${topProduct.total_quantity} units sold.`
        });
    }
    
    // Analyze interactions
    if (data.customerInteractions && data.customerInteractions.length > 0) {
        const totalInteractions = data.customerInteractions.reduce((sum, item) => sum + item.count, 0);
        const topInteraction = data.customerInteractions[0];
        insights.push({
            icon: 'fas fa-users',
            title: 'Customer Engagement',
            description: `Total ${totalInteractions} customer interactions recorded. ${topInteraction._id.replace('_', ' ')} is the most common interaction type with ${topInteraction.count} occurrences.`
        });
    }
    
    // Data integration insight
    insights.push({
        icon: 'fas fa-database',
        title: 'Multi-Source Integration',
        description: 'Successfully integrated structured data from PostgreSQL (sales transactions) with unstructured data from MongoDB (customer interactions) for comprehensive business analytics.'
    });
    
    // Generate HTML
    let html = '';
    insights.forEach(insight => {
        html += `
            <div class="insight-item">
                <h4><i class="${insight.icon}"></i> ${insight.title}</h4>
                <p>${insight.description}</p>
            </div>
        `;
    });
    
    container.innerHTML = html;
}

// Error handling
function showError(section, message) {
    const containers = {
        'postgresql': 'postgresqlData',
        'mongodb': 'mongodbData',
        'combined': 'insights'
    };
    
    const container = document.getElementById(containers[section]);
    if (container) {
        container.innerHTML = `<div class="message error">${message}</div>`;
    }
}

// Format currency
function formatCurrency(amount) {
    return new Intl.NumberFormat('id-ID', {
        style: 'currency',
        currency: 'IDR',
        minimumFractionDigits: 0
    }).format(amount);
}

// Auto refresh data every 5 minutes
setInterval(() => {
    if (currentTab === 'postgresql') {
        loadPostgreSQLData();
    } else if (currentTab === 'mongodb') {
        loadMongoDBData();
    } else if (currentTab === 'combined') {
        loadCombinedData();
    }
}, 300000); 