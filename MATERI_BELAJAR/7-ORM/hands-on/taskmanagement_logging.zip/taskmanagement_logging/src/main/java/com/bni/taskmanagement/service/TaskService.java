package com.bni.taskmanagement.service;

import java.util.List;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.stereotype.Service;

import com.bni.taskmanagement.model.Task;
import com.bni.taskmanagement.repository.TaskRepository;

/*************************** LAYER SERVICE ***************************/
// tempat semua business logic

@Service
public class TaskService {

    private static final Logger logger = LoggerFactory.getLogger(TaskService.class);

    // mengkoneksikan layer service ke layer repository
    private final TaskRepository taskRepository;
    // private : access modifier, meaning the field can only be accessed within the same class.
    // final : field cannot be reassigned after it is initialized

    // constructor
    public TaskService(TaskRepository taskRepository){
        this.taskRepository = taskRepository;
    }

    // method untuk membuat sebuah Object:task
    public Task createTask(Task task){
        logger.info("Save data success for title: {}", task.getTitle());  // Replaces `{}` with the ID
        return taskRepository.save(task);
    }

    // method untuk mengembalikan semua task dalam bentuk List of Object:Task
    public List<Task> getAllTasks(){
        // karena yang di-return ada banyak Task, maka mengembalikan List of Task

        logger.info("Fetching all tasks");

        return taskRepository.findAll();
    }
}

/*************************** END OF LAYER SERVICE ***************************/