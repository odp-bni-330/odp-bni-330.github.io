-- Membuat tabel products jika belum ada
CREATE TABLE products (
    product_id INT PRIMARY KEY,
    product_name VARCHAR(255),
    category VARCHAR(50),
    price DECIMAL(10, 2)
);

-- Membuat tabel orders jika belum ada
CREATE TABLE orders (
    order_id INT PRIMARY KEY,
    customer_id INT,
    order_date DATE
);

-- Membuat tabel order_items jika belum ada
CREATE TABLE order_items (
    order_item_id INT PRIMARY KEY,
    order_id INT,
    product_id INT,
    quantity INT,
    unit_price DECIMAL(10, 2),
    FOREIGN KEY (order_id) REFERENCES orders(order_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

-- Menyisipkan data sampel
INSERT INTO products (product_id, product_name, category, price) VALUES
(1, 'Smartphone A', 'Electronics', 1500000.00),
(2, 'Smartphone B', 'Electronics', 1200000.00),
(3, 'Laptop X', 'Electronics', 5000000.00);

INSERT INTO orders (order_id, customer_id, order_date) VALUES
(101, 1, TO_DATE('2025-03-01', 'YYYY-MM-DD')),
(102, 1, TO_DATE('2025-04-15', 'YYYY-MM-DD')),
(103, 2, TO_DATE('2025-05-10', 'YYYY-MM-DD'));

INSERT INTO order_items (order_item_id, order_id, product_id, quantity, unit_price) VALUES
(1, 101, 1, 3, 1500000.00),
(2, 101, 2, 5, 1200000.00),
(3, 102, 1, 2, 1500000.00),
(4, 103, 3, 1, 5000000.00);

COMMIT;

-- Query 1: Urutan join dimulai dari products
SELECT   
    p.product_name,  
    o.order_date,  
    oi.quantity,  
    oi.unit_price
FROM   
    products p
INNER JOIN 
    order_items oi ON oi.product_id = p.product_id
INNER JOIN 
    orders o ON o.order_id = oi.order_id
WHERE   
    o.order_date BETWEEN TO_DATE('2025-01-01', 'YYYY-MM-DD') AND TO_DATE('2025-06-30', 'YYYY-MM-DD')
    AND p.price > 1000000
ORDER BY   
    o.order_date DESC
FETCH FIRST 20 ROWS ONLY;