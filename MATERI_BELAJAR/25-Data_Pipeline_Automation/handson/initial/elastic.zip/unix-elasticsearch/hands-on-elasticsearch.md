# Hands-on: Query Elasticsearch with Kibana

This guide will walk you through setting up Elasticsearch and Kibana using Docker, and performing basic queries.

## Prerequisites
- Docker and Docker Compose installed
- Basic understanding of REST APIs

## Setup

1. Start the Elasticsearch and Kibana containers:
```bash
docker-compose up -d
```

2. Wait for the services to start (this may take a minute or two)

3. Verify Elasticsearch is running:
```bash
curl http://localhost:9200
```

4. Access Kibana at http://localhost:5601 in your browser

## Exercise 1: Index Sample Data

Let's create an index and add some sample data:

```bash
# Create an index called "products"
curl -X PUT "localhost:9200/products"

# Add a document to the index
curl -X POST "localhost:9200/products/_doc" -H "Content-Type: application/json" -d'
{
  "name": "Laptop",
  "price": 999.99,
  "in_stock": 10,
  "category": "electronics",
  "tags": ["computer", "work", "portable"]
}'

# Add more documents
curl -X POST "localhost:9200/products/_doc" -H "Content-Type: application/json" -d'
{
  "name": "Smartphone",
  "price": 699.99,
  "in_stock": 15,
  "category": "electronics",
  "tags": ["mobile", "communication"]
}'

curl -X POST "localhost:9200/products/_doc" -H "Content-Type: application/json" -d'
{
  "name": "Headphones",
  "price": 149.99,
  "in_stock": 8,
  "category": "electronics",
  "tags": ["audio", "music", "wireless"]
}'

curl -X POST "localhost:9200/products/_doc" -H "Content-Type: application/json" -d'
{
  "name": "Coffee Maker",
  "price": 89.99,
  "in_stock": 5,
  "category": "kitchen",
  "tags": ["appliance", "morning", "beverage"]
}'

curl -X POST "localhost:9200/products/_doc" -H "Content-Type: application/json" -d'
{
  "name": "Blender",
  "price": 49.99,
  "in_stock": 12,
  "category": "kitchen",
  "tags": ["appliance", "cooking"]
}'
```

## Exercise 2: Basic Queries with REST API

### Search all documents
```bash
curl -X GET "localhost:9200/products/_search" -H "Content-Type: application/json" -d'
{
  "query": {
    "match_all": {}
  }
}'
```

### Search by exact field value
```bash
curl -X GET "localhost:9200/products/_search" -H "Content-Type: application/json" -d'
{
  "query": {
    "match": {
      "category": "electronics"
    }
  }
}'
```

### Range query for price
```bash
curl -X GET "localhost:9200/products/_search" -H "Content-Type: application/json" -d'
{
  "query": {
    "range": {
      "price": {
        "gte": 100,
        "lte": 800
      }
    }
  }
}'
```

### Boolean query (AND condition)
```bash
curl -X GET "localhost:9200/products/_search" -H "Content-Type: application/json" -d'
{
  "query": {
    "bool": {
      "must": [
        { "match": { "category": "electronics" } },
        { "range": { "price": { "lt": 700 } } }
      ]
    }
  }
}'
```

## Exercise 3: Using Kibana

1. Open Kibana at http://localhost:5601
2. Navigate to Dev Tools (from the left menu)
3. Try the following queries in the Console:

```
# Get all indices
GET _cat/indices?v

# Search all products
GET products/_search
{
  "query": {
    "match_all": {}
  }
}

# Search with a specific term
GET products/_search
{
  "query": {
    "match": {
      "name": "Laptop"
    }
  }
}

# Search with a wildcard
GET products/_search
{
  "query": {
    "wildcard": {
      "name": "*phone*"
    }
  }
}

# Aggregation - average price by category
GET products/_search
{
  "size": 0,
  "aggs": {
    "avg_price_by_category": {
      "terms": {
        "field": "category.keyword"
      },
      "aggs": {
        "avg_price": {
          "avg": {
            "field": "price"
          }
        }
      }
    }
  }
}
```

## Exercise 4: Create a Kibana Dashboard

1. Go to Stack Management > Index Patterns
2. Create an index pattern for "products*"
3. Go to Visualize and create visualizations:
   - Pie chart of products by category
   - Bar chart of product prices
   - Data table showing all products
4. Create a dashboard and add your visualizations

## Clean Up

When you're done, stop and remove the containers:
```bash
docker-compose down
```

To remove the volumes as well:
```bash
docker-compose down -v
```