const { Pool } = require("pg");
const { faker } = require("@faker-js/faker");

const pool = new Pool({
  user: "postgres",
  host: "localhost",
  database: "newbank",
  password: "Ishlah123",
  port: 5432,
});

async function insertUsersBatch(batchSize = 500, total = 5000) {
  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    for (let i = 0; i < total; i += batchSize) {
      const values = [];

      for (let j = 0; j < batchSize && i + j < total; j++) {
        const fullName = faker.person.fullName().replace(/'/g, "''"); // escape single quotes
        const dateOfBirth = faker.date
          .birthdate({ min: 23, max: 38, mode: "age" })
          .toISOString()
          .split("T")[0];
        const address = faker.location.city().replace(/'/g, "''");
        const email = `user${i + j}@example.com`;
        const phoneNumber = "08" + faker.string.numeric(10); // aman: total 12 digit

        values.push(
          `('${fullName}', '${dateOfBirth}', '${address}', '${email}', '${phoneNumber}')`
        );
      }

      const insertQuery = `
        INSERT INTO users (full_name, date_of_birth, address, email, phone_number)
        VALUES ${values.join(", ")};
      `;

      await client.query(insertQuery);
      console.log(
        `✅ Inserted batch: ${i + 1}–${Math.min(i + batchSize, total)}`
      );
    }

    await client.query("COMMIT");
    console.log("🎉 Semua 5000 users berhasil dimasukkan.");
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("❌ Error:", err.message);
  } finally {
    client.release();
  }
}

insertUsersBatch();
