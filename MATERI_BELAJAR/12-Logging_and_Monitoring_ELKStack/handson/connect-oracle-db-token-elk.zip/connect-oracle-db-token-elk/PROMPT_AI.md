# Menghubungkan Spring Boot Application ke ELK Stack

Untuk menghubungkan aplikasi Spring Boot Anda yang sudah ada (dengan fitur register/login) ke ELK Stack (Elasticsearch, Logstash, Kibana), berikut langkah-langkah yang perlu Anda lakukan:

## 1. Prasyarat
- Pastikan Anda sudah memiliki ELK Stack yang berjalan (bisa di localhost atau server terpisah)
- Aplikasi Spring Boot Anda sudah menggunakan logging framework (biasanya SLF4J dengan Logback)

## 2. Tambahkan Dependencies ke `pom.xml`

```xml
<!-- Logstash Logback Encoder -->
<dependency>
    <groupId>net.logstash.logback</groupId>
    <artifactId>logstash-logback-encoder</artifactId>
    <version>7.4</version>
</dependency>
```

## 3. Konfigurasi Logback

Buat/ubah file `logback-spring.xml` di `src/main/resources`:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<configuration>
    <include resource="org/springframework/boot/logging/logback/defaults.xml"/>
    
    <springProperty scope="context" name="appName" source="spring.application.name"/>
    
    <!-- Console Appender -->
    <appender name="CONSOLE" class="ch.qos.logback.core.ConsoleAppender">
        <encoder>
            <pattern>%d{yyyy-MM-dd HH:mm:ss} [%thread] %-5level %logger{36} - %msg%n</pattern>
        </encoder>
    </appender>
    
    <!-- Logstash Appender -->
    <appender name="LOGSTASH" class="net.logstash.logback.appender.LogstashTcpSocketAppender">
        <destination>localhost:5000</destination> <!-- Ganti dengan alamat Logstash Anda -->
        <encoder class="net.logstash.logback.encoder.LogstashEncoder">
            <customFields>{"appname":"${appName}", "environment":"development"}</customFields>
        </encoder>
    </appender>
    
    <root level="INFO">
        <appender-ref ref="CONSOLE"/>
        <appender-ref ref="LOGSTASH"/>
    </root>
    
    <!-- Log SQL queries -->
    <logger name="org.hibernate.SQL" level="DEBUG"/>
    <logger name="org.hibernate.type.descriptor.sql.BasicBinder" level="TRACE"/>
</configuration>
```

## 4. Konfigurasi Logstash

Buat file konfigurasi Logstash (misalnya `springboot.conf`):

```conf
input {
  tcp {
    port => 5000
    codec => json_lines
  }
}

filter {
  # Anda bisa menambahkan filter khusus di sini
  # Misalnya untuk login/register events
  if [message] =~ "LOGIN_ATTEMPT" {
    grok {
      match => { "message" => "LOGIN_ATTEMPT for user %{USERNAME:username} with status %{WORD:status}" }
    }
  }
  
  if [message] =~ "REGISTER_ATTEMPT" {
    grok {
      match => { "message" => "REGISTER_ATTEMPT for user %{USERNAME:username} with email %{EMAILADDRESS:email}" }
    }
  }
}

output {
  elasticsearch {
    hosts => ["localhost:9200"] # Ganti dengan alamat Elasticsearch Anda
    index => "springboot-%{+YYYY.MM.dd}"
  }
  
  # Untuk debugging (opsional)
  stdout {
    codec => rubydebug
  }
}
```

## 5. Modifikasi Kode untuk Logging Khusus

Tambahkan logging khusus untuk fitur register dan login di controller/service Anda:

```java
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    
    private static final Logger logger = LoggerFactory.getLogger(AuthController.class);
    
    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@RequestBody RegisterRequest request) {
        try {
            // Proses registrasi
            logger.info("REGISTER_ATTEMPT for user {} with email {}", request.getUsername(), request.getEmail());
            // ... kode registrasi ...
            return ResponseEntity.ok("User registered successfully");
        } catch (Exception e) {
            logger.error("REGISTER_FAILED for user {}: {}", request.getUsername(), e.getMessage());
            return ResponseEntity.badRequest().body("Registration failed");
        }
    }
    
    @PostMapping("/login")
    public ResponseEntity<?> authenticateUser(@RequestBody LoginRequest request) {
        try {
            // Proses login
            logger.info("LOGIN_ATTEMPT for user {}", request.getUsername());
            // ... kode login ...
            if (authenticated) {
                logger.info("LOGIN_SUCCESS for user {}", request.getUsername());
                return ResponseEntity.ok(jwtToken);
            } else {
                logger.warn("LOGIN_FAILED for user {}", request.getUsername());
                return ResponseEntity.badRequest().body("Invalid credentials");
            }
        } catch (Exception e) {
            logger.error("LOGIN_ERROR for user {}: {}", request.getUsername(), e.getMessage());
            return ResponseEntity.badRequest().body("Login failed");
        }
    }
}
```

## 6. Konfigurasi Spring Boot Application

Tambahkan properti berikut di `application.properties` atau `application.yml`:

```properties
# Nama aplikasi untuk logging
spring.application.name=your-application-name

# Untuk logging SQL queries (opsional)
logging.level.org.hibernate.SQL=DEBUG
logging.level.org.hibernate.type.descriptor.sql.BasicBinder=TRACE
```

## 7. Menjalankan Sistem

1. Jalankan Elasticsearch dan Kibana
2. Jalankan Logstash dengan konfigurasi yang telah dibuat: `bin/logstash -f springboot.conf`
3. Jalankan aplikasi Spring Boot Anda

## 8. Membuat Dashboard di Kibana

1. Buka Kibana di browser (biasanya http://localhost:5601)
2. Buat index pattern `springboot-*`
3. Buat visualisasi dan dashboard untuk memantau:
   - Jumlah percobaan login/register
   - Error rate
   - User activity
   - dll.

## Tips Tambahan

1. Untuk environment production, pertimbangkan untuk:
   - Menggunakan credentials untuk koneksi ke Elasticsearch
   - Mengenkripsi komunikasi antara aplikasi dan Logstash
   - Menggunakan Filebeat sebagai alternatif pengiriman log

2. Anda bisa menambahkan lebih banyak field khusus di log untuk kebutuhan analisis:
   ```java
   logger.info("LOGIN_ATTEMPT", Map.of(
       "username", request.getUsername(),
       "ip", request.getRemoteAddr(),
       "userAgent", request.getHeader("User-Agent")
   ));
   ```

3. Untuk performa lebih baik, pertimbangkan menggunakan asynchronous logging dengan menambahkan `AsyncAppender` di logback.