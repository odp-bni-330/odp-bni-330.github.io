-- Membuat Tabel products
CREATE TABLE products (
    product_id INT PRIMARY KEY,
    product_name VARCHAR(255),
    category VARCHAR(50),
    price DECIMAL(10, 2)
);

-- Membuat Tabel order_items
CREATE TABLE order_items (
    order_item_id INT PRIMARY KEY,
    order_id INT,
    product_id INT,
    quantity INT,
    unit_price DECIMAL(10, 2),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

-- Membuat Tabel inventory
CREATE TABLE inventory (
    inventory_id INT PRIMARY KEY,
    product_id INT,
    quantity INT,
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

-- Menyisipkan data ke dalam tabel products
INSERT INTO products (product_id, product_name, category, price) VALUES
(1, 'Smartphone A', 'Electronics', 1500000.00),
(2, 'Smartphone B', 'Electronics', 1200000.00),
(3, 'Laptop X', 'Electronics', 5000000.00),
(4, 'Headphones Y', 'Electronics', 700000.00),
(5, 'Smartwatch Z', 'Electronics', 2000000.00),
(6, 'Smartphone C', 'Electronics', 2500000.00),
(7, 'Tablet M', 'Electronics', 1800000.00);

-- Menyisipkan data ke dalam tabel order_items
INSERT INTO order_items (order_item_id, order_id, product_id, quantity, unit_price) VALUES
(1, 101, 1, 3, 1500000.00),
(2, 101, 2, 5, 1200000.00),
(3, 102, 1, 2, 1500000.00),
(4, 103, 3, 1, 5000000.00),
(5, 104, 1, 4, 1500000.00),
(6, 104, 2, 3, 1200000.00),
(7, 105, 5, 2, 2000000.00),
(8, 106, 6, 3, 2500000.00),
(9, 107, 7, 6, 1800000.00);

-- Menyisipkan data ke dalam tabel inventory
INSERT INTO inventory (inventory_id, product_id, quantity) VALUES
(1, 1, 50),
(2, 2, 30),
(3, 3, 20),
(4, 4, 100),
(5, 5, 40),
(6, 6, 60),
(7, 7, 80);

COMMIT;

-- Query untuk mendapatkan nama produk, harga, harga rata-rata yang dijual, jumlah pesanan, dan jumlah stok
SELECT   
    p.product_name,  
    p.price,  
    (SELECT AVG(unit_price) FROM order_items WHERE product_id = p.product_id) AS avg_sold_price,  
    (SELECT COUNT(*) FROM order_items WHERE product_id = p.product_id) AS times_ordered,  
    (SELECT SUM(quantity) FROM inventory WHERE product_id = p.product_id) AS stock_level
FROM   
    products p
WHERE   
    p.category = 'Electronics'  
    AND p.price > 1000000
ORDER BY   
    times_ordered DESC
FETCH FIRST 20 ROWS ONLY;

-- Jalankan query dengan JOIN
SELECT   
    p.product_name,  
    p.price,  
    AVG(oi.unit_price) AS avg_sold_price,  
    COUNT(oi.order_item_id) AS times_ordered,  
    MAX(i.quantity) AS stock_level
FROM   
    products p
LEFT JOIN 
    order_items oi ON oi.product_id = p.product_id
LEFT JOIN 
    inventory i ON i.product_id = p.product_id
WHERE   
    p.category = 'Electronics'  
    AND p.price > 1000000
GROUP BY   
    p.product_id, p.product_name, p.price
ORDER BY   
    times_ordered DESC
FETCH FIRST 20 ROWS ONLY;