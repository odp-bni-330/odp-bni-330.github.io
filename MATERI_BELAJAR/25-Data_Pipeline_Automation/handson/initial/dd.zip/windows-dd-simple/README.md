# Demo Multi-Source Data Visualization (Windows Version)

Demo ini mendemonstrasikan cara mengambil data dari PostgreSQL (Neon Cloud) dan MongoDB (Atlas Cloud), kemudian memvisualisasikannya menggunakan JavaScript dengan Chart.js dalam aplikasi web yang responsif. Versi ini dioptimalkan untuk Windows dengan script PowerShell dan Batch.

## 🌟 Fitur Utama

- **Multi-Source Data Integration**: Mengintegrasikan data terstruktur dari PostgreSQL (Neon Cloud) dan data semi-terstruktur dari MongoDB (Atlas Cloud)
- **Real-time Visualization**: Dashboard interaktif dengan berbagai jenis chart menggunakan Chart.js
- **Responsive Design**: Antarmuka yang responsif dan modern dengan CSS Flexbox/Grid
- **Docker Containerization**: Semua service dijalankan dalam Docker containers untuk konsistensi
- **RESTful API**: Backend Node.js dengan endpoint API yang terorganisir
- **Health Monitoring**: Monitoring status koneksi database secara real-time

## 🏗️ Arsitektur Sistem

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Frontend      │    │   Backend       │    │   Databases     │
│   (HTML/JS/CSS) │◄──►│   (Node.js)     │◄──►│ PostgreSQL(Neon)│
│                 │    │                 │    │ MongoDB(Atlas)  │
│   - Chart.js    │    │   - Express     │    │                 │
│   - Responsive  │    │   - pg (Postgres)│    │                 │
│   - Interactive │    │   - mongodb     │    │                 │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

## 📋 Prerequisites

- **Docker Desktop** untuk Windows terinstall
- **PowerShell 5.1+** atau **Windows Terminal** (recommended)
- **Node.js** (untuk database setup scripts)
- Port tersedia: 3000
- Koneksi internet untuk akses cloud databases

## 🚀 Quick Start

### 1. Setup Database (WAJIB - Sekali Setup)

**PENTING**: Sebelum menjalankan demo, Anda perlu mengatur database cloud terlebih dahulu:

```powershell
# Setup otomatis database PostgreSQL dan MongoDB
.\setup-databases.ps1
```

Script ini akan memandu Anda untuk:
- ✅ Setup PostgreSQL (Neon Cloud) dengan tabel dan data sample
- ✅ Setup MongoDB (Atlas Cloud) dengan collections dan data sample
- ✅ Test koneksi database

📋 **Untuk panduan setup database lengkap, lihat [DATABASE-SETUP.md](DATABASE-SETUP.md)**

### 2. Menjalankan Demo

**Menggunakan PowerShell (Recommended):**
```powershell
# Masuk ke direktori demo
cd windows-dd-simple

# Menjalankan demo
.\demo.ps1 start
```

**Menggunakan Command Prompt:**
```cmd
# Masuk ke direktori demo
cd windows-dd-simple

# Menjalankan demo
demo.bat start
```

### 2. Akses Aplikasi

Setelah semua service berjalan:

- **🌐 Web Dashboard**: http://localhost:3000
- **🐘 PostgreSQL**: Neon Cloud Database (hosted)
- **🍃 MongoDB**: Atlas Cloud Database (hosted)

## 📊 Data Sources

### PostgreSQL - Structured Data
- **Tabel Products**: Katalog produk elektronik
- **Tabel Sales**: Data transaksi penjualan
- **Relasi**: Foreign key antara products dan sales
- **Sample Data**: 10 produk, 25+ transaksi selama 6 bulan

### MongoDB - Document Data
- **Collection Customers**: Profil customer dengan nested objects
- **Collection Interactions**: Log aktivitas customer
- **Collection Reviews**: Review produk dengan rating
- **Sample Data**: 5 customers, 10+ interactions, 3 reviews

## 🎯 Use Cases Demo

### 1. Overview Dashboard
- Menampilkan status system secara keseluruhan
- Chart overview dengan data source statistics
- Real-time health monitoring PostgreSQL dan MongoDB

### 2. PostgreSQL Analytics
- **Sales by Product**: Bar chart penjualan per produk
- **Monthly Trends**: Line chart trend penjualan bulanan
- **Data Table**: Tabel detail dengan formatting mata uang

### 3. MongoDB Analytics
- **Customer Distribution**: Pie chart distribusi customer per kota
- **Interaction Types**: Doughnut chart tipe interaksi customer
- **Customer Profiles**: Tabel detail profil customer

### 4. Combined Analysis
- **Cross-Database Insights**: Analisis gabungan dari kedua database
- **Business Intelligence**: Insight otomatis dari pattern data
- **Correlation Analysis**: Hubungan antara penjualan dan interaksi customer

## 🔧 Management Commands

**PowerShell Script (`demo.ps1`):**
```powershell
.\demo.ps1 start       # Start semua services
.\demo.ps1 stop        # Stop semua services
.\demo.ps1 restart     # Restart semua services
.\demo.ps1 status      # Cek status services
.\demo.ps1 logs        # Lihat logs semua services
.\demo.ps1 logs webapp # Lihat logs service tertentu
.\demo.ps1 cleanup     # Hapus containers dan volumes
.\demo.ps1 info        # Tampilkan informasi koneksi
.\demo.ps1 help        # Tampilkan help
```

**Batch Script (`demo.bat`):**
```cmd
demo.bat start       # Start semua services
demo.bat stop        # Stop semua services
demo.bat restart     # Restart semua services
demo.bat status      # Cek status services
demo.bat logs        # Lihat logs semua services
demo.bat cleanup     # Hapus containers dan volumes
demo.bat info        # Tampilkan informasi koneksi
demo.bat help        # Tampilkan help
```

## 🔌 API Endpoints

### Health Check
```
GET /api/health
Response: Status PostgreSQL dan MongoDB
```

### PostgreSQL Endpoints
```
GET /api/postgres/sales
Response: Agregasi penjualan per produk

GET /api/postgres/monthly-sales
Response: Trend penjualan bulanan
```

### MongoDB Endpoints
```
GET /api/mongodb/customers
Response: Distribusi customer per kota

GET /api/mongodb/interactions
Response: Statistik tipe interaksi
```

### Combined Analytics
```
GET /api/combined/dashboard
Response: Data gabungan untuk analisis
```

## 📁 Struktur Project

```
windows-dd-simple/
├── docker-compose.yml          # Konfigurasi Docker services
├── Dockerfile                  # Docker image untuk webapp
├── package.json               # Dependencies Node.js
├── server.js                  # Backend API server
├── demo.ps1                   # PowerShell management script
├── demo.bat                   # Batch management script
├── README.md                  # Dokumentasi ini
├── public/                    # Frontend assets
│   ├── index.html            # Main dashboard
│   ├── script.js             # JavaScript functionality
│   └── style.css             # Responsive styling
└── init-scripts/             # Database initialization (legacy)
    ├── postgres/
    │   └── 01-init-demo.sql   # PostgreSQL schema & data
    └── mongo/
        └── 01-init-demo.js    # MongoDB collections & data
```

## 🛠️ Technology Stack

### Frontend
- **HTML5**: Semantic markup dengan accessibility
- **CSS3**: Modern styling dengan Flexbox/Grid, gradients, animations
- **JavaScript ES6+**: Async/await, modules, modern syntax
- **Chart.js**: Library visualisasi data yang powerful dan responsive

### Backend
- **Node.js**: JavaScript runtime untuk server
- **Express.js**: Web framework minimalis dan cepat
- **pg**: PostgreSQL client library
- **mongodb**: MongoDB official driver

### Database
- **PostgreSQL (Neon Cloud)**: Relational database untuk data terstruktur
- **MongoDB (Atlas Cloud)**: Document database untuk data semi-terstruktur

### DevOps
- **Docker**: Containerization semua services
- **Docker Compose**: Orchestration multi-container

## 🎨 Visual Features

### Modern UI/UX
- **Glassmorphism Design**: Backdrop blur effects
- **Gradient Backgrounds**: CSS linear gradients
- **Responsive Layout**: Mobile-first design
- **Interactive Elements**: Hover effects, transitions
- **Color-coded Status**: Visual health indicators

### Chart Visualizations
- **Bar Charts**: Sales analysis dengan custom styling
- **Line Charts**: Trend analysis dengan smooth curves
- **Pie Charts**: Distribution analysis
- **Doughnut Charts**: Interaction statistics
- **Horizontal Bar Charts**: Product rankings

## 🔒 Security Considerations

### Database Security
- Custom users dengan limited privileges
- Password-protected access
- Network isolation dalam Docker
- Data persistence dengan named volumes

### Application Security
- Input validation pada API endpoints
- Error handling yang comprehensive
- CORS configuration
- Health check untuk monitoring

## 🚀 Development

### Local Development
```bash
# Install dependencies
npm install

# Set environment variables
export POSTGRES_HOST=localhost
export POSTGRES_PORT=5434
export MONGODB_URL=mongodb://demo_admin:demo_password@localhost:27019/demo_db

# Run development server
npm run dev
```

### Database Connections
```bash
# Connect to PostgreSQL
psql -h localhost -p 5434 -U demo_user -d demo_db

# Connect to MongoDB
mongosh mongodb://demo_admin:demo_password@localhost:27019/demo_db
```

## 🐛 Troubleshooting

### Port Conflicts
Jika port sudah digunakan, edit `docker-compose.yml`:
```yaml
ports:
  - "3001:3000"  # Change web port
  - "5435:5432"  # Change PostgreSQL port
  - "27020:27017" # Change MongoDB port
```

### Container Issues
```bash
# Restart containers
./demo.sh restart

# Check container logs
./demo.sh logs webapp
./demo.sh logs postgres
./demo.sh logs mongodb

# Complete cleanup
./demo.sh cleanup
```

### Data Issues
```bash
# Reinitialize databases
./demo.sh cleanup
./demo.sh start
```

## 📈 Performance Optimization

### Database Optimization
- Indexes pada foreign keys dan search fields
- Connection pooling di PostgreSQL
- Aggregation pipeline optimization di MongoDB

### Frontend Optimization
- Chart.js responsive configuration
- Lazy loading untuk data yang besar
- CSS animations dengan GPU acceleration
- Optimized asset loading

## 🔄 Future Enhancements

### Possible Extensions
- **Real-time Updates**: WebSocket untuk live data
- **Advanced Analytics**: Machine learning insights
- **Export Features**: PDF/Excel export functionality
- **User Management**: Authentication dan authorization
- **Caching Layer**: Redis untuk performance
- **Monitoring**: Grafana/Prometheus integration

### Scaling Considerations
- Load balancing untuk multiple instances
- Database sharding untuk data besar
- CDN untuk static assets
- Microservices architecture

## 📞 Support

Jika mengalami masalah:

1. Cek status services: `./demo.sh status`
2. Lihat logs: `./demo.sh logs`
3. Restart demo: `./demo.sh restart`
4. Cleanup dan restart: `./demo.sh cleanup && ./demo.sh start`

## 📝 Learning Objectives

Demo ini dirancang untuk mempelajari:

1. **Multi-Database Integration**: Cara mengintegrasikan SQL dan NoSQL
2. **Data Visualization**: Implementasi chart interaktif dengan JavaScript
3. **API Design**: RESTful API design patterns
4. **Docker Operations**: Containerization dan orchestration
5. **Full-Stack Development**: End-to-end web application development
6. **Modern Frontend**: Responsive design dan UX principles

## 🪟 Windows-Specific Features

### PowerShell Integration
- **Colored Output**: Rich console colors untuk better UX
- **Parameter Validation**: Built-in command validation
- **Error Handling**: Comprehensive error messages
- **Modern Syntax**: PowerShell 5.1+ features

### Batch File Support
- **Legacy Compatibility**: Mendukung Command Prompt klasik
- **Simple Commands**: Syntax yang familiar untuk Windows users
- **Color Support**: ANSI color codes untuk output yang menarik

### Windows Terminal Integration
```powershell
# Set execution policy (jika diperlukan)
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser

# Jalankan dengan Windows Terminal untuk pengalaman terbaik
wt -d . pwsh -Command ".\demo.ps1 start"
```

### Docker Desktop Integration
- **Native Windows Support**: Optimized untuk Docker Desktop
- **WSL2 Backend**: Performa optimal dengan WSL2
- **Resource Management**: Monitoring resource usage

### Troubleshooting Windows-Specific Issues

#### PowerShell Execution Policy
```powershell
# Jika script tidak bisa dijalankan
Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope Process
.\demo.ps1 start
```

#### Docker Desktop Issues
```powershell
# Restart Docker Desktop
Restart-Service com.docker.service

# Check Docker status
docker version
docker-compose version
```

#### Port Conflicts pada Windows
```powershell
# Check port usage
netstat -ano | findstr :3000

# Kill process using port
taskkill /PID <process_id> /F
```

---

🎉 **Selamat mencoba demo Multi-Source Data Visualization untuk Windows!**

Untuk pertanyaan lebih lanjut, silakan eksplorasi kode atau jalankan:
- PowerShell: `.\demo.ps1 help`
- Command Prompt: `demo.bat help` 