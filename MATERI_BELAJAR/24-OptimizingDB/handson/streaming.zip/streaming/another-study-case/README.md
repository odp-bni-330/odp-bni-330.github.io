# Streaming Data Simulation with Kafka, Spark, and JavaScript

This project demonstrates a complete data streaming pipeline using:
- JavaScript producer to generate data
- Apache Kafka for message streaming
- Apache Spark for stream processing (using JavaScript)

## Project Structure

```
streaming/
├── docker-compose.yml        # Docker configuration for Kafka and Spark
├── js-producer/              # JavaScript Kafka producer
│   ├── package.json
│   └── producer.js
├── spark-apps/              # Spark streaming application (JavaScript)
│   ├── package.json
│   └── spark-streaming.js
├── spark-data/              # Directory for Spark data output
│   ├── event-counts/        # CSV files with event count data
│   ├── purchase-analysis/   # JSON files with purchase analysis
│   └── checkpoints/         # Spark streaming checkpoints
└── README.md                # This file
```

## Prerequisites

- Docker and Docker Compose
- Node.js and npm

## Getting Started

### 1. Start the Kafka and Spark clusters

```bash
docker-compose up -d
```

### 2. Start the JavaScript producer

```bash
cd js-producer
npm install
npm start
```

### 3. Start the JavaScript Spark application

```bash
cd spark-apps
npm install
npm start
```

## Data Flow

1. The JavaScript producer generates random user events (clicks, views, purchases, etc.)
2. Events are sent to the Kafka topic "user-events"
3. Spark Streaming consumes the events from Kafka
4. Spark processes the data in real-time:
   - Counts events by type in 1-minute windows
   - Analyzes purchase events (average price, count)
5. Results are displayed in the console AND saved to files:
   - Event counts saved as CSV files in spark-data/event-counts
   - Purchase analysis saved as JSON files in spark-data/purchase-analysis

## Stopping the Services

```bash
docker-compose down
```