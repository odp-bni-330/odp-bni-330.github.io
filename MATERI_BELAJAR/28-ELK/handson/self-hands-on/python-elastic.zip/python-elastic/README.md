# Ingesting Data with Python

![client-architecture](./img/client-architecture.png)

## Langkah

**Langkah 0** : Setup virtual environment

```bash
mkdir python-elastic
cd python-elastic
python -m venv venv
source venv/bin/activate
```

**Langkah 1** : Install library yang dibutuhkan

```bash
pip install elasticsearch
pip install elasticsearch-async

touch requirements.txt
pip freeze >> requirements.txt
```

atau:

```bash
pip install -r requirements.txt
```

**Langkah 2** : Jalankan program python

```bash
python ingest.py            # masukkan data ke index
python search.py            # lakukan pencarian data
```

maka akan otomatis dibuatkan index

![index-lord-of-the-ring](./img/index-lord-of-the-ring.png)

[Referensi](https://www.elastic.co/docs/manage-data/ingest/ingesting-data-from-applications/ingest-data-with-python-on-elasticsearch-service)
