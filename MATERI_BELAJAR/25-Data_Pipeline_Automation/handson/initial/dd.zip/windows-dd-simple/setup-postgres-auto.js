const { Pool } = require('pg');
const fs = require('fs');
const path = require('path');

// Database configuration (matching the docker-compose environment)
const dbConfig = {
    host: 'ep-falling-cake-a1j2rvpd-pooler.ap-southeast-1.aws.neon.tech',
    port: 5432,
    database: 'neondb',
    user: 'neondb_owner',
    password: 'npg_G47bTrUPvdfo',
    ssl: {
        rejectUnauthorized: false
    }
};

// Windows-compatible console colors
const colors = {
    reset: '',
    bright: '',
    green: '',
    red: '',
    yellow: '',
    blue: '',
    magenta: '',
    cyan: ''
};

// Check if we're in a Windows environment that supports ANSI colors
if (process.platform === 'win32') {
    // Try to enable ANSI colors on Windows
    try {
        process.stdout.write('\x1b[0m');
        colors.reset = '\x1b[0m';
        colors.bright = '\x1b[1m';
        colors.green = '\x1b[32m';
        colors.red = '\x1b[31m';
        colors.yellow = '\x1b[33m';
        colors.blue = '\x1b[34m';
        colors.magenta = '\x1b[35m';
        colors.cyan = '\x1b[36m';
    } catch (e) {
        // Colors not supported, use plain text
    }
} else {
    colors.reset = '\x1b[0m';
    colors.bright = '\x1b[1m';
    colors.green = '\x1b[32m';
    colors.red = '\x1b[31m';
    colors.yellow = '\x1b[33m';
    colors.blue = '\x1b[34m';
    colors.magenta = '\x1b[35m';
    colors.cyan = '\x1b[36m';
}

function log(message, color = 'reset') {
    console.log(`${colors[color]}${message}${colors.reset}`);
}

async function setupPostgreSQL() {
    const pool = new Pool(dbConfig);
    
    try {
        log('🚀 Starting PostgreSQL Database Setup for Windows DD Simple', 'magenta');
        log('📍 Connecting to Neon PostgreSQL...', 'blue');
        
        // Test connection
        const client = await pool.connect();
        log('✅ Connected to PostgreSQL successfully!', 'green');
        
        // Read and execute SQL setup script
        log('📝 Reading SQL setup script...', 'blue');
        const sqlPath = path.join(__dirname, 'setup-databases.sql');
        
        if (!fs.existsSync(sqlPath)) {
            throw new Error('setup-databases.sql file not found!');
        }
        
        const sqlContent = fs.readFileSync(sqlPath, 'utf8');
        log('✅ SQL script loaded successfully!', 'green');
        
        log('🔧 Executing database setup...', 'blue');
        
        // Execute the SQL script
        const result = await client.query(sqlContent);
        
        log('✅ Database setup completed successfully!', 'green');
        
        // Verify tables were created
        log('🔍 Verifying table creation...', 'blue');
        
        const tablesQuery = `
            SELECT table_name 
            FROM information_schema.tables 
            WHERE table_schema = 'public' 
            AND table_name IN ('products', 'sales')
            ORDER BY table_name;
        `;
        
        const tablesResult = await client.query(tablesQuery);
        
        if (tablesResult.rows.length === 2) {
            log('✅ Tables verified: products, sales', 'green');
            
            // Check data
            const productCount = await client.query('SELECT COUNT(*) as count FROM products');
            const salesCount = await client.query('SELECT COUNT(*) as count FROM sales');
            
            log(`📊 Sample data loaded:`, 'cyan');
            log(`   • Products: ${productCount.rows[0].count}`, 'cyan');
            log(`   • Sales: ${salesCount.rows[0].count}`, 'cyan');
            
            // Test a sample query to ensure data integrity
            log('🧪 Testing data integrity...', 'blue');
            const testQuery = await client.query(`
                SELECT p.name, SUM(s.total_amount) as total_sales
                FROM products p
                LEFT JOIN sales s ON p.id = s.product_id
                GROUP BY p.id, p.name
                ORDER BY total_sales DESC NULLS LAST
                LIMIT 3
            `);
            
            log('✅ Top 3 products by sales:', 'green');
            testQuery.rows.forEach((row, index) => {
                const sales = row.total_sales ? `Rp ${parseInt(row.total_sales).toLocaleString('id-ID')}` : 'No sales';
                log(`   ${index + 1}. ${row.name}: ${sales}`, 'cyan');
            });
            
        } else {
            log('⚠️  Warning: Not all tables were created', 'yellow');
        }
        
        client.release();
        log('🎉 PostgreSQL setup completed successfully!', 'green');
        
    } catch (error) {
        log('❌ PostgreSQL setup failed:', 'red');
        log(error.message, 'red');
        
        if (error.code) {
            log(`Error Code: ${error.code}`, 'red');
        }
        
        // Provide more specific error guidance
        if (error.code === '22003') {
            log('💡 This appears to be a numeric overflow error.', 'yellow');
            log('   The decimal values might be too large for the field type.', 'yellow');
        }
        
        throw error;
    } finally {
        await pool.end();
    }
}

// Run the setup
if (require.main === module) {
    setupPostgreSQL()
        .then(() => {
            log('\n🚀 Setup completed! You can now run your application.', 'bright');
            log('💡 Try running: demo.bat start', 'cyan');
            log('💡 Or PowerShell: .\\demo.ps1 start', 'cyan');
            process.exit(0);
        })
        .catch((error) => {
            log('\n❌ Setup failed. Please check the error above.', 'red');
            process.exit(1);
        });
}

module.exports = { setupPostgreSQL }; 