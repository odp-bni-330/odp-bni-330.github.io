# Navigate to the directory where the script is located
Set-Location $PSScriptRoot

Write-Host "Stopping monitoring stack..." -ForegroundColor Red
docker-compose down

Write-Host "Monitoring stack stopped." -ForegroundColor Green
Write-Host "All containers have been removed." -ForegroundColor Green
Read-Host "Press Enter to continue" 