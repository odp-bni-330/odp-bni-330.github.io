package com.bni.taskmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.bni.taskmanagement.model.Task;

/*************************** LAYER REPOSITORY ***************************/

// mengkoneksikan layer model ke layer repository
public interface TaskRepository extends JpaRepository<Task, Long> {
    
    // kosong namun sudah disediakan secara template oleh Jpa
    // paling tidak : CRUD

    // rule of thumb : jangan jalankan query berat di DB
    // e.g. join, subquery

    // findAllById(<ID>)
    // query setara dengan : SELECT * FROM task
}

/*************************** END OF LAYER REPOSITORY ***************************/

// referensi :
    // https://docs.spring.io/spring-data/jpa/docs/current/api/org/springframework/data/jpa/repository/JpaRepository.html