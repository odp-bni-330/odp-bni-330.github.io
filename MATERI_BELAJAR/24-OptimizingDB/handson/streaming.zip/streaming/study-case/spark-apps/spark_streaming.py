from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
import os
import json
from datetime import datetime

# Alert thresholds configuration
ALERT_THRESHOLDS = {
    "popular_product_threshold": 20,      # Units sold per 5-minute window
    "high_sales_threshold": 50000,        # Total sales per 5-minute window  
    "anomaly_threshold": 3.0,             # Standard deviation multiplier
    "category_dominance_threshold": 0.6,   # Category market share threshold
    "location_concentration_threshold": 0.5 # Location concentration threshold
}

def create_spark_session():
    """Create and configure Spark session for real-time analytics"""
    return (SparkSession.builder
            .appName("RealTimeTransactionAnalysis")
            .config("spark.jars.packages", "org.apache.spark:spark-sql-kafka-0-10_2.12:3.3.0")
            .config("spark.sql.adaptive.enabled", "true")
            .config("spark.sql.adaptive.coalescePartitions.enabled", "true")
            .getOrCreate())

def define_transaction_schema():
    """Define comprehensive schema for enhanced transaction data"""
    return StructType([
        StructField("transaction_id", StringType(), True),
        StructField("product_id", IntegerType(), True),
        StructField("product_name", StringType(), True),
        StructField("category", StringType(), True),
        StructField("quantity", IntegerType(), True),
        StructField("price_per_unit", DoubleType(), True),
        StructField("total_amount", DoubleType(), True),
        StructField("payment_method", StringType(), True),
        StructField("location", StringType(), True),
        StructField("customer_segment", StringType(), True),
        StructField("timestamp", StringType(), True),
        StructField("hour_of_day", IntegerType(), True),
        StructField("day_of_week", StringType(), True),
        StructField("day_of_month", IntegerType(), True),
        StructField("month", IntegerType(), True),
        StructField("year", IntegerType(), True)
    ])

def read_kafka_stream(spark):
    """Read streaming data from Kafka with optimized settings"""
    return (spark
            .readStream
            .format("kafka")
            .option("kafka.bootstrap.servers", "kafka:29092")
            .option("subscribe", "sales_transactions")
            .option("startingOffsets", "latest")
            .option("maxOffsetsPerTrigger", "1000")
            .load())

def process_stream(df, schema):
    """Enhanced stream processing with data enrichment"""
    # Parse JSON data
    parsed_df = df.selectExpr("CAST(value AS STRING)") \
        .select(from_json(col("value"), schema).alias("data")) \
        .select("data.*")
    
    # Add processing timestamp and derived fields
    enriched_df = parsed_df \
        .withColumn("processing_time", current_timestamp()) \
        .withColumn("timestamp_parsed", to_timestamp("timestamp", "yyyy-MM-dd HH:mm:ss")) \
        .withColumn("revenue_per_item", col("total_amount") / col("quantity")) \
        .withColumn("is_high_value", when(col("total_amount") > 1000, True).otherwise(False)) \
        .withColumn("is_weekend", when(col("day_of_week").isin(["Saturday", "Sunday"]), True).otherwise(False))
    
    return enriched_df

def analyze_top_products(df):
    """Analyze top selling products with enhanced metrics"""
    # Add watermark to handle late data
    df_with_watermark = df.withWatermark("timestamp_parsed", "2 minutes")
    
    return df_with_watermark \
        .groupBy(
            window(col("timestamp_parsed"), "5 minutes"), 
            "product_name", 
            "category",
            "customer_segment"
        ) \
        .agg(
            sum("quantity").alias("units_sold"),
            sum("total_amount").alias("total_sales"),
            count("transaction_id").alias("transaction_count"),
            avg("total_amount").alias("avg_transaction_value"),
            max("total_amount").alias("max_transaction_value"),
            approx_count_distinct("location").alias("unique_locations")
        ) \
        .withColumn("sales_per_unit", col("total_sales") / col("units_sold"))

def analyze_sales_by_category(df):
    """Enhanced category analysis without complex joins"""
    # Add watermark to handle late data
    df_with_watermark = df.withWatermark("timestamp_parsed", "2 minutes")
    
    return df_with_watermark \
        .groupBy(window(col("timestamp_parsed"), "5 minutes"), "category") \
        .agg(
            sum("total_amount").alias("total_sales"),
            count("transaction_id").alias("transaction_count"),
            sum("quantity").alias("total_units"),
            avg("total_amount").alias("avg_transaction_value"),
            approx_count_distinct("customer_segment").alias("unique_segments"),
            approx_count_distinct("location").alias("unique_locations")
        ) \
        .withColumn("sales_per_transaction", col("total_sales") / col("transaction_count")) \
        .orderBy(desc("total_sales"))

def analyze_sales_by_location(df):
    """Enhanced location analysis with geographic insights"""
    # Add watermark to handle late data
    df_with_watermark = df.withWatermark("timestamp_parsed", "2 minutes")
    
    return df_with_watermark \
        .groupBy(window(col("timestamp_parsed"), "5 minutes"), "location") \
        .agg(
            sum("total_amount").alias("total_sales"),
            count("transaction_id").alias("transaction_count"),
            sum("quantity").alias("total_units"),
            avg("total_amount").alias("avg_transaction_value"),
            approx_count_distinct("category").alias("unique_categories"),
            approx_count_distinct("customer_segment").alias("unique_segments"),
            max("total_amount").alias("max_single_transaction")
        ) \
        .withColumn("sales_per_transaction", col("total_sales") / col("transaction_count"))

def analyze_customer_segments(df):
    """Analyze customer segment behavior"""
    # Add watermark to handle late data
    df_with_watermark = df.withWatermark("timestamp_parsed", "2 minutes")
    
    return df_with_watermark \
        .groupBy(window(col("timestamp_parsed"), "5 minutes"), "customer_segment") \
        .agg(
            sum("total_amount").alias("total_sales"),
            count("transaction_id").alias("transaction_count"),
            avg("total_amount").alias("avg_transaction_value"),
            sum("quantity").alias("total_units"),
            approx_count_distinct("category").alias("categories_purchased"),
            approx_count_distinct("location").alias("locations_active")
        ) \
        .withColumn("avg_units_per_transaction", col("total_units") / col("transaction_count"))

def analyze_hourly_trends(df):
    """Enhanced hourly trend analysis - using time window aggregation"""
    # Add watermark to handle late data
    df_with_watermark = df.withWatermark("timestamp_parsed", "2 minutes")
    
    return df_with_watermark \
        .groupBy(window(col("timestamp_parsed"), "10 minutes"), "hour_of_day", "day_of_week") \
        .agg(
            sum("total_amount").alias("total_sales"),
            count("transaction_id").alias("transaction_count"),
            avg("total_amount").alias("avg_transaction_value"),
            sum("quantity").alias("total_units"),
            approx_count_distinct("category").alias("active_categories"),
            approx_count_distinct("location").alias("active_locations")
        ) \
        .withColumn("sales_per_transaction", col("total_sales") / col("transaction_count"))

def create_notification_alerts(df):
    """Generate real-time notifications and alerts - simplified to avoid multiple streaming aggregations"""
    # Add watermark to handle late data
    df_with_watermark = df.withWatermark("timestamp_parsed", "2 minutes")
    
    # Popular product alerts
    popular_products = df_with_watermark \
        .groupBy(window(col("timestamp_parsed"), "5 minutes"), "product_name", "category") \
        .agg(sum("quantity").alias("units_sold"), sum("total_amount").alias("total_sales")) \
        .filter(col("units_sold") >= ALERT_THRESHOLDS["popular_product_threshold"]) \
        .withColumn("alert_type", lit("POPULAR_PRODUCT")) \
        .withColumn("alert_message", 
                   concat(lit("🔥 HOT PRODUCT ALERT: "), col("product_name"), 
                         lit(" sold "), col("units_sold"), lit(" units in 5 minutes!"))) \
        .withColumn("severity", lit("HIGH")) \
        .withColumn("timestamp", current_timestamp())
    
    # High sales alerts
    high_sales = df_with_watermark \
        .groupBy(window(col("timestamp_parsed"), "5 minutes")) \
        .agg(sum("total_amount").alias("total_sales")) \
        .filter(col("total_sales") >= ALERT_THRESHOLDS["high_sales_threshold"]) \
        .withColumn("alert_type", lit("HIGH_SALES")) \
        .withColumn("alert_message", 
                   concat(lit("💰 HIGH SALES ALERT: $"), col("total_sales"), 
                         lit(" in 5 minutes!"))) \
        .withColumn("severity", lit("MEDIUM")) \
        .withColumn("timestamp", current_timestamp())
    
    # Simplified category alerts without market share calculation (to avoid joins)
    category_alerts = df_with_watermark \
        .groupBy(window(col("timestamp_parsed"), "5 minutes"), "category") \
        .agg(sum("total_amount").alias("category_sales"), count("transaction_id").alias("transaction_count")) \
        .filter(col("category_sales") >= ALERT_THRESHOLDS["high_sales_threshold"] * 0.3) \
        .withColumn("alert_type", lit("HIGH_CATEGORY_SALES")) \
        .withColumn("alert_message", 
                   concat(lit("📊 HIGH CATEGORY SALES: "), col("category"), 
                         lit(" generated $"), round(col("category_sales"), 2), 
                         lit(" in 5 minutes!"))) \
        .withColumn("severity", lit("INFO")) \
        .withColumn("timestamp", current_timestamp())
    
    return popular_products, high_sales, category_alerts

def setup_data_directories():
    """Setup data directories with proper permissions"""
    data_dirs = [
        "/opt/spark-data/top_products",
        "/opt/spark-data/sales_by_category", 
        "/opt/spark-data/sales_by_location",
        "/opt/spark-data/customer_segments",
        "/opt/spark-data/hourly_trends",
        "/opt/spark-data/notifications",
        "/opt/spark-data/notifications/popular_products",
        "/opt/spark-data/alerts",
        "/opt/spark-data/checkpoints",
        "/opt/spark-data/checkpoints/top_products",
        "/opt/spark-data/checkpoints/sales_by_category",
        "/opt/spark-data/checkpoints/sales_by_location",
        "/opt/spark-data/checkpoints/customer_segments",
        "/opt/spark-data/checkpoints/hourly_trends",
        "/opt/spark-data/checkpoints/notifications_popular"
    ]
    
    for directory in data_dirs:
        try:
            os.makedirs(directory, exist_ok=True)
            # Set permissions for the directory
            try:
                os.chmod(directory, 0o777)
            except Exception as perm_error:
                print(f"⚠️  Warning: Could not set permissions for {directory}: {perm_error}")
            print(f"✅ Created directory: {directory}")
        except Exception as e:
            print(f"❌ Error creating directory {directory}: {e}")
            # Continue with other directories even if one fails

def start_streaming_queries(processed_df):
    """Start all enhanced streaming queries with notifications"""
    
    print("🚀 Starting Real-Time Analytics Engine...")
    print("📊 Initializing data directories...")
    setup_data_directories()
    
    checkpoint_dir = "/opt/spark-data/checkpoints"
    queries = []
    
    try:
        # 1. Top Products Analysis
        print("📈 Starting Top Products Analysis...")
        top_products = analyze_top_products(processed_df)
        
        top_products_query = top_products \
            .writeStream \
            .outputMode("complete") \
            .format("console") \
            .option("truncate", "false") \
            .option("numRows", 10) \
            .trigger(processingTime="10 seconds") \
            .queryName("top_products_analysis") \
            .start()
        queries.append(top_products_query)
        
        # 2. Sales by Category Analysis
        print("📊 Starting Category Analysis...")
        sales_by_category = analyze_sales_by_category(processed_df)
        
        category_query = sales_by_category \
            .writeStream \
            .outputMode("complete") \
            .format("console") \
            .option("truncate", "false") \
            .option("numRows", "15") \
            .trigger(processingTime="10 seconds") \
            .queryName("category_analysis") \
            .start()
        queries.append(category_query)
        
        # 3. Sales by Location Analysis
        print("🌍 Starting Location Analysis...")
        sales_by_location = analyze_sales_by_location(processed_df)
        
        location_query = sales_by_location \
            .writeStream \
            .outputMode("complete") \
            .format("console") \
            .option("truncate", "false") \
            .option("numRows", "15") \
            .trigger(processingTime="10 seconds") \
            .queryName("location_analysis") \
            .start()
        queries.append(location_query)
        
        # 4. Customer Segment Analysis
        print("👥 Starting Customer Segment Analysis...")
        customer_segments = analyze_customer_segments(processed_df)
        
        segments_query = customer_segments \
            .writeStream \
            .outputMode("complete") \
            .format("console") \
            .option("truncate", "false") \
            .option("numRows", "10") \
            .trigger(processingTime="10 seconds") \
            .queryName("customer_segments") \
            .start()
        queries.append(segments_query)
        
        # 5. Hourly Trends Analysis
        print("⏰ Starting Hourly Trends Analysis...")
        hourly_trends = analyze_hourly_trends(processed_df)
        
        hourly_query = hourly_trends \
            .writeStream \
            .outputMode("complete") \
            .format("console") \
            .option("truncate", "false") \
            .option("numRows", "24") \
            .trigger(processingTime="30 seconds") \
            .queryName("hourly_trends") \
            .start()
        queries.append(hourly_query)
        
        # 6. Notification System
        print("🚨 Starting Notification System...")
        try:
            popular_products_alerts, high_sales_alerts, category_alerts = create_notification_alerts(processed_df)
            
            # Popular products notifications
            popular_alerts_query = popular_products_alerts \
                .writeStream \
                .outputMode("append") \
                .format("console") \
                .option("truncate", "false") \
                .trigger(processingTime="15 seconds") \
                .queryName("popular_alerts") \
                .start()
            queries.append(popular_alerts_query)
            
            # High sales notifications
            high_sales_query = high_sales_alerts \
                .writeStream \
                .outputMode("append") \
                .format("console") \
                .option("truncate", "false") \
                .trigger(processingTime="15 seconds") \
                .queryName("high_sales_alerts") \
                .start()
            queries.append(high_sales_query)
            
            # Category dominance notifications
            category_alerts_query = category_alerts \
                .writeStream \
                .outputMode("append") \
                .format("console") \
                .option("truncate", "false") \
                .trigger(processingTime="30 seconds") \
                .queryName("category_alerts") \
                .start()
            queries.append(category_alerts_query)
            
        except Exception as alert_error:
            print(f"⚠️  Warning: Could not start notification queries: {alert_error}")
            print("📊 Continuing with main analytics queries...")
        
        print("✅ All streaming queries started successfully!")
        print("📊 Real-time analytics and notifications are now active")
        print("🎯 Monitor the console for live alerts and insights")
        
        return queries
        
    except Exception as e:
        print(f"❌ Error starting streaming queries: {e}")
        print(f"📝 Error details: {str(e)}")
        # Stop any started queries in case of error
        for query in queries:
            if query and query.isActive:
                try:
                    query.stop()
                except:
                    pass
        return []

def main():
    """Main execution function"""
    print("=" * 80)
    print("🏪 REAL-TIME TRANSACTION ANALYTICS ENGINE")
    print("📈 Studi Kasus: Analisis Transaksi Real-Time")
    print("🚨 With Live Notifications & Trend Analysis")
    print("=" * 80)
    
    # Create Spark session
    spark = create_spark_session()
    spark.sparkContext.setLogLevel("WARN")
    
    # Define schema
    schema = define_transaction_schema()
    
    # Read from Kafka
    print("📡 Connecting to Kafka stream...")
    kafka_df = read_kafka_stream(spark)
    
    # Process the stream
    print("⚡ Processing transaction stream...")
    processed_df = process_stream(kafka_df, schema)
    
    # Start all streaming queries
    queries = start_streaming_queries(processed_df)
    
    if queries:
        print("\n🎯 Analytics Pipeline Status:")
        print("   ✅ Real-time transaction processing")
        print("   ✅ Top products identification") 
        print("   ✅ Category performance analysis")
        print("   ✅ Geographic sales distribution")
        print("   ✅ Customer segment insights")
        print("   ✅ Hourly trend analysis")
        print("   ✅ Automated notification system")
        print("\n📊 Dashboard data being updated every 10 seconds")
        print("🔔 Alerts will appear in console and saved to files")
        print("\n💡 Access Spark UI at http://localhost:8080 for monitoring")
        
        # Wait for termination
        try:
            for query in queries:
                if query and query.isActive:
                    query.awaitTermination()
        except KeyboardInterrupt:
            print("\n🛑 Shutting down analytics engine...")
            for query in queries:
                if query and query.isActive:
                    query.stop()
            print("✅ All queries stopped successfully")
    else:
        print("❌ Failed to start streaming queries")

if __name__ == "__main__":
    main()