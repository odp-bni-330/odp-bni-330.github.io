import os
import requests
from dotenv import load_dotenv

# Load .env file
load_dotenv()

# Get token and chat_id from environment variables
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")

# Define the message
message = "🚨 sebuah pesan dari python!"

# Define the URL
url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"

# Define the payload
payload = {
    "chat_id": TELEGRAM_CHAT_ID,
    "text": message,
}

# Send the POST request
response = requests.post(url, data=payload)

# Print the response (optional)
print("Status Code:", response.status_code)
print("Response Body:", response.text)
