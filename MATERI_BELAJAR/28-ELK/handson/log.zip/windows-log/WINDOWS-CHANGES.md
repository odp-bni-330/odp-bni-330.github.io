# Windows Compatibility Changes 🪟

Dokumen ini menjelaskan perubahan yang dibuat untuk mengadaptasi ELK Stack demo agar berjalan optimal di Windows.

## 📋 Ringkasan Perubahan

### 🔄 File yang Diganti/Dibuat Baru

| Unix Version | Windows Version | Keterangan |
|--------------|----------------|------------|
| `run-elk-demo.sh` | `run-elk-demo.ps1` | Script utama dalam PowerShell |
| `scripts/generate_logs.sh` | `scripts/generate_logs.ps1` | Log generator dalam PowerShell |
| - | `run-elk-demo.bat` | Alternatif batch file untuk kemudahan |
| `README.md` | `README.md` (updated) | Dokumentasi khusus Windows |

### ⚙️ Perubahan Konfigurasi

#### Docker Compose (`docker-compose.yml`)
- **Removed**: `version: '3.8'` (deprecated warning)
- **Filebeat volumes**: Menghapus Docker socket mounting untuk Windows compatibility
  ```yaml
  # Dihapus untuk Windows:
  # - /var/lib/docker/containers:/var/lib/docker/containers:ro
  # - /var/run/docker.sock:/var/run/docker.sock:ro
  ```

#### Filebeat (`filebeat/filebeat.yml`)
- **Docker metadata processor**: Di-disable untuk Windows
  ```yaml
  # Dihapus untuk Windows:
  # - add_docker_metadata: ~
  ```

### 🆕 PowerShell Features

#### Main Script (`run-elk-demo.ps1`)
- **Color Output Functions**: Menggunakan `Write-Host -ForegroundColor`
- **Error Handling**: PowerShell `try-catch` blocks
- **Web Requests**: `Invoke-WebRequest` dan `Invoke-RestMethod`
- **Background Jobs**: `Start-Job` untuk log generator
- **Parameter Validation**: `ValidateSet` untuk command arguments

#### Log Generator (`scripts/generate_logs.ps1`)
- **Array Operations**: PowerShell array syntax dan `Get-Random`
- **File Operations**: `Add-Content` dengan UTF8 encoding
- **Date Formatting**: `Get-Date -Format`
- **Error Handling**: Try-catch untuk file operations
- **Path Separators**: Windows backslash paths (`\`)

### 🔧 Windows-Specific Optimizations

#### Execution Policy
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

#### Background Job Management
- **Start Jobs**: `Start-Job -ScriptBlock { ... }`
- **Stop Jobs**: `Stop-Job -Id $jobId` dan `Remove-Job -Id $jobId`
- **Job Tracking**: PID file untuk tracking background jobs

#### Path Handling
- **Windows Paths**: `logs\apache\access.log` (backslash)
- **PowerShell Compatibility**: Forward slash juga didukung

### 📊 Feature Comparison

| Feature | Unix Version | Windows Version | Status |
|---------|-------------|-----------------|--------|
| Main Script | Bash | PowerShell + Batch | ✅ Enhanced |
| Log Generator | Bash | PowerShell | ✅ Enhanced |
| Docker Integration | Full | Compatible | ✅ Working |
| Background Processing | `nohup` + `&` | PowerShell Jobs | ✅ Better |
| Color Output | ANSI codes | PowerShell colors | ✅ Native |
| Error Handling | Basic | Advanced | ✅ Improved |
| Service Health Checks | `curl` | `Invoke-WebRequest` | ✅ Native |

### 🎯 Keunggulan Windows Version

1. **Better Error Handling**: PowerShell exception handling
2. **Native Windows Integration**: No need for WSL or Git Bash
3. **Rich Output**: Native Windows console colors
4. **Background Job Management**: PowerShell job system
5. **Parameter Validation**: Built-in PowerShell validation
6. **Dual Script Support**: PowerShell (full) + Batch (simple)

### ⚠️ Limitations

1. **Docker Socket**: Tidak ada Docker metadata untuk containers
2. **File Permissions**: Tidak ada Unix-style chmod
3. **Signal Handling**: PowerShell signal handling berbeda dari bash

### 🚀 Usage Examples

#### PowerShell (Recommended)
```powershell
# Set execution policy (once)
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser

# Run demo
.\run-elk-demo.ps1 start
.\run-elk-demo.ps1 stop
.\run-elk-demo.ps1 restart
```

#### Batch (Alternative)
```cmd
run-elk-demo.bat start
run-elk-demo.bat stop
run-elk-demo.bat status
```

#### Manual Log Generator
```powershell
# Run log generator manually
powershell -ExecutionPolicy Bypass -File "scripts\generate_logs.ps1"
```

### 📝 Testing Recommendations

1. **Test dengan Docker Desktop**: Pastikan WSL2 backend aktif
2. **Test dengan PowerShell 5.1 dan 7+**: Compatibility check
3. **Test Execution Policy**: Berbagai skenario policy
4. **Test Background Jobs**: Job lifecycle management
5. **Test Path Separators**: Forward slash vs backslash

---

**Note**: Semua fungsionalitas core ELK stack tetap sama, hanya delivery mechanism yang disesuaikan untuk Windows environment. 