/*
 * Written by : Bostang Palaguna
 * Date : 2025-05-28
 * File : ProductV1.java
 * Deskripsi : Deklarasi class ProductV2 (DTO)
 */

// src/main/java/com/example/api_versioning/dto/v1/ProductV1.java
package com.example.api_versioning.dto.v1;  // pen-definisi-an package

// import library
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


/************************** Layer Model/DTO **************************/
// Layer Model/Data Transfer Object (DTO) 
    // → kemas data produk untuk dikirim melalui layer Controller → Client

// Anotasi Lombok → untuk kurangi boilerplate code
@Data                   // generasi otomatis getter & setter
@NoArgsConstructor      // buat constructor tanpa parameter (default constructor)
@AllArgsConstructor     // buat constructor dengan semua parameter
public class ProductV1 {
    private Long id;
    private String name;
    private double price;
}

/************************** End of Layer Model/DTO *******************/

/*CATATAN
 * - constructor tanpa parameter:
 *  public ProductV1() {}
 * 
 * - constructor dengan semua parameter:
 * public ProductV1(Long id, String name, double price) {
    this.id = id;
    this.name = name;
    this.price = price;
}
 */