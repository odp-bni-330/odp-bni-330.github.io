# Linux DD Simple - Setup Summary 🐧

**Multi-Source Data Demo optimized for Linux distributions**

## 📋 Migration Overview

Proyek **linux-dd-simple** adalah adaptasi Linux-optimized dari **unix-dd-simple** dengan berbagai peningkatan dan fitur khusus Linux.

### ✨ Linux-Specific Enhancements

#### 1. **Advanced Terminal Support**
- ✅ Automatic color detection menggunakan `tput`
- ✅ TERM environment variable support
- ✅ Graceful fallback untuk terminals tanpa warna
- ✅ UTF-8 encoding detection

#### 2. **System Integration Features**
- ✅ **systemd user services** untuk production deployment
- ✅ **journalctl** integration untuk centralized logging
- ✅ Process management dengan proper signal handling
- ✅ Resource limits dan security constraints
- ✅ Service auto-restart dan health monitoring

#### 3. **Distribution Detection & Support**
- ✅ Auto-detection: Ubuntu, Debian, CentOS, Fedora, Arch, openSUSE, Alpine
- ✅ Package manager specific installation commands
- ✅ Kernel version dan architecture detection  
- ✅ Real-time memory dan load average monitoring

#### 4. **Enhanced Network & Connectivity**
- ✅ Multiple HTTP client support (curl, wget, python3)
- ✅ DNS resolution testing dan troubleshooting
- ✅ Network connectivity validation
- ✅ Firewall detection (ufw, firewalld, iptables)

#### 5. **Performance Monitoring**
- ✅ Real-time system info (/proc/meminfo, /proc/loadavg)
- ✅ Resource usage monitoring
- ✅ Process performance tracking
- ✅ Linux-specific optimization recommendations

## 🗃️ Database Architecture (Enhanced)

### PostgreSQL (Neon Cloud) - Fixed Schema
```sql
-- Fixed decimal precision untuk Indonesian Rupiah
Products Table:
- price: DECIMAL(12,2)      -- Support hingga 999 miliar IDR
- Contoh: Rp 180.000.000 (laptop gaming premium)

Sales Table:  
- total_amount: DECIMAL(15,2) -- Support hingga 999 triliun IDR
- Contoh: Rp 1.728.000.000 (total semua sales)
```

### Sample Data
- **Products**: 30 produk elektronik Indonesia
- **Sales**: 90 transaksi (Jan-Jun 2024)
- **Total Sales**: ~1.7 miliar IDR
- **MongoDB**: 5 customers, 7 interactions

## 🚀 Quick Start Options

### Option 1: Automated Fix (Recommended)
```bash
./fix-database.sh
```
**Features:**
- Complete system detection
- Dependency verification
- Network connectivity testing
- Database setup dengan timeout handling
- Endpoint testing dengan multiple HTTP clients
- Performance monitoring

### Option 2: Manual Setup
```bash
npm install
node setup-postgres-auto.js  # Enhanced dengan Linux system info
node setup-mongodb.js
./demo.sh start
```

### Option 3: Production Service
```bash
./install-service.sh         # Install systemd user service
systemctl --user start node-demo
systemctl --user enable node-demo
journalctl --user -f -u node-demo  # Monitor logs
```

## 📦 File Structure Enhancements

```
linux-dd-simple/
├── fix-database.sh           ← Linux optimized dengan error handling
├── setup-postgres-auto.js    ← Enhanced dengan system monitoring
├── install-service.sh        ← systemd service installer
├── node-demo.service         ← systemd service definition
├── setup-databases.sql       ← Fixed decimal precision
├── README-LINUX.md          ← Comprehensive Linux documentation
├── LINUX-SETUP-SUMMARY.md  ← This file
└── Original files from unix-dd-simple...
```

## 🛠️ Linux Distribution Support

### Ubuntu/Debian
```bash
sudo apt update && sudo apt install nodejs npm curl
./fix-database.sh
```

### CentOS/RHEL
```bash
sudo yum install nodejs npm curl  # or dnf on newer versions
./fix-database.sh
```

### Fedora
```bash
sudo dnf install nodejs npm curl
./fix-database.sh
```

### Arch Linux
```bash
sudo pacman -S nodejs npm curl
./fix-database.sh
```

### openSUSE
```bash
sudo zypper install nodejs npm curl
./fix-database.sh
```

### Alpine Linux
```bash
sudo apk add nodejs npm curl
./fix-database.sh
```

## 🔧 Enhanced Features vs Unix Version

| Feature | Unix DD Simple | Linux DD Simple |
|---------|---------------|-----------------|
| Color Support | Basic ANSI | Advanced tput detection |
| Error Handling | Basic | Comprehensive dengan exit codes |
| System Info | Minimal | Full distribution detection |
| Service Management | Manual only | systemd integration |
| Monitoring | None | Real-time performance metrics |
| Network Testing | curl only | curl/wget/python3 fallback |
| Documentation | Basic | Distribution-specific guides |
| Security | None | systemd security hardening |
| Installation | Manual deps | Package manager detection |

## 🌐 API Endpoints dengan Linux Testing

| Endpoint | Description | Linux Test Command |
|----------|-------------|-------------------|
| `/api/health` | Health check | `curl -s http://localhost:3000/api/health \| jq` |
| `/api/postgres/sales` | PostgreSQL data | `wget -qO- http://localhost:3000/api/postgres/sales` |
| `/api/postgres/monthly-sales` | Sales trends | `curl http://localhost:3000/api/postgres/monthly-sales` |
| `/api/mongodb/customers` | MongoDB data | `python3 -c "import urllib.request; print(urllib.request.urlopen('http://localhost:3000/api/mongodb/customers').read().decode())"` |
| `/api/mongodb/interactions` | Interactions | `curl http://localhost:3000/api/mongodb/interactions` |
| `/api/combined/dashboard` | Combined analytics | `curl http://localhost:3000/api/combined/dashboard` |

## 🔐 Security Enhancements Linux

### systemd Security Features
```ini
# Built into node-demo.service
NoNewPrivileges=true     # Prevent privilege escalation
PrivateTmp=true         # Isolated /tmp directory
ProtectHome=true        # Protect /home directories
ProtectSystem=strict    # Read-only system directories
LimitNOFILE=65536      # File descriptor limits
LimitNPROC=4096        # Process limits
```

### File Permissions
```bash
# Proper executable permissions
chmod +x *.sh           # Shell scripts
chmod 644 *.js *.json   # JavaScript dan config files
chmod 644 *.md          # Documentation
```

## 📊 Performance Monitoring Linux

### Real-time Monitoring Commands
```bash
# System resources
htop                    # Interactive process viewer
top                     # Traditional process viewer
free -h                 # Memory usage
df -h                   # Disk usage

# Service monitoring
systemctl --user status node-demo
journalctl --user -f -u node-demo

# Network monitoring
netstat -tlnp | grep :3000
ss -tlnp | grep :3000

# Load monitoring
uptime
cat /proc/loadavg
cat /proc/meminfo | head -10
```

### Built-in Performance Info
Script `fix-database.sh` otomatis menampilkan:
- Distribution dan kernel version
- Memory usage (available/total)
- Load average (1min, 5min, 15min)
- Network connectivity status

## 🐛 Linux Troubleshooting Guide

### Common Issues & Solutions

#### 1. Package Installation Issues
```bash
# Ubuntu/Debian: GPG key issues
sudo apt-key adv --keyserver keyserver.ubuntu.com --recv-keys [KEY_ID]

# CentOS/RHEL: Repository issues
sudo yum clean all && sudo yum update

# Arch: Package conflicts
sudo pacman -Syu && sudo pacman -S nodejs npm
```

#### 2. Firewall Issues
```bash
# Check Ubuntu/Debian firewall
sudo ufw status
sudo ufw allow 3000/tcp

# Check CentOS/RHEL firewall
sudo firewall-cmd --list-all
sudo firewall-cmd --permanent --add-port=3000/tcp
sudo firewall-cmd --reload
```

#### 3. DNS Resolution Issues
```bash
# Check DNS configuration
cat /etc/resolv.conf
systemd-resolve --status

# Test DNS
nslookup ep-falling-cake-a1j2rvpd-pooler.ap-southeast-1.aws.neon.tech
dig +short ep-falling-cake-a1j2rvpd-pooler.ap-southeast-1.aws.neon.tech
```

#### 4. systemd Service Issues
```bash
# Check service logs
journalctl --user -u node-demo --no-pager
journalctl --user -u node-demo -f

# Reload service
systemctl --user daemon-reload
systemctl --user restart node-demo

# Check service file
cat ~/.config/systemd/user/node-demo.service
```

## 🚀 Production Deployment Linux

### 1. systemd User Service (Recommended)
```bash
# Install service
./install-service.sh

# Enable autostart
systemctl --user enable node-demo

# Start service
systemctl --user start node-demo

# Monitor
journalctl --user -f -u node-demo
```

### 2. PM2 Process Manager
```bash
npm install -g pm2
pm2 start server.js --name "linux-dd-simple"
pm2 startup  # Auto-start on boot
pm2 save
```

### 3. Docker/Podman Container
```bash
# Docker
docker-compose up -d

# Podman (rootless)
podman-compose up -d
```

### 4. nginx Reverse Proxy
```bash
# Install nginx
sudo apt install nginx  # Ubuntu/Debian
sudo yum install nginx  # CentOS/RHEL

# Configure proxy
sudo nano /etc/nginx/sites-available/default
# Add proxy_pass http://localhost:3000;
```

## 📈 Performance Optimization Linux

### 1. System Level Optimizations
```bash
# Increase file descriptor limits
echo "* soft nofile 65536" | sudo tee -a /etc/security/limits.conf
echo "* hard nofile 65536" | sudo tee -a /etc/security/limits.conf

# TCP optimizations
echo "net.core.somaxconn = 65536" | sudo tee -a /etc/sysctl.conf
sudo sysctl -p
```

### 2. Node.js Optimizations
```bash
# Production environment
export NODE_ENV=production

# Memory optimization
export NODE_OPTIONS="--max-old-space-size=2048"

# Enable clustering
# Modify server.js to use cluster module
```

## 🔄 Testing & Validation

### Automated Testing (dalam fix-database.sh)
1. ✅ **System Detection**: Distribution, kernel, architecture
2. ✅ **Prerequisites**: Node.js, npm, network connectivity  
3. ✅ **Database Setup**: PostgreSQL + MongoDB dengan timeout
4. ✅ **Endpoint Testing**: Semua 6 API endpoints
5. ✅ **Performance Check**: Memory, load average, process status

### Manual Testing Commands
```bash
# Test all endpoints
curl -s http://localhost:3000/api/health | jq
curl -s http://localhost:3000/api/postgres/sales | jq '. | length'
curl -s http://localhost:3000/api/mongodb/customers | jq '. | length'
curl -s http://localhost:3000/api/combined/dashboard | jq '.summary'

# Performance testing
ab -n 100 -c 10 http://localhost:3000/api/health  # Apache bench
wrk -t4 -c100 -d30s http://localhost:3000/api/health  # wrk tool
```

## 💾 Backup & Recovery Linux

### Database Backup
```bash
# PostgreSQL (if running locally)
pg_dump -h localhost -U postgres neondb > backup.sql

# MongoDB (if running locally)  
mongodump --db atlasdb --out ./mongodb_backup
```

### Application Backup
```bash
# Full application backup
tar -czf linux-dd-simple-backup.tar.gz linux-dd-simple/

# Configuration backup
cp ~/.config/systemd/user/node-demo.service ~/node-demo.service.backup
```

## 📞 Linux Support Resources

### Documentation
- 📖 **README-LINUX.md**: Comprehensive Linux guide
- 📖 **LINUX-SETUP-SUMMARY.md**: This summary (overview)
- 📖 **DATABASE-FIX.md**: Database troubleshooting guide

### Linux Communities
- **Ubuntu**: https://askubuntu.com/
- **Debian**: https://forums.debian.net/
- **CentOS**: https://forums.centos.org/
- **Fedora**: https://ask.fedoraproject.org/
- **Arch**: https://bbs.archlinux.org/

### Commands untuk Help
```bash
# System information
uname -a                    # Kernel info
lsb_release -a             # Distribution info
cat /etc/os-release        # Detailed OS info
lscpu                      # CPU information
free -h                    # Memory information

# Service debugging
systemctl --user status node-demo
journalctl --user -u node-demo --since "1 hour ago"
```

---

## 🎯 Summary

**Linux DD Simple** adalah versi yang sangat enhanced dari unix-dd-simple dengan:

✅ **Advanced Linux Integration** - systemd, journalctl, distribution detection  
✅ **Enhanced Error Handling** - Comprehensive troubleshooting dan recovery  
✅ **Production Ready** - Security hardening, resource limits, monitoring  
✅ **Multi-Distribution Support** - Ubuntu, Debian, CentOS, Fedora, Arch, openSUSE  
✅ **Performance Optimized** - Real-time monitoring, load balancing ready  
✅ **Developer Friendly** - Rich documentation, automated testing, one-command setup  

**Quick Start:** `./fix-database.sh`  
**Production:** `./install-service.sh`  
**Monitor:** `journalctl --user -f -u node-demo`  

🐧 **Happy Coding on Linux!** 