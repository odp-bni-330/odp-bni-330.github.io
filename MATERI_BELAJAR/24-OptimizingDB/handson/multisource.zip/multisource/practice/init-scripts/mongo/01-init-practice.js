// Initialize practice database for MongoDB
// Collections: customers, interactions

// Switch to practice database
db = db.getSiblingDB('ecommerce_practice');

// Create practice user
db.createUser({
  user: 'practice_user',
  pwd: 'practice_pass',
  roles: [
    {
      role: 'readWrite',
      db: 'ecommerce_practice'
    }
  ]
});

// Insert customer data with detailed profiles
db.customers.insertMany([
  {
    customer_id: 1,
    name: "John Doe",
    email: "john.doe@email.com",
    phone: "+62-812-3456-7890",
    demographics: {
      age: 28,
      gender: "Male",
      occupation: "Software Engineer",
      income_level: "High"
    },
    location: {
      address: "Jl. Sudirman No. 1",
      city: "Jakarta",
      country: "Indonesia",
      coordinates: [-6.2088, 106.8456],
      timezone: "Asia/Jakarta"
    },
    registration_date: new Date("2023-01-15"),
    last_login: new Date("2024-03-01T10:30:00Z"),
    status: "active",
    preferences: {
      categories: ["Electronics", "Books", "Technology"],
      newsletter: true,
      language: "Indonesian",
      currency: "IDR"
    },
    loyalty_program: {
      tier: "Gold",
      points: 15000,
      joined_date: new Date("2023-06-01")
    }
  },
  {
    customer_id: 2,
    name: "Jane Smith",
    email: "jane.smith@email.com",
    phone: "+62-813-4567-8901",
    demographics: {
      age: 32,
      gender: "Female",
      occupation: "Marketing Manager",
      income_level: "High"
    },
    location: {
      address: "Jl. Thamrin No. 2",
      city: "Jakarta",
      country: "Indonesia",
      coordinates: [-6.1944, 106.8229],
      timezone: "Asia/Jakarta"
    },
    registration_date: new Date("2023-02-10"),
    last_login: new Date("2024-02-28T15:45:00Z"),
    status: "active",
    preferences: {
      categories: ["Fashion", "Health", "Beauty"],
      newsletter: true,
      language: "Indonesian",
      currency: "IDR"
    },
    loyalty_program: {
      tier: "Silver",
      points: 8500,
      joined_date: new Date("2023-05-15")
    }
  },
  {
    customer_id: 3,
    name: "Michael Johnson",
    email: "michael.johnson@email.com",
    phone: "+62-814-5678-9012",
    demographics: {
      age: 35,
      gender: "Male",
      occupation: "Business Owner",
      income_level: "High"
    },
    location: {
      address: "Jl. Asia Afrika No. 3",
      city: "Bandung",
      country: "Indonesia",
      coordinates: [-6.9175, 107.6191],
      timezone: "Asia/Jakarta"
    },
    registration_date: new Date("2023-03-05"),
    last_login: new Date("2024-02-29T09:20:00Z"),
    status: "active",
    preferences: {
      categories: ["Electronics", "Sports", "Automotive"],
      newsletter: false,
      language: "Indonesian",
      currency: "IDR"
    },
    loyalty_program: {
      tier: "Platinum",
      points: 25000,
      joined_date: new Date("2023-04-01")
    }
  },
  {
    customer_id: 4,
    name: "Sarah Wilson",
    email: "sarah.wilson@email.com",
    phone: "+62-815-6789-0123",
    demographics: {
      age: 27,
      gender: "Female",
      occupation: "Teacher",
      income_level: "Medium"
    },
    location: {
      address: "Jl. Gatot Subroto No. 4",
      city: "Medan",
      country: "Indonesia",
      coordinates: [3.5952, 98.6722],
      timezone: "Asia/Jakarta"
    },
    registration_date: new Date("2023-04-12"),
    last_login: new Date("2024-02-27T14:15:00Z"),
    status: "active",
    preferences: {
      categories: ["Fashion", "Books", "Education"],
      newsletter: true,
      language: "Indonesian",
      currency: "IDR"
    },
    loyalty_program: {
      tier: "Bronze",
      points: 3200,
      joined_date: new Date("2023-08-10")
    }
  },
  {
    customer_id: 5,
    name: "David Brown",
    email: "david.brown@email.com",
    phone: "+62-816-7890-1234",
    demographics: {
      age: 41,
      gender: "Male",
      occupation: "Doctor",
      income_level: "High"
    },
    location: {
      address: "Jl. Malioboro No. 5",
      city: "Yogyakarta",
      country: "Indonesia",
      coordinates: [-7.7956, 110.3695],
      timezone: "Asia/Jakarta"
    },
    registration_date: new Date("2023-05-20"),
    last_login: new Date("2024-02-26T11:30:00Z"),
    status: "active",
    preferences: {
      categories: ["Sports", "Health", "Medical"],
      newsletter: true,
      language: "Indonesian",
      currency: "IDR"
    },
    loyalty_program: {
      tier: "Gold",
      points: 12800,
      joined_date: new Date("2023-07-01")
    }
  },
  {
    customer_id: 6,
    name: "Lisa Anderson",
    email: "lisa.anderson@email.com",
    phone: "+62-817-8901-2345",
    demographics: {
      age: 29,
      gender: "Female",
      occupation: "Graphic Designer",
      income_level: "Medium"
    },
    location: {
      address: "Jl. Pemuda No. 6",
      city: "Semarang",
      country: "Indonesia",
      coordinates: [-6.9667, 110.4167],
      timezone: "Asia/Jakarta"
    },
    registration_date: new Date("2023-06-08"),
    last_login: new Date("2024-02-25T16:45:00Z"),
    status: "active",
    preferences: {
      categories: ["Books", "Home", "Art"],
      newsletter: false,
      language: "Indonesian",
      currency: "IDR"
    },
    loyalty_program: {
      tier: "Silver",
      points: 6400,
      joined_date: new Date("2023-09-01")
    }
  },
  {
    customer_id: 7,
    name: "Robert Taylor",
    email: "robert.taylor@email.com",
    phone: "+62-818-9012-3456",
    demographics: {
      age: 33,
      gender: "Male",
      occupation: "Architect",
      income_level: "High"
    },
    location: {
      address: "Jl. Ijen No. 7",
      city: "Malang",
      country: "Indonesia",
      coordinates: [-7.9797, 112.6304],
      timezone: "Asia/Jakarta"
    },
    registration_date: new Date("2023-07-15"),
    last_login: new Date("2024-02-24T13:20:00Z"),
    status: "active",
    preferences: {
      categories: ["Electronics", "Home", "Design"],
      newsletter: true,
      language: "Indonesian",
      currency: "IDR"
    },
    loyalty_program: {
      tier: "Gold",
      points: 11200,
      joined_date: new Date("2023-10-01")
    }
  },
  {
    customer_id: 8,
    name: "Emily Davis",
    email: "emily.davis@email.com",
    phone: "+62-819-0123-4567",
    demographics: {
      age: 26,
      gender: "Female",
      occupation: "Yoga Instructor",
      income_level: "Medium"
    },
    location: {
      address: "Jl. Sunset Road No. 8",
      city: "Denpasar",
      country: "Indonesia",
      coordinates: [-8.6500, 115.2167],
      timezone: "Asia/Makassar"
    },
    registration_date: new Date("2023-08-22"),
    last_login: new Date("2024-02-23T12:10:00Z"),
    status: "active",
    preferences: {
      categories: ["Fashion", "Sports", "Health"],
      newsletter: true,
      language: "Indonesian",
      currency: "IDR"
    },
    loyalty_program: {
      tier: "Bronze",
      points: 4800,
      joined_date: new Date("2023-11-01")
    }
  },
  {
    customer_id: 9,
    name: "Christopher Miller",
    email: "christopher.miller@email.com",
    phone: "+62-820-1234-5678",
    demographics: {
      age: 38,
      gender: "Male",
      occupation: "Nutritionist",
      income_level: "Medium"
    },
    location: {
      address: "Jl. Sam Ratulangi No. 9",
      city: "Makassar",
      country: "Indonesia",
      coordinates: [-5.1477, 119.4327],
      timezone: "Asia/Makassar"
    },
    registration_date: new Date("2023-09-10"),
    last_login: new Date("2024-02-22T17:30:00Z"),
    status: "active",
    preferences: {
      categories: ["Health", "Books", "Nutrition"],
      newsletter: false,
      language: "Indonesian",
      currency: "IDR"
    },
    loyalty_program: {
      tier: "Silver",
      points: 7600,
      joined_date: new Date("2023-12-01")
    }
  },
  {
    customer_id: 10,
    name: "Amanda Wilson",
    email: "amanda.wilson@email.com",
    phone: "+62-821-2345-6789",
    demographics: {
      age: 31,
      gender: "Female",
      occupation: "Interior Designer",
      income_level: "High"
    },
    location: {
      address: "Jl. Sudirman No. 10",
      city: "Palembang",
      country: "Indonesia",
      coordinates: [-2.9167, 104.7458],
      timezone: "Asia/Jakarta"
    },
    registration_date: new Date("2023-10-05"),
    last_login: new Date("2024-02-21T08:45:00Z"),
    status: "active",
    preferences: {
      categories: ["Home", "Electronics", "Design"],
      newsletter: true,
      language: "Indonesian",
      currency: "IDR"
    },
    loyalty_program: {
      tier: "Gold",
      points: 9800,
      joined_date: new Date("2024-01-01")
    }
  },
  {
    customer_id: 11,
    name: "James Moore",
    email: "james.moore@email.com",
    phone: "+62-822-3456-7890",
    demographics: {
      age: 45,
      gender: "Male",
      occupation: "CEO",
      income_level: "Very High"
    },
    location: {
      address: "Jl. MH Thamrin No. 11",
      city: "Jakarta",
      country: "Indonesia",
      coordinates: [-6.2088, 106.8456],
      timezone: "Asia/Jakarta"
    },
    registration_date: new Date("2023-11-12"),
    last_login: new Date("2024-02-20T19:15:00Z"),
    status: "active",
    preferences: {
      categories: ["Electronics", "Sports", "Luxury"],
      newsletter: true,
      language: "Indonesian",
      currency: "IDR"
    },
    loyalty_program: {
      tier: "Platinum",
      points: 35000,
      joined_date: new Date("2023-11-15")
    }
  },
  {
    customer_id: 12,
    name: "Michelle Garcia",
    email: "michelle.garcia@email.com",
    phone: "+62-823-4567-8901",
    demographics: {
      age: 24,
      gender: "Female",
      occupation: "Student",
      income_level: "Low"
    },
    location: {
      address: "Jl. Basuki Rahmat No. 12",
      city: "Surabaya",
      country: "Indonesia",
      coordinates: [-7.2575, 112.7521],
      timezone: "Asia/Jakarta"
    },
    registration_date: new Date("2023-12-01"),
    last_login: new Date("2024-02-19T10:30:00Z"),
    status: "active",
    preferences: {
      categories: ["Fashion", "Health", "Education"],
      newsletter: false,
      language: "Indonesian",
      currency: "IDR"
    },
    loyalty_program: {
      tier: "Bronze",
      points: 1200,
      joined_date: new Date("2024-01-15")
    }
  }
]);

// Insert interaction data (website visits, email opens, support tickets, etc.)
db.interactions.insertMany([
  // Customer 1 interactions
  {
    interaction_id: 1,
    customer_id: 1,
    type: "website_visit",
    timestamp: new Date("2024-02-28T10:00:00Z"),
    details: {
      page: "/products/electronics",
      duration_seconds: 180,
      source: "google",
      device: "desktop"
    }
  },
  {
    interaction_id: 2,
    customer_id: 1,
    type: "email_open",
    timestamp: new Date("2024-02-27T09:30:00Z"),
    details: {
      campaign: "weekly_deals",
      subject: "Special Electronics Sale",
      email_type: "promotional"
    }
  },
  {
    interaction_id: 3,
    customer_id: 1,
    type: "purchase",
    timestamp: new Date("2024-01-15T14:30:00Z"),
    details: {
      order_id: 1,
      amount: 2999.99,
      products: ["MacBook Pro 14\""],
      payment_method: "credit_card"
    }
  },
  // Customer 2 interactions
  {
    interaction_id: 4,
    customer_id: 2,
    type: "website_visit",
    timestamp: new Date("2024-02-26T15:20:00Z"),
    details: {
      page: "/products/fashion",
      duration_seconds: 240,
      source: "direct",
      device: "mobile"
    }
  },
  {
    interaction_id: 5,
    customer_id: 2,
    type: "cart_abandonment",
    timestamp: new Date("2024-02-25T16:45:00Z"),
    details: {
      cart_value: 299.99,
      products: ["Nike Air Max 270", "Yoga Mat Premium"],
      abandonment_stage: "checkout"
    }
  },
  {
    interaction_id: 6,
    customer_id: 2,
    type: "email_click",
    timestamp: new Date("2024-02-24T11:15:00Z"),
    details: {
      campaign: "abandoned_cart",
      link_clicked: "return_to_cart",
      email_type: "retargeting"
    }
  },
  // Customer 3 interactions
  {
    interaction_id: 7,
    customer_id: 3,
    type: "support_ticket",
    timestamp: new Date("2024-02-20T13:00:00Z"),
    details: {
      ticket_id: "SUPP-001",
      category: "product_inquiry",
      status: "resolved",
      resolution_time_hours: 2
    }
  },
  {
    interaction_id: 8,
    customer_id: 3,
    type: "product_review",
    timestamp: new Date("2024-02-18T10:30:00Z"),
    details: {
      product_id: 3,
      rating: 5,
      review_text: "Excellent smartphone, very satisfied!",
      verified_purchase: true
    }
  },
  // Customer 4 interactions
  {
    interaction_id: 9,
    customer_id: 4,
    type: "wishlist_add",
    timestamp: new Date("2024-02-15T14:20:00Z"),
    details: {
      product_id: 7,
      product_name: "The Great Gatsby",
      category: "Books"
    }
  },
  {
    interaction_id: 10,
    customer_id: 4,
    type: "newsletter_signup",
    timestamp: new Date("2024-02-10T09:45:00Z"),
    details: {
      subscription_type: "weekly_deals",
      source: "website_popup"
    }
  },
  // Customer 5 interactions
  {
    interaction_id: 11,
    customer_id: 5,
    type: "app_download",
    timestamp: new Date("2024-02-05T16:30:00Z"),
    details: {
      platform: "android",
      version: "1.2.3",
      install_source: "google_play"
    }
  },
  {
    interaction_id: 12,
    customer_id: 5,
    type: "loyalty_points_redemption",
    timestamp: new Date("2024-01-30T11:20:00Z"),
    details: {
      points_used: 5000,
      reward: "10% discount coupon",
      coupon_code: "LOYAL10"
    }
  },
  // Additional interactions for other customers
  {
    interaction_id: 13,
    customer_id: 6,
    type: "social_media_share",
    timestamp: new Date("2024-02-12T13:45:00Z"),
    details: {
      platform: "instagram",
      content_type: "product_photo",
      product_id: 9,
      engagement: "high"
    }
  },
  {
    interaction_id: 14,
    customer_id: 7,
    type: "live_chat",
    timestamp: new Date("2024-02-08T15:30:00Z"),
    details: {
      duration_minutes: 15,
      topic: "shipping_inquiry",
      satisfaction_rating: 4.5
    }
  },
  {
    interaction_id: 15,
    customer_id: 8,
    type: "referral",
    timestamp: new Date("2024-01-25T10:15:00Z"),
    details: {
      referred_customer_id: 12,
      referral_code: "REF-EMILY123",
      reward_earned: "500 points"
    }
  }
]);

// Create indexes for better performance
db.customers.createIndex({ "customer_id": 1 });
db.customers.createIndex({ "email": 1 });
db.customers.createIndex({ "location.city": 1 });
db.customers.createIndex({ "demographics.age": 1 });
db.customers.createIndex({ "loyalty_program.tier": 1 });
db.customers.createIndex({ "preferences.categories": 1 });

db.interactions.createIndex({ "customer_id": 1 });
db.interactions.createIndex({ "type": 1 });
db.interactions.createIndex({ "timestamp": 1 });
db.interactions.createIndex({ "customer_id": 1, "type": 1 });

print("MongoDB practice database initialization completed successfully!");
print("Created collections: customers, interactions");
print("Total customers: " + db.customers.countDocuments());
print("Total interactions: " + db.interactions.countDocuments()); 