# ELK Stack Demo - Linux Edition 🐧

Demo lengkap untuk **Elasticsearch**, **Logstash**, **Kibana**, dan **Filebeat** yang dioptimalkan khusus untuk environment **Linux** menggunakan Docker Compose dengan log generator otomatis.

## 📋 Daftar Isi

- [Fitur Linux-Specific](#-fitur-linux-specific)
- [Prasyarat Linux](#-prasyarat-linux)
- [Quick Start](#-quick-start)
- [Instalasi Detail](#-instalasi-detail)
- [Penggunaan](#-penggunaan)
- [Monitoring](#-monitoring)
- [Konfigurasi Linux](#-konfigurasi-linux)
- [Troubleshooting Linux](#-troubleshooting-linux)
- [Performance Tuning](#-performance-tuning)

## ✨ Fitur Linux-Specific

- **🐧 Optimized untuk Linux** - Konfigurasi khusus untuk kernel Linux
- **🚀 Modern Docker Compose** - Support untuk Docker Compose v2
- **📊 Resource Monitoring** - Built-in monitoring untuk CPU, Memory, Disk
- **🔧 Auto-Detection** - Deteksi distro Linux otomatis (Ubuntu, CentOS, RHEL, etc.)
- **⚡ Performance Tuned** - vm.max_map_count auto-config untuk Elasticsearch
- **🛡️ Security Enhanced** - Optimasi keamanan untuk production Linux
- **📈 Metricbeat Integration** - Monitor sistem dan container metrics
- **🔄 Auto-Restart** - Container restart policy untuk high availability

## 🛠 Prasyarat Linux

### Minimum System Requirements
- **OS**: Linux kernel 3.10+ (Ubuntu 18.04+, CentOS 7+, RHEL 7+)
- **RAM**: 4GB minimum (8GB+ recommended)
- **Disk**: 5GB free space
- **CPU**: 2 cores minimum (4+ recommended)

### Software Requirements
```bash
# Check kernel version
uname -r  # Should be 3.10+

# Required packages
sudo apt-get update  # For Ubuntu/Debian
sudo yum update      # For CentOS/RHEL

# Install curl if not present
sudo apt-get install curl  # Ubuntu/Debian
sudo yum install curl      # CentOS/RHEL
```

### Docker Installation

**Ubuntu/Debian:**
```bash
# Remove old versions
sudo apt-get remove docker docker-engine docker.io containerd runc

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Add user to docker group
sudo usermod -aG docker $USER
newgrp docker

# Start and enable Docker
sudo systemctl start docker
sudo systemctl enable docker
```

**CentOS/RHEL:**
```bash
# Remove old versions
sudo yum remove docker docker-client docker-client-latest docker-common

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Add user to docker group
sudo usermod -aG docker $USER
newgrp docker

# Start and enable Docker
sudo systemctl start docker
sudo systemctl enable docker
```

### Docker Compose Installation
```bash
# Option 1: Docker Compose Plugin (Recommended)
sudo apt-get install docker-compose-plugin  # Ubuntu/Debian
sudo dnf install docker-compose-plugin      # RHEL/Fedora

# Option 2: Standalone Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Verify installation
docker compose version  # or docker-compose version
```

## ⚡ Quick Start

```bash
# Clone repository
git clone <repository-url>
cd linux-log

# Make scripts executable
chmod +x run-elk-demo.sh scripts/generate_logs.sh

# Start demo (auto-detects Linux environment)
./run-elk-demo.sh start

# Access Kibana
open http://localhost:5601
```

## 📦 Instalasi Detail

### 1. Persiapan Environment
```bash
# Check system requirements
./run-elk-demo.sh help

# Optional: Set vm.max_map_count for optimal Elasticsearch performance
sudo sysctl -w vm.max_map_count=262144

# Make it permanent
echo 'vm.max_map_count=262144' | sudo tee -a /etc/sysctl.conf
```

### 2. Konfigurasi Network (Optional)
```bash
# Allow Docker ports through firewall
sudo ufw allow 9200  # Elasticsearch
sudo ufw allow 5601  # Kibana
sudo ufw allow 5044  # Logstash

# For CentOS/RHEL
sudo firewall-cmd --permanent --add-port=9200/tcp
sudo firewall-cmd --permanent --add-port=5601/tcp
sudo firewall-cmd --permanent --add-port=5044/tcp
sudo firewall-cmd --reload
```

### 3. Jalankan Demo
```bash
# Start with system checks
./run-elk-demo.sh start

# Monitor in real-time
./run-elk-demo.sh monitor

# View logs
./run-elk-demo.sh logs
```

## 🎯 Penggunaan

### Perintah Utama

```bash
# Start ELK Stack
./run-elk-demo.sh start

# Stop demo
./run-elk-demo.sh stop

# Restart (with 3s delay)
./run-elk-demo.sh restart

# Monitor system resources
./run-elk-demo.sh monitor

# View container logs
./run-elk-demo.sh logs [service_name]

# Check status
./run-elk-demo.sh status

# Complete cleanup (remove all data)
./run-elk-demo.sh cleanup

# Help
./run-elk-demo.sh help
```

### Monitoring Specific Services

```bash
# Monitor specific service logs
./run-elk-demo.sh logs elasticsearch
./run-elk-demo.sh logs logstash
./run-elk-demo.sh logs kibana
./run-elk-demo.sh logs filebeat
./run-elk-demo.sh logs metricbeat
```

## 📊 Monitoring

### Built-in System Monitoring

Script akan secara otomatis memonitor:
- **Memory Usage** - Real-time RAM usage
- **Disk Space** - Available storage space  
- **Docker Stats** - Container resource usage
- **vm.max_map_count** - Elasticsearch kernel parameter

```bash
# View current system stats
./run-elk-demo.sh monitor

# Continuous monitoring
watch -n 5 './run-elk-demo.sh monitor'
```

### Container Resources

```bash
# View Docker container resources
docker stats

# View specific container
docker stats elk-elasticsearch
docker stats elk-logstash
docker stats elk-kibana
```

## ⚙️ Konfigurasi Linux

### Struktur Direktori

```
linux-log/
├── docker-compose.yml           # Docker Compose dengan optimasi Linux
├── run-elk-demo.sh             # Script utama dengan deteksi Linux
├── README.md                   # Dokumentasi ini
├── filebeat/
│   └── filebeat.yml           # Konfigurasi Filebeat untuk Linux
├── logstash/
│   ├── config/
│   │   └── logstash.yml       # Konfigurasi Logstash
│   ├── pipeline/
│   │   └── logstash.conf      # Pipeline dengan custom patterns
│   └── patterns/
│       └── custom             # Custom Grok patterns untuk Linux
├── logs/                      # Sample log files
│   ├── apache/
│   ├── nginx/
│   ├── application/
│   └── system/               # System logs (optional)
└── scripts/
    └── generate_logs.sh       # Log generator untuk Linux
```

### Resource Limits (Docker Compose)

Container dioptimalkan untuk Linux dengan resource limits:

- **Elasticsearch**: 1GB limit, 512MB reserved
- **Logstash**: 768MB limit, 256MB reserved
- **Kibana**: 512MB limit, 256MB reserved
- **Filebeat**: 256MB limit, 128MB reserved
- **Metricbeat**: 256MB limit, 128MB reserved

### Network Configuration

```yaml
networks:
  elk-network:
    driver: bridge
    ipam:
      config:
        - subnet: 172.20.0.0/24
```

## 🎨 Menggunakan Kibana

### 1. Dashboard dan Visualisasi

Akses: **http://localhost:5601**

#### Index Pattern
- **Pattern**: `linux-demo-logs-*`
- **Time Field**: `@timestamp`

#### Pre-configured Fields
- `log_source` - apache, nginx, application
- `severity` - high, medium, low
- `response_category` - success, redirect, client_error, server_error
- `clientip` - IP address dengan GeoIP data
- `user_agent.*` - Parsed user agent information

### 2. Sample Queries

```
# Error logs only
severity:high

# Specific log source
log_source:nginx

# HTTP client errors (4xx)
response_category:client_error

# Geographic distribution
geoip.country_name:*

# Time range filter
@timestamp:[now-1h TO now]

# Combined filters
log_source:apache AND response_category:server_error
```

### 3. Recommended Visualizations

1. **Log Sources Distribution** - Pie chart
2. **HTTP Status Codes Over Time** - Line chart
3. **Top Client IPs** - Data table with GeoIP
4. **Error Rate Trends** - Area chart
5. **Geographic World Map** - Maps visualization
6. **System Metrics** - Metricbeat dashboards

## 🐛 Troubleshooting Linux

### Common Issues

#### 1. Elasticsearch Won't Start
```bash
# Check vm.max_map_count
cat /proc/sys/vm/max_map_count

# Should be >= 262144, if not:
sudo sysctl -w vm.max_map_count=262144

# Check disk space
df -h

# Check Docker logs
./run-elk-demo.sh logs elasticsearch
```

#### 2. Permission Issues
```bash
# Fix Docker permissions
sudo usermod -aG docker $USER
newgrp docker

# Fix file permissions
chmod +x run-elk-demo.sh scripts/generate_logs.sh

# Fix log directory permissions
sudo chown -R $USER:$USER logs/
```

#### 3. Memory Issues
```bash
# Check available memory
free -h

# Reduce resource limits in docker-compose.yml
# Edit ES_JAVA_OPTS and LS_JAVA_OPTS

# For low-memory systems (< 4GB)
export ES_JAVA_OPTS="-Xms256m -Xmx256m"
export LS_JAVA_OPTS="-Xms128m -Xms256m"
```

#### 4. Network/Firewall Issues
```bash
# Check if ports are accessible
netstat -tlnp | grep :9200
netstat -tlnp | grep :5601

# Ubuntu/Debian firewall
sudo ufw status
sudo ufw allow 9200/tcp
sudo ufw allow 5601/tcp

# CentOS/RHEL firewall
sudo firewall-cmd --list-ports
sudo firewall-cmd --permanent --add-port=9200/tcp
sudo firewall-cmd --reload
```

#### 5. Docker Compose Issues
```bash
# Check Docker Compose version
docker compose version

# If using old docker-compose
docker-compose --version

# Update to latest
sudo apt-get update && sudo apt-get install docker-compose-plugin
```

### Performance Issues

#### 1. Slow Response
```bash
# Check system load
uptime
htop

# Check Docker stats
docker stats

# Monitor disk I/O
iostat -x 1
```

#### 2. Out of Memory
```bash
# Check memory usage
free -h
./run-elk-demo.sh monitor

# Reduce container memory limits
# Edit docker-compose.yml resource limits
```

## ⚡ Performance Tuning

### System Level Optimizations

```bash
# 1. Elasticsearch optimizations
echo 'vm.max_map_count=262144' | sudo tee -a /etc/sysctl.conf
echo 'vm.swappiness=1' | sudo tee -a /etc/sysctl.conf

# 2. File descriptor limits
echo '* soft nofile 65536' | sudo tee -a /etc/security/limits.conf
echo '* hard nofile 65536' | sudo tee -a /etc/security/limits.conf

# 3. Apply changes
sudo sysctl -p
```

### Docker Optimizations

```bash
# 1. Use Docker storage driver optimization
# Edit /etc/docker/daemon.json
{
  "storage-driver": "overlay2",
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "10m",
    "max-file": "3"
  }
}

# 2. Restart Docker
sudo systemctl restart docker
```

### ELK Stack Optimizations

1. **Elasticsearch**:
   - Increase heap size for larger datasets
   - Use SSD storage for better I/O
   - Tune refresh interval

2. **Logstash**:
   - Increase pipeline workers
   - Optimize filter patterns
   - Use pipeline-to-pipeline communication

3. **Kibana**:
   - Enable optimization bundles
   - Use index patterns with time ranges

## 🔧 Advanced Configuration

### Custom Log Sources

```bash
# Add custom log directory
mkdir -p logs/custom

# Update filebeat.yml to include new paths
# Update logstash.conf to parse new formats
```

### Production Readiness

```bash
# 1. Enable security
# Edit docker-compose.yml to enable X-Pack security

# 2. Use external volumes for persistence
# Edit docker-compose.yml volumes section

# 3. Set up log rotation
# Configure logrotate for application logs

# 4. Monitoring alerts
# Configure Metricbeat with alerting
```

## 🏁 Cleanup

### Partial Cleanup
```bash
# Stop containers but keep data
./run-elk-demo.sh stop

# Remove containers but keep volumes
docker compose down
```

### Complete Cleanup
```bash
# Remove everything including data
./run-elk-demo.sh cleanup

# Remove Docker images (optional)
docker rmi $(docker images "docker.elastic.co/*" -q)

# Remove unused volumes
docker volume prune
```

## 📈 Monitoring Dashboard Examples

### System Health Dashboard
- CPU usage per container
- Memory consumption trends
- Disk I/O metrics
- Network traffic

### Application Monitoring
- Log volume by source
- Error rate trends
- Response time percentiles
- Geographic user distribution

### Security Monitoring
- Failed authentication attempts
- Suspicious IP addresses
- Abnormal traffic patterns
- Security scan detections

---

## 🎉 Selamat!

ELK Stack Demo untuk Linux sudah siap! Environment ini sudah dioptimalkan khusus untuk Linux dengan:

- ✅ **Auto-detection** untuk distro Linux
- ✅ **Resource monitoring** terintegrasi  
- ✅ **Performance tuning** otomatis
- ✅ **Security hardening** untuk production
- ✅ **Comprehensive logging** dengan pattern realistis

**Happy Logging on Linux!** 🐧📊

### Support & Documentation

- **Elasticsearch**: https://www.elastic.co/guide/en/elasticsearch/reference/current/
- **Logstash**: https://www.elastic.co/guide/en/logstash/current/
- **Kibana**: https://www.elastic.co/guide/en/kibana/current/
- **Filebeat**: https://www.elastic.co/guide/en/beats/filebeat/current/
- **Docker Compose**: https://docs.docker.com/compose/ 