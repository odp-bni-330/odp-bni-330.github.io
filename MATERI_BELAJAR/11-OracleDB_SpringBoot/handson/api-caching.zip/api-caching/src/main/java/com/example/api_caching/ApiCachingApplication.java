/*
 * Written by : Bostang Palaguna
 * Date : 2025-05-28
 * File : ApiCachingApplication.java
 * Deskripsi : Main class dari aplikasi
 */

package com.example.api_caching; // package declaration

// import library
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;

/************************** MAIN CLASS dari aplikasi Spring Boot **************************/

@SpringBootApplication
// anotasi yang terdiri:
	// @Configuration → class sumber definisi bean Spring
	// @EnableAutoConfiguration → tambahkan bean bdskan aturan classpath
	// @ComponentScan → pindai komponen, config, services dalam paket

@EnableCaching // mengaktifkan mekanisme caching
	//
public class ApiCachingApplication { // deklarasi kelas utama aplikasi

	// metode utama yang akan dijalankan pertama kali ketika aplikasi dimulai
	public static void main(String[] args) {
		// Meluncurkan app
		SpringApplication.run(ApiCachingApplication.class, args);
	}

}
/************************** End of MAIN CLASS dari aplikasi Spring Boot *******************/