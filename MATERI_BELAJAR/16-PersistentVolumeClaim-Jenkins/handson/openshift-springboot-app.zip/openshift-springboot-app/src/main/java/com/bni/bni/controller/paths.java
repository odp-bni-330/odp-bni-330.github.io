package com.bni.bni.controller;

public interface paths {

}
