const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

// Database setup (in-memory for simplicity)
const db = new sqlite3.Database(':memory:');

db.serialize(() => {
    db.run("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, password TEXT)");
    db.run("INSERT INTO users (username, password) VALUES ('admin', 'password123')");
    db.run("INSERT INTO users (username, password) VALUES ('guest', 'guest123')");

    db.run("CREATE TABLE IF NOT EXISTS posts (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, content TEXT)");
    db.run("INSERT INTO posts (title, content) VALUES ('First Post', 'This is the first post.')");
});

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.set('view engine', 'ejs'); // Use EJS for rendering

// XSS Vulnerability
app.get('/xss', (req, res) => {
    const userInput = req.query.input || '';
    res.render('xss', { output: userInput });
});

// SQL Injection Vulnerability
app.get('/login', (req, res) => {
    res.render('login');
});

app.post('/login', (req, res) => {
    const username = req.body.username;
    const password = req.body.password;

    // INSECURE: Vulnerable to SQL Injection
    const query = `SELECT * FROM users WHERE username = '${username}' AND password = '${password}'`;

    db.get(query, (err, row) => {
        if (err) {
            console.error(err);
            res.send('Login failed due to database error.');
        } else if (row) {
            res.send(`Login successful for user: ${row.username}`);
        } else {
            res.send('Invalid username or password.');
        }
    });
});

app.listen(port, () => {
    console.log(`Vulnerable app listening at http://localhost:${port}`);
});