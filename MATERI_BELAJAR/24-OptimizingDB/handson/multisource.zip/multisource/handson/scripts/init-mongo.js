// Script inisialisasi untuk MongoDB

// Membuat user untuk database ecommerce
db.createUser({
  user: "ecommerce_user",
  pwd: "ecommerce_pass",
  roles: [
    { role: "readWrite", db: "ecommerce" }
  ]
});

// Menggunakan database ecommerce
db = db.getSiblingDB('ecommerce');

// Membuat collection product_reviews dan memasukkan data
db.product_reviews.insertMany([
  {
    "review_id": "r101",
    "product_id": 101,
    "customer_id": 2,
    "rating": 4.5,
    "review_text": "Great smartphone with excellent camera quality!",
    "review_date": new Date("2023-01-20"),
    "helpful_votes": 15,
    "verified_purchase": true
  },
  {
    "review_id": "r102",
    "product_id": 101,
    "customer_id": 4,
    "rating": 3.5,
    "review_text": "Good phone but battery life could be better.",
    "review_date": new Date("2023-01-25"),
    "helpful_votes": 8,
    "verified_purchase": true
  },
  {
    "review_id": "r103",
    "product_id": 102,
    "customer_id": 1,
    "rating": 5.0,
    "review_text": "Excellent laptop! Fast performance and great display.",
    "review_date": new Date("2023-02-02"),
    "helpful_votes": 20,
    "verified_purchase": true
  },
  {
    "review_id": "r104",
    "product_id": 103,
    "customer_id": 5,
    "rating": 4.0,
    "review_text": "Makes great coffee, easy to use.",
    "review_date": new Date("2023-02-05"),
    "helpful_votes": 12,
    "verified_purchase": true
  },
  {
    "review_id": "r105",
    "product_id": 104,
    "customer_id": 3,
    "rating": 4.5,
    "review_text": "Very comfortable running shoes, good support.",
    "review_date": new Date("2023-02-10"),
    "helpful_votes": 7,
    "verified_purchase": false
  },
  {
    "review_id": "r106",
    "product_id": 105,
    "customer_id": 2,
    "rating": 5.0,
    "review_text": "Amazing sound quality and comfortable fit!",
    "review_date": new Date("2023-02-15"),
    "helpful_votes": 18,
    "verified_purchase": true
  },
  {
    "review_id": "r107",
    "product_id": 101,
    "customer_id": 5,
    "rating": 4.0,
    "review_text": "Good value for money, but charging is slow.",
    "review_date": new Date("2023-02-20"),
    "helpful_votes": 5,
    "verified_purchase": true
  },
  {
    "review_id": "r108",
    "product_id": 102,
    "customer_id": 4,
    "rating": 4.5,
    "review_text": "Great for work and gaming. Keyboard is excellent.",
    "review_date": new Date("2023-02-25"),
    "helpful_votes": 10,
    "verified_purchase": true
  }
]);

// Membuat collection user_interactions dan memasukkan data
db.user_interactions.insertMany([
  {
    "interaction_id": "i101",
    "customer_id": 1,
    "product_id": 101,
    "interaction_type": "view",
    "timestamp": new Date("2023-01-08T10:15:00Z"),
    "duration_seconds": 120,
    "device": "mobile"
  },
  {
    "interaction_id": "i102",
    "customer_id": 1,
    "product_id": 102,
    "interaction_type": "view",
    "timestamp": new Date("2023-01-08T10:20:00Z"),
    "duration_seconds": 180,
    "device": "mobile"
  },
  {
    "interaction_id": "i103",
    "customer_id": 2,
    "product_id": 101,
    "interaction_type": "view",
    "timestamp": new Date("2023-01-12T14:30:00Z"),
    "duration_seconds": 90,
    "device": "desktop"
  },
  {
    "interaction_id": "i104",
    "customer_id": 2,
    "product_id": 102,
    "interaction_type": "add_to_cart",
    "timestamp": new Date("2023-01-12T14:35:00Z"),
    "device": "desktop"
  },
  {
    "interaction_id": "i105",
    "customer_id": 3,
    "product_id": 103,
    "interaction_type": "view",
    "timestamp": new Date("2023-01-15T09:10:00Z"),
    "duration_seconds": 60,
    "device": "mobile"
  },
  {
    "interaction_id": "i106",
    "customer_id": 3,
    "product_id": 103,
    "interaction_type": "add_to_cart",
    "timestamp": new Date("2023-01-15T09:12:00Z"),
    "device": "mobile"
  },
  {
    "interaction_id": "i107",
    "customer_id": 4,
    "product_id": 104,
    "interaction_type": "view",
    "timestamp": new Date("2023-01-20T16:45:00Z"),
    "duration_seconds": 150,
    "device": "tablet"
  },
  {
    "interaction_id": "i108",
    "customer_id": 4,
    "product_id": 103,
    "interaction_type": "view",
    "timestamp": new Date("2023-01-20T16:50:00Z"),
    "duration_seconds": 75,
    "device": "tablet"
  },
  {
    "interaction_id": "i109",
    "customer_id": 4,
    "product_id": 104,
    "interaction_type": "add_to_cart",
    "timestamp": new Date("2023-01-20T16:55:00Z"),
    "device": "tablet"
  },
  {
    "interaction_id": "i110",
    "customer_id": 5,
    "product_id": 102,
    "interaction_type": "view",
    "timestamp": new Date("2023-01-25T11:20:00Z"),
    "duration_seconds": 200,
    "device": "desktop"
  },
  {
    "interaction_id": "i111",
    "customer_id": 5,
    "product_id": 105,
    "interaction_type": "view",
    "timestamp": new Date("2023-01-25T11:25:00Z"),
    "duration_seconds": 100,
    "device": "desktop"
  },
  {
    "interaction_id": "i112",
    "customer_id": 5,
    "product_id": 102,
    "interaction_type": "add_to_cart",
    "timestamp": new Date("2023-01-25T11:30:00Z"),
    "device": "desktop"
  }
]);