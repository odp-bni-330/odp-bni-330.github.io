package com.bni.taskmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.bni.taskmanagement.model.Task;
import com.bni.taskmanagement.service.TaskService;

import org.springframework.http.HttpStatus;


/*************************** LAYER CONTROLLER ***************************/

@RestController // menandakan bahwa file TaskController.java adalah presentation layer 
@RequestMapping("/api/tasks")   // assign end-point
public class TaskController {
    private final TaskService taskService;

    // @Autowired
    public TaskController(TaskService taskService) {
        this.taskService = taskService;
    }

    // CREATE
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Task createTask(@RequestBody Task task) {
        return taskService.createTask(task);
    }

    // READ ALL
    @GetMapping
    public List<Task> getAllTasks() {
        return taskService.getAllTasks();
    }

    // READ BY ID
    @GetMapping("/{id}")
    public Task getTaskById(@PathVariable Long id) {
        return taskService.getTaskById(id);
    }

    // UPDATE
    @PutMapping("/{id}")
    public Task updateTask(@PathVariable Long id, @RequestBody Task taskDetails) {
        return taskService.updateTask(id, taskDetails);
    }

    // DELETE
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteTask(@PathVariable Long id) {
        taskService.deleteTask(id);
    }

}
/*************************** END OF LAYER CONTROLLER ***************************/

/*
// VERSI 1 ( DI KELAS)
public class TaskController {

    @Autowired  // DI (dependency injection) : membuat definisi objek secara otomatis
    // Task task = new Task(...);
    private TaskService taskService;

    // READ ALL
    @GetMapping
    public List<Task> getAllTasks(){
        return taskService.getAllTasks();
    }

    // CREATE
    @PostMapping
    public Task createTask(@RequestBody Task task){
        // RequestBody : untuk parsing JSON (input dari web/client) menjadi object
        return taskService.createTask(task);
    }
}
*/

