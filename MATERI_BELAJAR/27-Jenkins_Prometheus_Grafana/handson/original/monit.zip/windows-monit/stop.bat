@echo off
REM Navigate to the directory where the script is located
cd /d "%~dp0"

echo Stopping monitoring stack...
docker-compose down

echo Monitoring stack stopped.
echo All containers have been removed.
pause 