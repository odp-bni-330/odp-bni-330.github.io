#!/usr/bin/env pwsh
# Demo Multi-Source Data Visualization Management Script for Windows (PowerShell)

param(
    [Parameter(Position=0)]
    [ValidateSet("start", "stop", "restart", "status", "logs", "cleanup", "info", "help")]
    [string]$Command = "",
    
    [Parameter(Position=1)]
    [string]$Service = ""
)

# Colors for PowerShell output
function Write-Info { param($Message) Write-Host "ℹ️  $Message" -ForegroundColor Blue }
function Write-Success { param($Message) Write-Host "✅ $Message" -ForegroundColor Green }
function Write-Warning { param($Message) Write-Host "⚠️  $Message" -ForegroundColor Yellow }
function Write-Error { param($Message) Write-Host "❌ $Message" -ForegroundColor Red }
function Write-Header { param($Message) Write-Host "🚀 $Message" -ForegroundColor Magenta }

function Test-Docker {
    try {
        docker info 2>$null | Out-Null
        if ($LASTEXITCODE -ne 0) {
            Write-Error "Docker is not running. Please start Docker Desktop first."
            exit 1
        }
    }
    catch {
        Write-Error "Docker is not available. Please install Docker Desktop."
        exit 1
    }
}

function Get-DockerComposeCommand {
    try {
        docker-compose --version 2>$null | Out-Null
        if ($LASTEXITCODE -eq 0) {
            return "docker-compose"
        }
    }
    catch { }
    
    try {
        docker compose version 2>$null | Out-Null
        if ($LASTEXITCODE -eq 0) {
            return "docker compose"
        }
    }
    catch { }
    
    Write-Error "Docker Compose is not available."
    exit 1
}

function Start-Demo {
    Write-Header "Starting Demo Environment"
    Test-Docker
    $DockerComposeCmd = Get-DockerComposeCommand
    
    Write-Info "Building and starting containers..."
    Invoke-Expression "$DockerComposeCmd up -d --build"
    
    if ($LASTEXITCODE -ne 0) {
        Write-Error "Failed to start containers"
        exit 1
    }
    
    Write-Info "Waiting for services to be ready..."
    Start-Sleep -Seconds 10
    
    Write-Success "Demo environment started!"
    Write-Info "Access the demo at: " -NoNewline
    Write-Host "http://localhost:3000" -ForegroundColor Cyan
}

function Stop-Demo {
    Write-Header "Stopping Demo Environment"
    $DockerComposeCmd = Get-DockerComposeCommand
    
    Invoke-Expression "$DockerComposeCmd down"
    Write-Success "Demo environment stopped!"
}

function Restart-Demo {
    Stop-Demo
    Start-Sleep -Seconds 2
    Start-Demo
}

function Get-Status {
    Write-Header "Demo Environment Status"
    $DockerComposeCmd = Get-DockerComposeCommand
    Invoke-Expression "$DockerComposeCmd ps"
}

function Show-Logs {
    $DockerComposeCmd = Get-DockerComposeCommand
    if ([string]::IsNullOrEmpty($Service)) {
        Invoke-Expression "$DockerComposeCmd logs -f"
    } else {
        Invoke-Expression "$DockerComposeCmd logs -f $Service"
    }
}

function Remove-Demo {
    Write-Header "Cleaning Up Demo Environment"
    $DockerComposeCmd = Get-DockerComposeCommand
    Write-Warning "This will remove all containers and volumes. Continue? (y/N)"
    
    $response = Read-Host
    if ($response -match "^[yY]([eE][sS])?$") {
        Invoke-Expression "$DockerComposeCmd down -v --remove-orphans"
        Write-Success "Cleanup completed!"
    } else {
        Write-Info "Cleanup cancelled."
    }
}

function Show-Info {
    Write-Header "Demo Connection Information"
    Write-Host ""
    Write-Info "🌐 Web Application: " -NoNewline
    Write-Host "http://localhost:3000" -ForegroundColor Cyan
    Write-Info "🐘 PostgreSQL: Neon Cloud Database"
    Write-Info "🍃 MongoDB: Atlas Cloud Database"
}

function Show-Help {
    Write-Header "Demo Multi-Source Data Visualization - Help"
    Write-Host ""
    Write-Host "Usage: .\demo.ps1 [command] [service]" -ForegroundColor White
    Write-Host ""
    Write-Host "Commands:" -ForegroundColor White
    Write-Host "  start       Start the demo environment" -ForegroundColor Gray
    Write-Host "  stop        Stop the demo environment" -ForegroundColor Gray
    Write-Host "  restart     Restart the demo environment" -ForegroundColor Gray
    Write-Host "  status      Show status of services" -ForegroundColor Gray
    Write-Host "  logs [svc]  Show logs (optionally for specific service)" -ForegroundColor Gray
    Write-Host "  cleanup     Remove containers and volumes" -ForegroundColor Gray
    Write-Host "  info        Show connection information" -ForegroundColor Gray
    Write-Host "  help        Show this help" -ForegroundColor Gray
    Write-Host ""
    Write-Host "Examples:" -ForegroundColor White
    Write-Host "  .\demo.ps1 start" -ForegroundColor Cyan
    Write-Host "  .\demo.ps1 logs webapp" -ForegroundColor Cyan
    Write-Host "  .\demo.ps1 status" -ForegroundColor Cyan
}

# Main execution logic
switch ($Command.ToLower()) {
    "start" { Start-Demo }
    "stop" { Stop-Demo }
    "restart" { Restart-Demo }
    "status" { Get-Status }
    "logs" { Show-Logs }
    "cleanup" { Remove-Demo }
    "info" { Show-Info }
    "help" { Show-Help }
    "" { 
        Write-Error "No command specified. Use 'help' for available commands."
        Show-Help
    }
    default { 
        Write-Error "Unknown command: $Command"
        Show-Help
        exit 1
    }
}
