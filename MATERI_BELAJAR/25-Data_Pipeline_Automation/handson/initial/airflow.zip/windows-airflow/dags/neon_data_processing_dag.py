from datetime import datetime, timedelta
import pandas as pd
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
import logging

default_args = {
    'owner': 'data-team',
    'depends_on_past': False,
    'start_date': datetime(2024, 1, 1),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5)
}

dag = DAG(
    'neon_data_processing_workflow',
    default_args=default_args,
    description='Data processing workflow using Neon PostgreSQL data',
    schedule_interval=timedelta(hours=6),
    catchup=False,
    tags=['neon', 'database', 'etl']
)

def extract_data_from_neon(**context):
    """Extract data from Neon PostgreSQL"""
    postgres_hook = PostgresHook(postgres_conn_id='neon_postgres')
    
    sql_query = """
    SELECT id, name, age, salary, salary_category,
           CURRENT_TIMESTAMP as extracted_at
    FROM employees 
    ORDER BY id;
    """
    
    df = postgres_hook.get_pandas_df(sql_query)
    csv_path = '/opt/airflow/data/neon_employees_data.csv'
    df.to_csv(csv_path, index=False)
    
    logging.info(f"Extracted {len(df)} records from Neon PostgreSQL")
    return csv_path

def process_and_analyze_data(**context):
    """Process the extracted data and create analytics"""
    df = pd.read_csv('/opt/airflow/data/neon_employees_data.csv')
    
    # Add processed columns
    df['age_group'] = pd.cut(df['age'], bins=[20, 30, 40, 50, 60], 
                           labels=['20-29', '30-39', '40-49', '50-59'])
    df['salary_percentile'] = pd.qcut(df['salary'], q=4, 
                                    labels=['Q1', 'Q2', 'Q3', 'Q4'])
    
    # Calculate statistics
    stats = {
        'total_employees': len(df),
        'avg_age': df['age'].mean(),
        'avg_salary': df['salary'].mean(),
        'min_salary': df['salary'].min(),
        'max_salary': df['salary'].max()
    }
    
    # Save processed data
    df.to_csv('/opt/airflow/data/processed_neon_data.csv', index=False)
    
    # Save statistics
    stats_df = pd.DataFrame([stats])
    stats_df.to_csv('/opt/airflow/data/neon_statistics.csv', index=False)
    
    logging.info(f"Processed data: {stats}")
    return stats

def generate_report(**context):
    """Generate HTML report"""
    df = pd.read_csv('/opt/airflow/data/processed_neon_data.csv')
    stats = pd.read_csv('/opt/airflow/data/neon_statistics.csv')
    
    html_content = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Neon PostgreSQL Data Analysis Report</title>
        <style>
            body {{ font-family: Arial, sans-serif; margin: 40px; background: #f5f7fa; }}
            .container {{ max-width: 1000px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; }}
            h1 {{ color: #2c3e50; text-align: center; }}
            .stats {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin: 20px 0; }}
            .stat-card {{ background: #3498db; color: white; padding: 20px; border-radius: 8px; text-align: center; }}
            table {{ width: 100%; border-collapse: collapse; margin: 20px 0; }}
            th, td {{ padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }}
            th {{ background: #3498db; color: white; }}
            tr:nth-child(even) {{ background: #f2f2f2; }}
            .badge {{ padding: 4px 8px; border-radius: 4px; font-size: 0.8em; font-weight: bold; }}
            .badge-junior {{ background: #f39c12; color: white; }}
            .badge-mid {{ background: #27ae60; color: white; }}
            .badge-senior {{ background: #8e44ad; color: white; }}
        </style>
    </head>
    <body>
        <div class="container">
            <h1>📊 Neon PostgreSQL Employee Data Analysis</h1>
            <p style="text-align: center; color: #7f8c8d;">Report Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}</p>
            
            <div class="stats">
                <div class="stat-card">
                    <h3>{int(stats['total_employees'].iloc[0])}</h3>
                    <p>Total Employees</p>
                </div>
                <div class="stat-card">
                    <h3>{stats['avg_age'].iloc[0]:.1f}</h3>
                    <p>Average Age</p>
                </div>
                <div class="stat-card">
                    <h3>${stats['avg_salary'].iloc[0]:,.0f}</h3>
                    <p>Average Salary</p>
                </div>
                <div class="stat-card">
                    <h3>${stats['max_salary'].iloc[0]:,.0f}</h3>
                    <p>Highest Salary</p>
                </div>
            </div>
            
            <h2>👥 Employee Distribution by Category</h2>
            <table>
                <tr>
                    <th>Salary Category</th>
                    <th>Count</th>
                    <th>Percentage</th>
                    <th>Avg Salary</th>
                </tr>
    """
    
    category_stats = df.groupby('salary_category').agg({
        'id': 'count',
        'salary': 'mean'
    }).round(2)
    
    total_employees = len(df)
    
    for category, row in category_stats.iterrows():
        count = int(row['id'])
        percentage = (count / total_employees) * 100
        avg_salary = row['salary']
        badge_class = f"badge-{category.lower().replace('-', '')}"
        
        html_content += f"""
            <tr>
                <td><span class="badge {badge_class}">{category}</span></td>
                <td>{count}</td>
                <td>{percentage:.1f}%</td>
                <td>${avg_salary:,.0f}</td>
            </tr>
        """
    
    html_content += f"""
            </table>
            
            <h2>📋 Sample Employee Data (First 10 Records)</h2>
            <table>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Age</th>
                    <th>Salary</th>
                    <th>Category</th>
                    <th>Age Group</th>
                </tr>
    """
    
    # Add sample data (first 10 records)
    for _, row in df.head(10).iterrows():
        badge_class = f"badge-{row['salary_category'].lower().replace('-', '')}"
        html_content += f"""
            <tr>
                <td>{int(row['id'])}</td>
                <td>{row['name']}</td>
                <td>{int(row['age'])}</td>
                <td>${row['salary']:,.0f}</td>
                <td><span class="badge {badge_class}">{row['salary_category']}</span></td>
                <td>{row['age_group']}</td>
            </tr>
        """
    
    html_content += f"""
            </table>
            
            <div style="text-align: center; margin-top: 30px; color: #7f8c8d; font-size: 0.9em;">
                <p><strong>Data Source:</strong> Neon PostgreSQL Database</p>
                <p><strong>Processing Time:</strong> {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}</p>
                <p><strong>Total Records Processed:</strong> {len(df)} employees</p>
            </div>
        </div>
    </body>
    </html>
    """
    
    with open('/opt/airflow/data/neon_data_report.html', 'w') as f:
        f.write(html_content)
    
    logging.info("HTML report generated successfully")

# Task definitions
extract_task = PythonOperator(
    task_id='extract_from_neon',
    python_callable=extract_data_from_neon,
    dag=dag
)

process_task = PythonOperator(
    task_id='process_data',
    python_callable=process_and_analyze_data,
    dag=dag
)

report_task = PythonOperator(
    task_id='generate_report',
    python_callable=generate_report,
    dag=dag
)

# Task dependencies
extract_task >> process_task >> report_task 