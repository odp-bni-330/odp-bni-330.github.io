# Latihan Praktis: Analisis Data Multi-Source dengan PostgreSQL dan MongoDB

## Deskripsi
Panduan latihan praktis untuk mempelajari cara menganalisis data dari berbagai sumber menggunakan PostgreSQL (relational database) dan MongoDB (NoSQL database), serta memvisualisasikan hasilnya dengan Tableau.

## Struktur Folder
```
practice/
├── docker-compose.yml           # Konfigurasi Docker Compose
├── setup.sh                     # Script management environment
├── README.md                    # Panduan ini
└── init-scripts/
    ├── postgres/
    │   └── 01-create-schema.sql  # Inisialisasi PostgreSQL
    └── mongo/
        └── 01-init-practice.js   # Inisialisasi MongoDB
```

## Quick Start

### 1. Persiapan Environment
```bash
# Beri izin eksekusi pada script
chmod +x setup.sh

# Jalankan environment
./setup.sh start
```

### 2. Verifikasi Koneksi
```bash
# Cek status services
./setup.sh status

# Lihat informasi koneksi
./setup.sh info
```

---

## Latihan 1: Menyiapkan Lingkungan

### 🎯 Tujuan
- Menginstal dan mengkonfigurasi PostgreSQL sebagai pengganti Oracle
- Mengatur MongoDB untuk data NoSQL
- Mempersiapkan dataset untuk analisis

### 📋 Langkah-langkah

#### A. Instalasi Database
```bash
# 1. Jalankan Docker Compose
./setup.sh start

# 2. Tunggu hingga semua service ready
# PostgreSQL akan tersedia di port 5433
# MongoDB akan tersedia di port 27018
```

#### B. Konfigurasi Konektivitas

**PostgreSQL Connection:**
- Host: `localhost`
- Port: `5433`
- Database: `ecommerce_practice`
- Username: `practice_user`
- Password: `practice_pass`

**MongoDB Connection:**
- Host: `localhost`
- Port: `27018`
- Database: `ecommerce_practice`
- Username: `practice_user`
- Password: `practice_pass`

#### C. Persiapan Dataset
Dataset sudah otomatis diimport saat container pertama kali dijalankan:

**PostgreSQL Tables:**
- `customers` - Data pelanggan dasar
- `orders` - Data transaksi pembelian
- `products` - Katalog produk
- `order_items` - Detail item per order

**MongoDB Collections:**
- `customers` - Profil lengkap pelanggan (demografi, preferensi, lokasi)
- `interactions` - Data interaksi pelanggan (website visits, email opens, dll)

### ✅ Verifikasi
```bash
# Test koneksi PostgreSQL
./setup.sh psql

# Test koneksi MongoDB  
./setup.sh mongo

# Jalankan sample queries
./setup.sh query
```

---

## Latihan 2: Membuat Query Dasar

### 🎯 Tujuan
- Membuat query SQL di PostgreSQL
- Membuat query aggregation di MongoDB
- Memahami perbedaan sintaks SQL vs NoSQL

### 📋 Praktik Query

#### A. Query PostgreSQL

**1. Top Spending Customers (6 bulan terakhir)**
```sql
SELECT
    c.customer_id,
    c.name,
    c.email,
    SUM(o.total_amount) AS total_spent
FROM
    customers c
JOIN
    orders o ON c.customer_id = o.customer_id
WHERE
    o.order_date >= CURRENT_DATE - INTERVAL '6 months'
GROUP BY
    c.customer_id,
    c.name,
    c.email
ORDER BY
    total_spent DESC
LIMIT 10;
```

**2. Sales by Category dan City**
```sql
SELECT
    p.category,
    c.city,
    COUNT(o.order_id) as total_orders,
    SUM(o.total_amount) as total_revenue,
    AVG(o.total_amount) as avg_order_value
FROM
    orders o
JOIN customers c ON o.customer_id = c.customer_id
JOIN order_items oi ON o.order_id = oi.order_id
JOIN products p ON oi.product_id = p.product_id
GROUP BY p.category, c.city
ORDER BY total_revenue DESC;
```

**3. Customer Activity Analysis**
```sql
SELECT
    c.city,
    COUNT(DISTINCT c.customer_id) as total_customers,
    COUNT(o.order_id) as total_orders,
    AVG(o.total_amount) as avg_order_value,
    SUM(o.total_amount) as total_revenue
FROM
    customers c
LEFT JOIN orders o ON c.customer_id = o.customer_id
GROUP BY c.city
ORDER BY total_revenue DESC;
```

#### B. Query MongoDB

**1. Customer Interactions Aggregation**
```javascript
db.customers.aggregate([
  { $lookup: {
      from: "interactions",
      localField: "customer_id",
      foreignField: "customer_id",
      as: "customer_interactions"
  }},
  { $project: {
      customer_id: 1,
      name: 1,
      email: 1,
      "location.city": 1,
      "demographics.age": 1,
      "loyalty_program.tier": 1,
      interaction_count: { $size: "$customer_interactions" }
  }},
  { $sort: { interaction_count: -1 }},
  { $limit: 10 }
]);
```

**2. Customer Demographics by City**
```javascript
db.customers.aggregate([
  { $group: {
      _id: "$location.city",
      total_customers: { $sum: 1 },
      avg_age: { $avg: "$demographics.age" },
      gender_distribution: {
        $push: "$demographics.gender"
      },
      loyalty_tiers: {
        $push: "$loyalty_program.tier"
      }
  }},
  { $project: {
      city: "$_id",
      total_customers: 1,
      avg_age: { $round: ["$avg_age", 1] },
      gender_distribution: 1,
      loyalty_tiers: 1
  }},
  { $sort: { total_customers: -1 }}
]);
```

**3. Interaction Types Analysis**
```javascript
db.interactions.aggregate([
  { $group: {
      _id: {
        type: "$type",
        customer_city: "$customer_city"
      },
      count: { $sum: 1 },
      customers: { $addToSet: "$customer_id" }
  }},
  { $project: {
      interaction_type: "$_id.type",
      city: "$_id.customer_city",
      total_interactions: "$count",
      unique_customers: { $size: "$customers" }
  }},
  { $sort: { total_interactions: -1 }}
]);
```

### 💡 Tips
- Gunakan `./setup.sh psql` untuk mengakses PostgreSQL
- Gunakan `./setup.sh mongo` untuk mengakses MongoDB  
- Simpan query hasil yang bagus untuk digunakan di Tableau

---

## Latihan 3: Menggabungkan Data di Tableau

### 🎯 Tujuan
- Menghubungkan Tableau ke PostgreSQL dan MongoDB
- Membuat relationship antar data sources
- Membuat calculated fields untuk analisis gabungan

### 📋 Langkah-langkah

#### A. Menambahkan Sumber Data

**1. Koneksi PostgreSQL:**
1. Buka Tableau Desktop
2. Pilih "PostgreSQL" sebagai data source
3. Masukkan connection details:
   - Server: `localhost`
   - Port: `5433`
   - Database: `ecommerce_practice`
   - Username: `practice_user`
   - Password: `practice_pass`
4. Pilih tabel: `customers`, `orders`, `products`, `order_items`

**2. Koneksi MongoDB:**
1. Export data MongoDB ke CSV:
```bash
# Export customers
mongoexport --host localhost:27018 --db ecommerce_practice --collection customers --username practice_user --password practice_pass --authenticationDatabase ecommerce_practice --type csv --fields customer_id,name,email,demographics.age,demographics.gender,location.city,loyalty_program.tier --out customers_mongo.csv

# Export interactions summary
mongosh --host localhost:27018 --username practice_user --password practice_pass --authenticationDatabase ecommerce_practice ecommerce_practice --eval "
db.interactions.aggregate([
  { \$group: {
      _id: '\$customer_id',
      total_interactions: { \$sum: 1 },
      interaction_types: { \$addToSet: '\$type' },
      last_interaction: { \$max: '\$timestamp' }
  }},
  { \$out: 'customer_interactions_summary' }
]);"

mongoexport --host localhost:27018 --db ecommerce_practice --collection customer_interactions_summary --username practice_user --password practice_pass --authenticationDatabase ecommerce_practice --type csv --out interactions_summary.csv
```

2. Import CSV files ke Tableau

#### B. Membuat Hubungan

1. Dalam Tableau, buat relationship berdasarkan `customer_id`
2. Join tabel PostgreSQL:
   - `customers` ↔ `orders` (customer_id)
   - `orders` ↔ `order_items` (order_id)  
   - `order_items` ↔ `products` (product_id)
3. Relate dengan data MongoDB menggunakan `customer_id`

#### C. Membuat Calculated Fields

**1. Customer Engagement Score:**
```
([Total Interactions] * 0.3) + 
([Total Orders] * 0.5) + 
([Total Spent] / 1000 * 0.2)
```

**2. Customer Lifetime Value:**
```
[Total Spent] / DATEDIFF('month', [Registration Date], TODAY())
```

**3. Interaction to Purchase Ratio:**
```
IF [Total Orders] > 0 THEN 
  [Total Interactions] / [Total Orders] 
ELSE 
  [Total Interactions] 
END
```

#### D. Membuat Visualisasi

**1. Customer Segmentation Dashboard:**
- Scatter plot: Age vs Total Spent (colored by City)
- Bar chart: Revenue by Category and City
- Map: Customer distribution by location
- Pie chart: Loyalty tier distribution

**2. Interaction Analysis:**
- Line chart: Interactions over time
- Heatmap: Interaction types by customer segment
- Tree map: Interaction volume by type

### 📊 Contoh Insights
- Pelanggan dari Jakarta memiliki engagement rate tertinggi
- Customer tier Gold menunjukkan interaction-to-purchase ratio terbaik
- Kategori Electronics mendominasi revenue di kota besar

---

## Latihan 4: Membuat Dashboard Interaktif

### 🎯 Tujuan
- Membuat dashboard yang responsif dan interaktif
- Mengimplementasikan filtering dan drill-down
- Menambahkan actions antar visualisasi

### 📋 Implementasi

#### A. Filter Interaktif

**1. Global Filters:**
- Date Range Picker (Order Date)
- City Multi-Select
- Category Multi-Select
- Customer Tier Single-Select

**2. Quick Filters:**
- Age Range Slider
- Revenue Range
- Interaction Count Range

#### B. Drill-Down Hierarkis

**1. Geographic Hierarchy:**
```
Country → City → Customer → Orders
```

**2. Product Hierarchy:**
```
Category → Product → Order Details
```

**3. Time Hierarchy:**
```
Year → Quarter → Month → Day
```

#### C. Tindakan Antar-Visualisasi

**1. Filter Actions:**
- Klik pada city map → filter all charts untuk city tersebut
- Select age range → update customer segment analysis
- Choose time period → refresh all time-based metrics

**2. Highlight Actions:**
- Hover pada customer segment → highlight di scatter plot
- Select product category → highlight related interactions

**3. URL Actions:**
- Link ke customer detail page
- Open product catalog
- Generate report export

### 🎨 Dashboard Design Tips

**1. Layout Best Practices:**
- Gunakan grid system untuk alignment
- Konsisten dengan color scheme
- White space yang cukup
- Mobile-responsive design

**2. User Experience:**
- Loading indicators untuk slow queries
- Clear legends dan labels  
- Intuitive navigation
- Error handling untuk empty results

**3. Performance Optimization:**
- Extract data untuk large datasets
- Optimize query calculations
- Use context filters
- Incremental refresh setup

---

## Sumber Daya untuk Pembelajaran Lanjutan

### 📚 Dokumentasi Resmi
- [PostgreSQL Documentation](https://www.postgresql.org/docs/)
- [MongoDB Manual](https://docs.mongodb.com/)
- [Tableau Help](https://help.tableau.com/)

### 🎓 Kursus Online
- **PostgreSQL:** 
  - Coursera: "PostgreSQL for Everybody"
  - Udemy: "The Complete PostgreSQL Bootcamp"
- **MongoDB:**
  - MongoDB University (Free courses)
  - Pluralsight: "MongoDB Developer Path"
- **Tableau:**
  - Tableau eLearning
  - LinkedIn Learning: "Tableau Essential Training"

### 💬 Komunitas dan Forum
- [Stack Overflow](https://stackoverflow.com/) - Technical Q&A
- [PostgreSQL Community](https://www.postgresql.org/community/)
- [MongoDB Community Forums](https://developer.mongodb.com/community/forums/)
- [Tableau Community](https://community.tableau.com/)

---

## Troubleshooting

### Masalah Umum

**1. Container tidak start:**
```bash
# Check Docker status
docker --version
docker-compose --version

# Check port conflicts
netstat -tulpn | grep :5433
netstat -tulpn | grep :27018

# Restart dengan cleanup
./setup.sh cleanup
./setup.sh start
```

**2. Koneksi database gagal:**
```bash
# Check container logs
./setup.sh logs postgresql
./setup.sh logs mongodb

# Test manual connection
docker exec -it practice-postgresql psql -U practice_user -d ecommerce_practice
docker exec -it practice-mongodb mongosh --username practice_user --password practice_pass ecommerce_practice
```

**3. Query performance lambat:**
- Gunakan EXPLAIN untuk PostgreSQL queries
- Gunakan .explain() untuk MongoDB aggregations  
- Check index usage
- Optimize join conditions

### 🆘 Bantuan
Jika mengalami masalah, jalankan:
```bash
./setup.sh help
```

Atau check logs detail:
```bash
./setup.sh logs
```

---

## Cleanup

```bash
# Stop services tanpa hapus data
./setup.sh stop

# Hapus containers tapi simpan data
./setup.sh cleanup

# Reset complete (HATI-HATI: hapus semua data)
./setup.sh cleanup
```

**Selamat belajar! 🚀** 