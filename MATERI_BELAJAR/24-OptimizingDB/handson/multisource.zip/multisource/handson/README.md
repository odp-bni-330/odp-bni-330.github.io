# Multi-Source Data Analysis Project

## Deskripsi Proyek

Proyek ini mendemonstrasikan analisis data dari berbagai sumber menggunakan PostgreSQL dan MongoDB. Hands-on ini memungkinkan Anda untuk:

1. Mengekstrak data penjualan dari PostgreSQL 
2. Mengekstrak data pelanggan dari MongoDB
3. Menggabungkan kedua sumber data di Tableau
4. Membuat visualisasi yang memberikan insight bisnis

## Arsitektur Sistem

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   PostgreSQL    │    │     MongoDB     │    │     Tableau     │
│  (Sales Data)   │───▶│ (Customer Data) │───▶│ (Visualization) │
│                 │    │                 │    │                 │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

## Setup dan Instalasi

### Prasyarat
- Docker dan Docker Compose
- Tableau Desktop atau Tableau Public
- pgAdmin (opsional)
- MongoDB Compass (opsional)

### Menjalankan Environment

1. Clone repository ini:
   ```bash
   git clone <repository-url>
   cd multisource
   ```

2. Jalankan Docker Compose:
   ```bash
   docker-compose up -d
   ```

3. Verifikasi semua container berjalan:
   ```bash
   docker-compose ps
   ```

## Struktur Data

### PostgreSQL - Sales Data
- **products**: Informasi produk (id, nama, kategori, harga)
- **sales**: Transaksi penjualan (id, customer_id, product_id, tanggal, jumlah)

### MongoDB - Customer Data
- **customers**: Profil pelanggan (customer_id, nama, lokasi, demografi, preferensi)

## Hands-on Tutorial

Lihat file `hands-on-postgres-mongodb.md` untuk tutorial lengkap tentang:

1. Mengakses dan query data dari PostgreSQL
2. Mengakses dan query data dari MongoDB  
3. Mengekspor data untuk Tableau
4. Membuat visualisasi di Tableau
5. Analisis insight bisnis

## Tools dan Koneksi

### PostgreSQL
- **Host**: localhost:5432
- **Database**: ecommerce
- **User**: ecommerce / ecommerce
- **Tool**: pgAdmin, psql, atau Tableau langsung

### MongoDB
- **Host**: localhost:27017
- **Database**: ecommerce
- **User**: ecommerce_user / ecommerce_pass
- **Tool**: MongoDB Compass, mongo shell

### MongoDB Express (Web UI)
- **URL**: http://localhost:8081
- **User**: admin / admin

## File Penting

- `docker-compose.yml`: Konfigurasi container
- `README-docker.md`: Panduan Docker detail
- `hands-on-postgres-mongodb.md`: Tutorial hands-on
- `init-scripts/postgres/`: Skrip inisialisasi PostgreSQL
- `init-scripts/mongo/`: Skrip inisialisasi MongoDB

## Troubleshooting

Jika mengalami masalah, lihat file `README-docker.md` untuk panduan troubleshooting yang lengkap.

## Cleanup

Untuk membersihkan environment:
```bash
# Hentikan container tanpa menghapus data
docker-compose stop

# Hentikan dan hapus container (data tetap ada)
docker-compose down

# Hapus semua termasuk data
docker-compose down -v
```