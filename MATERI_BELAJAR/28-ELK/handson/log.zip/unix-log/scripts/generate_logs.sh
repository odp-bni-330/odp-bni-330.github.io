#!/bin/bash

# Log generator script untuk ELK Stack Demo
# Script ini akan menggenerate log secara kontinyu

LOG_DIR="./logs"
APACHE_LOG="$LOG_DIR/apache/access.log"
NGINX_LOG="$LOG_DIR/nginx/access.log"
APP_LOG="$LOG_DIR/application/app.log"

# Array untuk sample IPs
IPS=("192.168.1.100" "10.0.0.50" "203.0.113.45" "172.16.0.25" "198.51.100.33" "127.0.0.1")

# Array untuk sample paths
APACHE_PATHS=("/index.html" "/products.html" "/about.html" "/contact.html" "/search" "/api/login" "/dashboard" "/images/logo.png")
NGINX_PATHS=("/api/v1/users" "/api/v1/orders" "/health" "/metrics" "/api/v1/products" "/webhook" "/api/v1/logs")

# Array untuk HTTP methods
METHODS=("GET" "POST" "PUT" "DELETE" "PATCH")

# Array untuk HTTP status codes
STATUS_CODES=("200" "201" "204" "302" "400" "404" "500")

# Array untuk user agents
USER_AGENTS=(
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36"
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36"
    "curl/7.68.0"
    "PostmanRuntime/7.28.4"
    "Prometheus/2.30.3"
)

# Array untuk log levels
LOG_LEVELS=("INFO" "DEBUG" "WARN" "ERROR")

# Array untuk log messages
LOG_MESSAGES=(
    "User authentication successful"
    "Database connection established"
    "Cache hit for user data"
    "API request processed successfully"
    "Background job completed"
    "High memory usage detected"
    "Slow query detected"
    "Rate limit approaching"
    "Database deadlock detected"
    "Payment processing completed"
)

generate_apache_log() {
    local ip=${IPS[$RANDOM % ${#IPS[@]}]}
    local path=${APACHE_PATHS[$RANDOM % ${#APACHE_PATHS[@]}]}
    local method=${METHODS[$RANDOM % ${#METHODS[@]}]}
    local status=${STATUS_CODES[$RANDOM % ${#STATUS_CODES[@]}]}
    local size=$((RANDOM % 10000 + 100))
    local user_agent=${USER_AGENTS[$RANDOM % ${#USER_AGENTS[@]}]}
    local timestamp=$(date '+%d/%b/%Y:%H:%M:%S %z')
    
    echo "$ip - - [$timestamp] \"$method $path HTTP/1.1\" $status $size \"http://example.com/\" \"$user_agent\"" >> "$APACHE_LOG"
}

generate_nginx_log() {
    local ip=${IPS[$RANDOM % ${#IPS[@]}]}
    local path=${NGINX_PATHS[$RANDOM % ${#NGINX_PATHS[@]}]}
    local method=${METHODS[$RANDOM % ${#METHODS[@]}]}
    local status=${STATUS_CODES[$RANDOM % ${#STATUS_CODES[@]}]}
    local size=$((RANDOM % 5000 + 50))
    local user_agent=${USER_AGENTS[$RANDOM % ${#USER_AGENTS[@]}]}
    local timestamp=$(date '+%d/%b/%Y:%H:%M:%S %z')
    
    echo "$ip - - [$timestamp] \"$method $path HTTP/1.1\" $status $size \"http://api.example.com/\" \"$user_agent\"" >> "$NGINX_LOG"
}

generate_application_log() {
    local level=${LOG_LEVELS[$RANDOM % ${#LOG_LEVELS[@]}]}
    local message=${LOG_MESSAGES[$RANDOM % ${#LOG_MESSAGES[@]}]}
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S,%3N')
    
    echo "[$timestamp] $level: $message" >> "$APP_LOG"
}

echo "🚀 Memulai log generator..."
echo "📁 Log directory: $LOG_DIR"
echo "⏹️  Tekan Ctrl+C untuk menghentikan"

# Main loop
while true; do
    # Generate Apache log (setiap 2-5 detik)
    if [ $((RANDOM % 3)) -eq 0 ]; then
        generate_apache_log
        echo "✅ Apache log generated"
    fi
    
    # Generate Nginx log (setiap 3-6 detik)
    if [ $((RANDOM % 4)) -eq 0 ]; then
        generate_nginx_log
        echo "✅ Nginx log generated"
    fi
    
    # Generate Application log (setiap 4-8 detik)
    if [ $((RANDOM % 5)) -eq 0 ]; then
        generate_application_log
        echo "✅ Application log generated"
    fi
    
    sleep $((RANDOM % 3 + 2))  # Sleep 2-4 seconds
done 