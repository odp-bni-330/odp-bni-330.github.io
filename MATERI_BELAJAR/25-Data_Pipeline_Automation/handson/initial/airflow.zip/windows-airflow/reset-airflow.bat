@echo off
echo ========================================
echo   RESET Apache Airflow on Windows
echo ========================================
echo.
echo WARNING: This will delete ALL data and volumes!
echo This includes:
echo   - All DAG run history
echo   - All task logs
echo   - Database content
echo   - Generated data files
echo.
set /p confirm="Are you sure? (type 'YES' to confirm): "
if /i not "%confirm%"=="YES" (
    echo Operation cancelled.
    pause
    exit /b 0
)

echo.
echo [INFO] Stopping all services...
docker-compose down

echo.
echo [INFO] Removing volumes and data...
docker-compose down -v

echo.
echo [INFO] Cleaning up local data directories...
if exist "logs\*" del /q "logs\*" 2>nul
if exist "data\*" del /q "data\*" 2>nul

echo.
echo [INFO] Removing Docker images (optional cleanup)...
docker rmi apache/airflow:2.7.1 2>nul
docker rmi postgres:13 2>nul
docker rmi redis:7-alpine 2>nul

echo.
echo ========================================
echo       Airflow completely reset!
echo ========================================
echo.
echo All data, volumes, and images removed.
echo To start fresh: run start-airflow.bat
echo.
pause 