# ELK Stack Demo - Windows Edition 🚀

Demo lengkap untuk **Elasticsearch**, **Logstash**, **Kibana**, dan **Filebeat** menggunakan Docker Compose dengan log generator otomatis yang dioptimalkan untuk **Windows**.

## 📋 Daftar Isi

- [Fitur](#-fitur)
- [Prasyarat](#-prasyarat)
- [Instalasi](#-instalasi)
- [Penggunaan](#-penggunaan)
- [Struktur Proyek](#-struktur-proyek)
- [Konfigurasi](#-konfigurasi)
- [Troubleshooting](#-troubleshooting)

## ✨ Fitur

- **Elasticsearch 8.11.0** - Search dan analytics engine
- **Logstash 8.11.0** - Data processing pipeline
- **Kibana 8.11.0** - Data visualization dan dashboard
- **Filebeat 8.11.0** - Log shipper
- **Log Generator** - Otomatis menggenerate sample logs
- **Docker Compose** - Deployment yang mudah
- **Script Otomatis** - Setup dan management yang simpel

## 🛠 Prasyarat

- **Docker Desktop for Windows** (versi 20.10+)
- **Docker Compose** (versi 2.0+)
- **PowerShell 5.1** atau **PowerShell 7+**
- **Windows 10/11** dengan WSL2 (recommended)
- **4GB RAM minimum** untuk semua container
- **Git for Windows** (optional, untuk clone repository)

## 📦 Instalasi

1. **Clone atau download proyek ini**
   ```powershell
   git clone <repository-url>
   cd elk-stack-demo/windows-log
   ```

2. **Set PowerShell Execution Policy (jika diperlukan)**
   ```powershell
   Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
   ```

3. **Jalankan demo**
   ```powershell
   .\run-elk-demo.ps1 start
   ```

## 🎯 Penggunaan

### Memulai Demo

```powershell
# Memulai seluruh ELK Stack
.\run-elk-demo.ps1 start
```

Script akan secara otomatis:
- ✅ Memeriksa Docker Desktop
- ✅ Memeriksa Docker Compose
- ✅ Membersihkan container lama
- ✅ Menjalankan semua service (Elasticsearch, Logstash, Kibana, Filebeat)
- ✅ Menunggu service siap
- ✅ Memulai log generator (PowerShell Jobs)
- ✅ Membuat index pattern di Kibana

### Perintah Lainnya

```powershell
# Menghentikan demo
.\run-elk-demo.ps1 stop

# Restart demo
.\run-elk-demo.ps1 restart

# Melihat logs container
.\run-elk-demo.ps1 logs

# Melihat status container
.\run-elk-demo.ps1 status

# Bantuan
.\run-elk-demo.ps1 help
```

### Mengakses Service

| Service | URL | Deskripsi |
|---------|-----|-----------|
| **Kibana** | http://localhost:5601 | Dashboard dan visualisasi |
| **Elasticsearch** | http://localhost:9200 | REST API |
| **Logstash** | http://localhost:9600 | Monitoring API |

## 📁 Struktur Proyek

```
windows-log/
├── docker-compose.yml          # Docker Compose configuration (Windows compatible)
├── run-elk-demo.ps1           # PowerShell script untuk menjalankan demo
├── README.md                  # Dokumentasi untuk Windows
├── filebeat/
│   └── filebeat.yml          # Konfigurasi Filebeat (Windows compatible)
├── logstash/
│   ├── config/
│   │   └── logstash.yml      # Konfigurasi Logstash
│   └── pipeline/
│       └── logstash.conf     # Pipeline processing rules
├── logs/                     # Sample log files
│   ├── apache/
│   │   └── access.log
│   ├── nginx/
│   │   └── access.log
│   └── application/
│       └── app.log
└── scripts/
    └── generate_logs.ps1     # PowerShell log generator script
```

## ⚙️ Konfigurasi

### Filebeat Configuration

- **Input**: Monitor log files di direktori `./logs/`
- **Output**: Kirim ke Logstash port 5044
- **Multiline**: Support untuk Apache dan Application logs

### Logstash Configuration

- **Input**: Beats input port 5044
- **Filter**: 
  - Grok patterns untuk Apache, Nginx, Application logs
  - GeoIP enrichment
  - Field type conversion
- **Output**: Elasticsearch dengan index pattern `demo-logs-YYYY.MM.dd`

### Elasticsearch Configuration

- **Mode**: Single node
- **Security**: Disabled (untuk demo)
- **Memory**: 512MB heap size

### Kibana Configuration

- **Port**: 5601
- **Index Pattern**: `demo-logs-*` (otomatis dibuat)

## 🎨 Menggunakan Kibana

1. **Buka Kibana** di http://localhost:5601

2. **Pergi ke Discover**
   - Sidebar → Analytics → Discover
   - Pilih index pattern: `demo-logs-*`

3. **Lihat Data Real-time**
   - Log akan muncul secara real-time
   - Filter berdasarkan log type, IP, status code, dll

4. **Buat Visualisasi**
   - Sidebar → Analytics → Visualize Library
   - Buat chart untuk:
     - HTTP status codes distribution
     - Top client IPs
     - Request methods over time
     - Error rate trends

5. **Buat Dashboard**
   - Sidebar → Analytics → Dashboard
   - Kombinasikan visualisasi yang sudah dibuat

## 🔍 Sample Queries

### Elasticsearch Queries

```bash
# Cek index yang tersedia
curl "localhost:9200/_cat/indices?v"

# Search semua logs
curl "localhost:9200/demo-logs-*/_search?pretty"

# Search error logs
curl "localhost:9200/demo-logs-*/_search?q=log_level:ERROR&pretty"

# Count documents
curl "localhost:9200/demo-logs-*/_count?pretty"
```

### Kibana Query Examples

```
# Filter logs dengan status 404
response:404

# Filter logs dari IP tertentu
clientip:"192.168.1.100"

# Filter application errors
fields.log_type:"application" AND log_level:"ERROR"

# Filter berdasarkan waktu
@timestamp:[now-1h TO now]
```

## 🐛 Troubleshooting

### Container Tidak Mau Start

```bash
# Cek status Docker
docker info

# Cek logs container
docker-compose logs elasticsearch
docker-compose logs logstash
docker-compose logs kibana
docker-compose logs filebeat
```

### Elasticsearch Tidak Bisa Diakses

```bash
# Cek health Elasticsearch
curl localhost:9200/_cluster/health?pretty

# Cek memory usage
docker stats elasticsearch
```

### Kibana Tidak Menampilkan Data

1. **Cek apakah index ada:**
   ```bash
   curl "localhost:9200/_cat/indices?v"
   ```

2. **Cek apakah Filebeat mengirim data:**
   ```bash
   docker-compose logs filebeat
   ```

3. **Cek Logstash processing:**
   ```bash
   docker-compose logs logstash
   ```

### Memory Issues

Jika mengalami masalah memory:

1. **Turunkan heap size di docker-compose.yml:**
   ```yaml
   environment:
     - ES_JAVA_OPTS=-Xms256m -Xmx256m  # dari 512m ke 256m
   ```

2. **Restart container:**
   ```bash
   ./run-elk-demo.sh restart
   ```

### Log Generator Tidak Berjalan

```bash
# Cek apakah process masih berjalan
ps aux | grep generate_logs

# Jalankan manual untuk debug
./scripts/generate_logs.sh

# Cek output log generator
cat log_generator.out
```

## 🏁 Membersihkan Demo

```powershell
# Stop demo dan hapus semua container + volume
.\run-elk-demo.ps1 stop
docker compose down -v --remove-orphans

# Hapus image (opsional)
docker rmi (docker images -q docker.elastic.co/elasticsearch/elasticsearch:8.11.0)
docker rmi (docker images -q docker.elastic.co/logstash/logstash:8.11.0)
docker rmi (docker images -q docker.elastic.co/kibana/kibana:8.11.0)
docker rmi (docker images -q docker.elastic.co/beats/filebeat:8.11.0)
```

## 🪟 Windows-Specific Notes

### PowerShell Execution Policy
Jika mengalami error execution policy:
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

### Docker Desktop Settings
Pastikan Docker Desktop dikonfigurasi dengan benar:
- **WSL2 Backend** enabled (recommended)
- **File Sharing** untuk drive di mana project berada
- **Memory**: Minimum 4GB untuk Docker

### Troubleshooting Windows
1. **PowerShell Jobs**: Log generator menggunakan PowerShell background jobs
2. **Path Separators**: Script menggunakan Windows path separators (`\`)
3. **File Permissions**: Tidak ada `chmod` seperti di Unix, tapi PowerShell execution policy
4. **Docker Socket**: Docker socket mounting di-disable untuk compatibility

## 📊 Sample Dashboard Ideas

Setelah data terkumpul, Anda bisa membuat visualisasi seperti:

1. **HTTP Status Codes** - Pie chart
2. **Requests Over Time** - Line chart
3. **Top Client IPs** - Data table
4. **Error Rate** - Metric visualization
5. **Geographic Distribution** - Maps (GeoIP)
6. **Request Methods** - Donut chart
7. **Response Time Trends** - Area chart

---

## 🎉 Selamat!

Demo ELK Stack untuk Windows Anda sudah siap! Mulai eksplorasi data logging dengan Elasticsearch, Logstash, Kibana, dan Filebeat menggunakan PowerShell.

**Happy Logging on Windows!** 📈📊🪟 