# Hands-on: Workflow Automation dengan Apache Airflow

Project ini mendemonstrasikan penggunaan Apache Airflow untuk workflow automation menggunakan Docker dengan Neon PostgreSQL sebagai database.

## Struktur Direktori

```
airflow/
├── dags/                   # Direktori untuk menyimpan DAG (Directed Acyclic Graph)
│   ├── example_dag.py      # Contoh DAG sederhana
│   └── data_processing_dag.py  # DAG untuk pemrosesan data
├── logs/                   # Direktori untuk log Airflow
├── plugins/                # Direktori untuk plugin Airflow
├── docker-compose.yml      # Konfigurasi Docker Compose dengan Neon PostgreSQL
├── test-neon-connection.sh # Script untuk test koneksi Neon PostgreSQL
└── .env                    # File environment variables
```

## Database Configuration

Project ini menggunakan **Neon PostgreSQL** sebagai database cloud untuk:
- ✅ **Skalabilitas** yang lebih baik
- ✅ **Managed service** tanpa perlu maintenance
- ✅ **High availability** dan backup otomatis
- ✅ **SSL connection** untuk keamanan

**Database URL:** `postgresql://neondb_owner:***@ep-falling-cake-a1j2rvpd-pooler.ap-southeast-1.aws.neon.tech/airflow`

## Cara Menjalankan

### 1. Test Koneksi Database (Opsional)
```bash
./test-neon-connection.sh
```

### 2. Jalankan Airflow
```bash
docker-compose up -d
```

### 3. Akses UI
- Akses Airflow UI di browser melalui: http://localhost:8080
- Username: admin
- Password: admin

## Services yang Berjalan

| Service | Description | Status |
|---------|-------------|---------|
| 🌐 **Webserver** | Airflow UI | http://localhost:8080 |
| 📅 **Scheduler** | Task scheduling | Background |
| 👷 **Worker** | Task execution | Background |
| 🔄 **Triggerer** | Deferred tasks | Background |
| 🔑 **Redis** | Message broker | Docker container |
| 🗄️ **PostgreSQL** | Database | **Neon Cloud** |

## DAG yang Tersedia

### 1. Example Workflow (example_dag.py)
DAG sederhana yang mendemonstrasikan penggunaan BashOperator dan PythonOperator dengan dependency antar task.

### 2. Data Processing Workflow (data_processing_dag.py)
DAG yang lebih kompleks yang mendemonstrasikan workflow pemrosesan data:
- Membuat sample data
- Memproses data
- Menghasilkan laporan
- Mengirim notifikasi setelah selesai

## Konsep Utama Airflow

1. **DAG (Directed Acyclic Graph)**: Representasi dari workflow yang terdiri dari tasks dan dependencies
2. **Operator**: Komponen yang mendefinisikan apa yang akan dilakukan oleh task (contoh: BashOperator, PythonOperator)
3. **Task**: Instance dari operator yang melakukan pekerjaan spesifik
4. **Task Dependencies**: Menentukan urutan eksekusi task (contoh: `task1 >> task2`)

## Tips Penggunaan

- Gunakan UI Airflow untuk memonitor status DAG dan task
- Periksa logs untuk debugging jika terjadi error
- Gunakan `docker-compose logs` untuk melihat logs container
- Untuk menghentikan semua container: `docker-compose down`

## Troubleshooting

### Database Connection Issues
Jika mengalami masalah koneksi ke Neon PostgreSQL:

```bash
# Test koneksi manual
./test-neon-connection.sh

# Atau test dengan psql langsung
docker run --rm -it postgres:13 psql "postgresql://neondb_owner:npg_G47bTrUPvdfo@ep-falling-cake-a1j2rvpd-pooler.ap-southeast-1.aws.neon.tech/airflow?sslmode=require"
```

### Database Migration
Jika muncul pesan error tentang database migration:

```bash
docker-compose exec airflow-webserver airflow db migrate
```

### Reset Instalasi
Untuk reset instalasi Airflow (tidak akan menghapus data Neon):

```bash
docker-compose down -v
docker-compose up -d
```

### Login Issues
Jika mengalami masalah login, buat user admin baru dengan perintah:

```bash
docker-compose exec airflow-webserver airflow users create \
  --role Admin \
  --username admin \
  --email admin@example.com \
  --firstname admin \
  --lastname admin \
  --password admin
```

## Keuntungan Menggunakan Neon PostgreSQL

1. **Serverless**: Auto-scaling berdasarkan load
2. **Backup otomatis**: Point-in-time recovery
3. **High availability**: 99.95% uptime SLA
4. **SSL/TLS**: Koneksi terenkripsi
5. **Cost-effective**: Pay per use
6. **Zero downtime**: Schema changes tanpa downtime

## Referensi

- [Apache Airflow Documentation](https://airflow.apache.org/docs/)
- [Airflow Docker Documentation](https://airflow.apache.org/docs/apache-airflow/stable/howto/docker-compose/index.html)
- [Neon PostgreSQL Documentation](https://neon.tech/docs)