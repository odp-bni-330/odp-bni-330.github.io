# Prometheus & Grafana Monitoring Demo with Dummy Data (Windows)

This project demonstrates a comprehensive monitoring setup using Prometheus and Grafana with dummy data generation, orchestrated with Docker Compose on Windows systems.

## Prerequisites

- [Docker](https://docs.docker.com/get-docker/)
- [Docker Compose](https://docs.docker.com/compose/install/)

## Components

### Services
- **Prometheus**: Metrics collection and storage
- **Grafana**: Metrics visualization and dashboards
- **Dummy App**: Python application generating sample metrics
- **Node Exporter**: System metrics collection

### Files
- `docker-compose.yml`: Defines all services (Prometheus, Grafana, Dummy App, WMI Exporter)
- `prometheus.yml`: Configuration file for Prometheus scraping targets
- `app.py`: Python application that generates dummy metrics
- `Dockerfile`: Container definition for the dummy application
- `start.bat`: Batch script to start the monitoring stack
- `stop.bat`: Batch script to stop the monitoring stack
- `start.ps1`: PowerShell script to start the monitoring stack
- `stop.ps1`: PowerShell script to stop the monitoring stack
- `README.md`: This file
- `grafana/provisioning/`: Auto-configuration for Grafana datasources and dashboards

## How to Run

1.  **Start the monitoring stack:**
    
    **Option A: Using Command Prompt (cmd):**
    Navigate to the `windows-monit` directory and run:
    ```cmd
    start.bat
    ```
    
    **Option B: Using PowerShell:**
    Navigate to the `windows-monit` directory and run:
    ```powershell
    .\start.ps1
    ```
    This command will:
    - Build the dummy application Docker image
    - Pull necessary Docker images (Prometheus, Grafana, Node Exporter)
    - Start all containers in the background
    - Configure Grafana with pre-defined dashboards

2.  **Access the services:**
    - **Prometheus**: [http://localhost:9090](http://localhost:9090)
      - View targets: Go to Status > Targets to see all monitored endpoints
      - Query metrics: Try `app_active_users`, `app_cpu_usage_percent`, or `up`
    - **Grafana**: [http://localhost:3000](http://localhost:3000)
      - **Login**: `admin` / `admin`
      - **Pre-configured dashboard**: "Application Monitoring Dashboard" will be automatically available
    - **Dummy App Metrics**: [http://localhost:8000/metrics](http://localhost:8000/metrics)
      - Raw Prometheus metrics from the dummy application
    - **WMI Exporter**: [http://localhost:9182/metrics](http://localhost:9182/metrics)
      - Windows system metrics from WMI Exporter

## Available Metrics

The dummy application generates the following metrics:

- `app_requests_total`: Counter of total HTTP requests by method and endpoint
- `app_active_users`: Gauge of current active users (10-100)
- `app_response_time_seconds`: Histogram of response times
- `app_error_rate`: Gauge of error rate percentage (0-5%)
- `app_cpu_usage_percent`: Gauge of CPU usage (20-80%)
- `app_memory_usage_bytes`: Gauge of memory usage

## Pre-configured Dashboard

The Grafana instance comes with a pre-configured dashboard called "Application Monitoring Dashboard" that displays:

- **Active Users**: Real-time count of active users
- **CPU Usage**: Application CPU utilization percentage
- **Request Rate**: HTTP requests per second by method and endpoint
- **Error Rate**: Application error rate percentage

## Manual Grafana Configuration (Optional)

The Prometheus data source and dashboard are automatically configured, but if you want to add more:

1.  **Additional Data Sources**: Configuration > Data Sources > Add data source
2.  **Custom Dashboards**: + > Dashboard > Add new panel
3.  **Sample Queries**:
    - `rate(app_requests_total[5m])` - Request rate over 5 minutes
    - `histogram_quantile(0.95, app_response_time_seconds_bucket)` - 95th percentile response time
    - `wmi_cpu_time_total` - WMI Exporter CPU metrics
    - `wmi_logical_disk_free_bytes` - Windows disk space metrics

## How to Stop

**Option A: Using Command Prompt (cmd):**
```cmd
stop.bat
```

**Option B: Using PowerShell:**
```powershell
.\stop.ps1
```

**Option C: Manually:**
```cmd
docker-compose down
``` 