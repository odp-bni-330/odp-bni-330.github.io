/*
 * Written by : Bostang Palaguna
 * Date : 2025-06-02
 * File : AuthService.java
 * Deskripsi : 
 * Kelas service yang menangani logika bisnis terkait autentikasi pengguna.
 * Meliputi proses registrasi pengguna baru, verifikasi kredensial saat login,
 * dan validasi token JWT.
 */

package com.example.connect_oracle_db.service;

import com.example.connect_oracle_db.entity.User;
import com.example.connect_oracle_db.repository.UserRepository;
import com.example.connect_oracle_db.util.JwtUtil;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

/**
 * Service untuk menangani operasi autentikasi termasuk:
 * - Registrasi pengguna baru
 * - Proses login pengguna
 * - Validasi token dan pengambilan data user
 */

/************************** Layer Service **************************/
@Service
public class AuthService {

    @Autowired
    private UserRepository repo; // Repository untuk operasi database terkait user

    @Autowired
    private PasswordEncoder encoder; // Komponen untuk enkripsi password

    @Autowired
    private JwtUtil jwtUtil; // Utility untuk operasi JWT (generate/validate token)

    /**
     * Method untuk registrasi pengguna baru.
     * 
     * @param username Username pengguna yang akan diregistrasi
     * @param password Password pengguna dalam bentuk plain text
     * @return Map berisi token JWT dan data user jika registrasi berhasil,
     *         atau null jika username sudah terdaftar
     */
    public Map<String, Object> register(String username, String password) {
        // Cek apakah username sudah terdaftar
        if (repo.existsById(username)) {
            return null;
        }

        // Buat user baru
        User user = new User();
        user.setUsername(username);
        user.setPasswordHash(encoder.encode(password)); // Enkripsi password sebelum disimpan
        user.setRole("USER"); // Set role default

        // Simpan user ke database
        repo.save(user);

        // Generate token JWT
        String token = jwtUtil.generateToken(user.getUsername(), user.getRole());

        // Siapkan response
        Map<String, Object> result = new HashMap<>();
        result.put("token", token);
        result.put("username", user.getUsername());
        result.put("role", user.getRole());

        return result;
    }

    /**
     * Method untuk proses login pengguna.
     * 
     * @param username Username pengguna
     * @param password Password pengguna dalam bentuk plain text
     * @return Map berisi token JWT dan data user jika login berhasil,
     *         atau null jika kredensial tidak valid
     */
    public Map<String, Object> login(String username, String password) {
        // Cari user berdasarkan username
        Optional<User> userOpt = repo.findByUsername(username);

        // Verifikasi password jika user ditemukan
        if (userOpt.isPresent() && encoder.matches(password, userOpt.get().getPasswordHash())) {
            User user = userOpt.get();

            // Generate token JWT
            String token = jwtUtil.generateToken(user.getUsername(), user.getRole());

            // Siapkan response
            Map<String, Object> result = new HashMap<>();
            result.put("token", token);
            result.put("username", user.getUsername());
            result.put("role", user.getRole());

            return result;
        }

        // Return null jika kredensial tidak valid
        return null;
    }

    /**
     * Method untuk mendapatkan data user dari token JWT.
     * 
     * @param token Token JWT yang akan divalidasi
     * @return Map berisi username dan role jika token valid,
     *         atau null jika token tidak valid
     */
    public Map<String, Object> getUserDetailsFromToken(String token) {
        // Validasi token terlebih dahulu
        if (!jwtUtil.validateToken(token)) {
            return null;
        }

        // Ekstrak informasi dari token
        String username = jwtUtil.getUsernameFromToken(token);
        String role = jwtUtil.getRoleFromToken(token);

        // Siapkan response
        Map<String, Object> result = new HashMap<>();
        result.put("username", username);
        result.put("role", role);

        return result;
    }
}
/************************** End of Layer Service *******************/