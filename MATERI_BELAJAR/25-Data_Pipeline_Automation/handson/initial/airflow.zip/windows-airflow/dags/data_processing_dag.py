from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator
import pandas as pd
import os

# Default arguments for the DAG
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

# Define the DAG
dag = DAG(
    'data_processing_workflow',
    default_args=default_args,
    description='Data processing workflow example for Windows',
    schedule_interval=timedelta(days=1),
    start_date=datetime(2023, 1, 1),
    catchup=False,
    tags=['data', 'processing', 'windows'],
)

# Task 1: Create a sample CSV file
def create_sample_data():
    # Create a directory for data if it doesn't exist
    os.makedirs('/opt/airflow/data', exist_ok=True)
    
    # Create a sample dataframe
    data = {
        'id': range(1, 101),
        'name': [f'Person_{i}' for i in range(1, 101)],
        'age': [(i * 73) % 80 + 20 for i in range(1, 101)],  # Random ages between 20 and 99
        'salary': [(i * 997) % 100000 + 30000 for i in range(1, 101)]  # Random salaries
    }
    
    df = pd.DataFrame(data)
    
    # Save to CSV
    df.to_csv('/opt/airflow/data/sample_data.csv', index=False)
    print(f"Created sample data with {len(df)} records")
    return "Sample data created successfully"

t1 = PythonOperator(
    task_id='create_sample_data',
    python_callable=create_sample_data,
    dag=dag,
)

# Task 2: Process the data
def process_data():
    # Read the CSV file
    df = pd.read_csv('/opt/airflow/data/sample_data.csv')
    
    # Perform some transformations
    df['salary_category'] = df['salary'].apply(
        lambda x: 'High' if x > 80000 else ('Medium' if x > 50000 else 'Low')
    )
    
    # Calculate some statistics
    stats = {
        'avg_age': df['age'].mean(),
        'avg_salary': df['salary'].mean(),
        'max_salary': df['salary'].max(),
        'min_salary': df['salary'].min(),
    }
    
    # Save processed data
    df.to_csv('/opt/airflow/data/processed_data.csv', index=False)
    
    # Save statistics
    pd.DataFrame([stats]).to_csv('/opt/airflow/data/statistics.csv', index=False)
    
    print(f"Processed {len(df)} records")
    print(f"Average salary: ${stats['avg_salary']:.2f}")
    return f"Data processed successfully. Average salary: {stats['avg_salary']:.2f}"

t2 = PythonOperator(
    task_id='process_data',
    python_callable=process_data,
    dag=dag,
)

# Task 3: Generate a report
def generate_report():
    # Read processed data
    df = pd.read_csv('/opt/airflow/data/processed_data.csv')
    stats = pd.read_csv('/opt/airflow/data/statistics.csv')
    
    # Create a simple HTML report
    html_content = f"""
    <html>
    <head>
        <title>Data Processing Report - Windows Environment</title>
        <style>
            body {{ font-family: Arial, sans-serif; margin: 20px; background-color: #f5f5f5; }}
            .container {{ background-color: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }}
            h1 {{ color: #2c3e50; border-bottom: 2px solid #3498db; padding-bottom: 10px; }}
            h2 {{ color: #34495e; margin-top: 30px; }}
            table {{ border-collapse: collapse; width: 100%; margin: 15px 0; }}
            th, td {{ border: 1px solid #ddd; padding: 12px; text-align: left; }}
            th {{ background-color: #3498db; color: white; }}
            tr:nth-child(even) {{ background-color: #f9f9f9; }}
            tr:hover {{ background-color: #e8f4f8; }}
            .footer {{ margin-top: 30px; padding: 15px; background-color: #ecf0f1; border-radius: 4px; }}
        </style>
    </head>
    <body>
        <div class="container">
            <h1>📊 Data Processing Report</h1>
            <p><strong>Environment:</strong> Windows Docker Desktop</p>
            <p><strong>Generated:</strong> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
            
            <h2>📈 Statistics Summary</h2>
            <table>
                <tr>
                    <th>Metric</th>
                    <th>Value</th>
                </tr>
                <tr>
                    <td>Average Age</td>
                    <td>{stats['avg_age'].values[0]:.2f} years</td>
                </tr>
                <tr>
                    <td>Average Salary</td>
                    <td>${stats['avg_salary'].values[0]:,.2f}</td>
                </tr>
                <tr>
                    <td>Maximum Salary</td>
                    <td>${stats['max_salary'].values[0]:,.2f}</td>
                </tr>
                <tr>
                    <td>Minimum Salary</td>
                    <td>${stats['min_salary'].values[0]:,.2f}</td>
                </tr>
                <tr>
                    <td>Total Records</td>
                    <td>{len(df)} persons</td>
                </tr>
            </table>
            
            <h2>💰 Salary Categories Distribution</h2>
            <table>
                <tr>
                    <th>Category</th>
                    <th>Count</th>
                    <th>Percentage</th>
                    <th>Salary Range</th>
                </tr>
    """
    
    # Calculate category counts
    category_counts = df['salary_category'].value_counts()
    total = len(df)
    
    category_ranges = {
        'High': '> $80,000',
        'Medium': '$50,000 - $80,000',
        'Low': '< $50,000'
    }
    
    for category, count in category_counts.items():
        percentage = (count / total) * 100
        salary_range = category_ranges.get(category, 'Unknown')
        html_content += f"""
            <tr>
                <td>{category}</td>
                <td>{count}</td>
                <td>{percentage:.2f}%</td>
                <td>{salary_range}</td>
            </tr>
        """
    
    html_content += f"""
            </table>
            
            <div class="footer">
                <p><strong>🚀 Powered by Apache Airflow on Windows Docker Desktop</strong></p>
                <p>Report generated successfully at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
            </div>
        </div>
    </body>
    </html>
    """
    
    # Save the report
    with open('/opt/airflow/data/report.html', 'w', encoding='utf-8') as f:
        f.write(html_content)
    
    print(f"Generated HTML report with {len(df)} records")
    return "Report generated successfully"

t3 = PythonOperator(
    task_id='generate_report',
    python_callable=generate_report,
    dag=dag,
)

# Task 4: Notify completion (Windows compatible)
t4 = BashOperator(
    task_id='notify_completion',
    bash_command='echo "🎉 Data processing workflow completed successfully on Windows at $(date)"',
    dag=dag,
)

# Set task dependencies
t1 >> t2 >> t3 >> t4 