# Navigate to the directory where the script is located
Set-Location $PSScriptRoot

Write-Host "Starting monitoring stack..." -ForegroundColor Green
docker-compose up -d

Write-Host "Monitoring stack started." -ForegroundColor Green
Write-Host "Prometheus is available at http://localhost:9090" -ForegroundColor Yellow
Write-Host "Grafana is available at http://localhost:3000 (login: admin/admin)" -ForegroundColor Yellow
Read-Host "Press Enter to continue" 