from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *

def create_spark_session():
    return (SparkSession.builder
            .appName("KafkaSparkStreaming")
            .config("spark.jars.packages", "org.apache.spark:spark-sql-kafka-0-10_2.12:3.3.0")
            .getOrCreate())

def define_schema():
    return StructType([
        StructField("transaction_id", StringType(), True),
        StructField("product_id", IntegerType(), True),
        StructField("product_name", StringType(), True),
        StructField("category", StringType(), True),
        StructField("quantity", IntegerType(), True),
        StructField("price_per_unit", DoubleType(), True),
        StructField("total_amount", DoubleType(), True),
        StructField("timestamp", StringType(), True)
    ])

def read_kafka_stream(spark):
    return (spark
            .readStream
            .format("kafka")
            .option("kafka.bootstrap.servers", "kafka:29092")
            .option("subscribe", "transactions")
            .option("startingOffsets", "earliest")
            .load())

def process_stream(df, schema):
    # Parse JSON data
    parsed_df = df.selectExpr("CAST(value AS STRING)") \
        .select(from_json(col("value"), schema).alias("data")) \
        .select("data.*")
    
    # Add processing timestamp
    df_with_timestamp = parsed_df.withColumn("processing_time", current_timestamp())
    
    # Calculate sales metrics
    # 1. Sales by category
    sales_by_category = df_with_timestamp \
        .groupBy(window(to_timestamp("timestamp", "yyyy-MM-dd HH:mm:ss"), "1 minute"), "category") \
        .agg(sum("total_amount").alias("total_sales"), count("transaction_id").alias("transaction_count"))
    
    # 2. Top selling products
    top_products = df_with_timestamp \
        .groupBy(window(to_timestamp("timestamp", "yyyy-MM-dd HH:mm:ss"), "1 minute"), "product_name") \
        .agg(sum("quantity").alias("units_sold"), sum("total_amount").alias("total_sales"))
    
    return sales_by_category, top_products

def start_streaming(sales_by_category, top_products):
    # Start the category sales stream
    query1 = sales_by_category \
        .writeStream \
        .outputMode("complete") \
        .format("console") \
        .option("truncate", "false") \
        .start()
    
    # Start the top products stream
    query2 = top_products \
        .writeStream \
        .outputMode("complete") \
        .format("console") \
        .option("truncate", "false") \
        .start()
    
    return query1, query2

if __name__ == "__main__":
    # Create Spark session
    spark = create_spark_session()
    
    # Define schema for the transaction data
    schema = define_schema()
    
    # Read from Kafka
    kafka_df = read_kafka_stream(spark)
    
    # Process the stream
    sales_by_category, top_products = process_stream(kafka_df, schema)
    
    # Start the streaming queries
    query1, query2 = start_streaming(sales_by_category, top_products)
    
    # Wait for the queries to terminate
    query1.awaitTermination()
    query2.awaitTermination()